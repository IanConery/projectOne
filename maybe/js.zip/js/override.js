
/******************************************************************
 * schedule.js
 *
 * This Javascript code does all the implementation of the code
 * related to the boiler monitor page.
 *
 * This code is jQuery 1.4.X dependent and also dependent on the
 * jquery.niagara-ajax.X.js jQuery plug-in for Niagara/Ajax 
 * communication with the Niagara server and the 
 * jquery.control-panel-1.0.js file, both of which must be loaded
 * first.
 * Author: Deepti Phadnis
 ******************************************************************/
 
	 jQuery(document).ready(function($) {

		 var loc = location.search.substring(1, location.search.length);
		 
		    var param_value = false;
		 var params = loc.split("&");
		 
		 param_name = params[0].substring(0,params[0].indexOf('='));
		 param_value = params[0].substring(params[0].indexOf('=')+1);
		 
		 var output = [];
		  var $data = {
		   regionPath : param_value,
		   scheduleType : "HVAC",
		   scheduleName : param_value
		 };
		 var $currWeeklySchedule = [];
		 var $newWeeklySchedule = [];
		    var maskHeight = 600;
		    var maskWidth = $(document).width();
		    var winH = 500;
		    var winW = $(document).width();
		    
		    var hvacList = [];
		    var lightingList = [];
		    var generalList = [];
		    
		var oldEventName="";
		var newEventName="";
		var cnt=30;
		var windLoc = window.location+"";
		var schedName="";
		var eventNames = "";
		var str1="";

		schedName = ""+params[0].substring(params[0].indexOf('=')+1);
		$data.scheduleName = schedName;

 
		$.niagara.getOverrideData($data.scheduleName,function(obj)
				{
				if(obj != null)
				{
					setOverrideData(obj);
				}
				});
 
 

 
 
function setOverrideData(obj)
{
	$("#enable").val(obj.enable);
	$("#nullOnActive").val(obj.nullOnActive);
	$("#overrideStartTime").text(obj.overrideStart);
	$("#overrideEndTime").text(obj.overrideEnd);

	$("#startTimeHour").val(obj.startHour);
	$("#startTimeMinute").val(obj.startMin);
	$("#startTimeAMPM").val(obj.startAmPm);

	$("#endTimeHour").val(obj.endHour);
	$("#endTimeMinute").val(obj.endMin);
	$("#endTimeAMPM").val(obj.endAmPm);
}
 
 $("#overrideSave").click(function(){

  var overrideStartTime = $("#overrideStartTime").val();
  var overrideEndTime = $("#overrideEndTime").val();

  var enable = $("#enable").val();
  var nullOnActive = $("#nullOnActive").val();
  var startTimeHour = $("#startTimeHour").val();
  var startTimeMinute = $("#startTimeMinute").val();
 
  var startTimeAMPM = $("#startTimeAMPM").val();
  var endTimeHour = $("#endTimeHour").val();
  var endTimeMinute = $("#endTimeMinute").val();
  
  var endTimeAMPM = $("#endTimeAMPM").val();
  
  
 
    $.niagara.saveOverrideData($data.scheduleName,enable,nullOnActive,startTimeHour,startTimeMinute,startTimeAMPM,endTimeHour,endTimeMinute,endTimeAMPM,function(obj){
     if(obj.value!= null)
       {
      if(obj.value == "false")
      {
       alert("Please check inputs");
      }
      else
    {
  		$.niagara.getOverrideData($data.scheduleName,function(obj)
				{
				if(obj != null)
				{
					setOverrideData(obj);
				}
				});
    }	  
    	  
       }
     //sethref("#sunPositionSave");
     });
 }); 
 
 $("#backButton").click(function()
		 {
	 sethref("#backButton");
	 	
});
 
function sethref(obj)
{
	
	 var arr = params[0].split("/");
		var sched = arr[arr.length-1];
		params[0]="";
		console.log(arr);
		for(var i=0;i<arr.length-1;i++)
		{	
			if(i<arr.length-2)
				params[0] = params[0]+arr[i]+"/";
			else
				params[0] = params[0]+arr[i];
		}
		var alink = "indexRelative.html?"+params[0]+"&sched="+sched;
		$(obj).attr('href',alink);	
		location.href = alink;

}
     
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     

 /* Get the metering present datapoint and store its result */
  
 $(window).unload(function() {
 // clearInterval(intr);
 });
 
});



 