// JavaScript Document
/*****************************************************************
 * Name: powerAnalyticsUtil.js
 * Version: 1.1
 * Date: 03/16/2013
 * Copyright: 2013 Controlco
 *
 * This file is called by lightingAnalyticsNew.js,lightingAnalytics.js,power.js and hvacTable1.js,navFile.js,hvacAnalyticsUtil.js
 * This code converts data to xml format and calls the niagra function
 * to retrieve data in xml format.It also makes function call to
 * plot the chart

 *****************************************************************/

$util = $util || {};;
(function($) {

    (function() {

    })();
    var energyDataSeries = [];
    var photocellInnerFlag;
    var xstr;
    var clickPowerTableRow;
    window.equipTables_Intervals = window.equipTables_Intervals || [];


    _.extend($util, {

        getChildNodes: function(uid, nodeId, tags, data) {
            var xml = "<ProphetRequest version='1'>" +
                "<Method name='getChildNodes' uid='" + uid + "'>" +
                "<nodeId>" + nodeId + "</nodeId>";
            if (tags != null) {
                xml = xml + "<tags>" + tags + "</tags>";
            }
            if (data != null) {
                xml = xml + "<data>" + data + "</data>";
            }
            xml = xml + "</Method>" + "</ProphetRequest>";
            return xml;
        },
        getNode: function(nodeId) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='getNode' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + nodeId + "</nodeId>" +
                "</Method></ProphetRequest>";
            return req;
        },

        //This function is used to get the nav file path from the attributes assigned to the respective(slot/nodeId).
        getNodeNavInfo: function(xml) {
            var xmlparse = $.parseXML(xml);
            var $xmlStr = $(xmlparse);
            var nodeArr = [];
            $xmlStr.find("node").each(function() {
                var arr = [];
                var node = $(this);
                var nodeType = $(node).attr('type');
                if (nodeType == 'csi3prophet:ProphetTemplateNode' || nodeType == 'csi3prophet:ProphetNode') {
                    var nodeId = $(node).find("nodeId").text();
                    var name = $(node).find("name").text();
                    var navLink;

                    var attrArr = $(node).find("attributes").text();
                    $(node).find("attributes").each(function() {
                        var attributesArr = $(this);

                        $(attributesArr).find("attr").each(function() {
                            var attrVal = $(this);
                            var test2 = $(attrVal).attr('n');
                            if (test2 == "disNavPlant" || test2 == "disNavEquip" || test2 == "disNavPhotocell") {
                                navLink = $(attrVal).text();
                            }

                        });

                    });

                    var pathFromParent = "/" + $(node).find("pathFromParent").text();
                    var parentpath = nodeId.replace(pathFromParent, "");
                    var vaArr = parentpath.split("/");
                    var parentName = vaArr[vaArr.length - 1];
                    arr.push(name);
                    arr.push(nodeId);
                    arr.push(navLink);

                    //arr.push(parentName);
                    //arr.push(parentpath);
                    // nodeArr.push(arr);
                    nodeArr = arr;
                }
            });


            return nodeArr;
        }, //xml string to setAttributes
        setAttributesXML: function(nodeId, action, value) {
            var xml = "<ProphetRequest version='1'>" +
                "<Method name='setAttributes' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + nodeId + "</nodeId>" +
            //  "<attr n='"+action+"'>"+value+"</attr>"+
            "<attr n='" + action + "'>" + value + "</attr>" +
                "</Method></ProphetRequest>";
            return xml;
        }, //xml string to invoke function
        setLightingOverrideXML: function(nodeId, action, dataDefn) {
            var xml = "<ProphetRequest version='1'>" +
                "<Method name='invoke' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + nodeId + "</nodeId>" +
                "<data>" + dataDefn + "</data>" +
                "<action>" + action + "</action>" +
                "</Method></ProphetRequest>";
            return xml;
        },
        pollconfigXML: function(ord, dataDefn, action) {
            var xml = "<ProphetRequest version='1'>" +
                "<Method name='invoke' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + ord + "</nodeId>";
            if (dataDefn != null) {
                xml = xml + "<data>" + dataDefn + "</data>";
            }
            xml = xml + "<action>" + action + "</action></Method></ProphetRequest>";
            return xml;
        },
        //function call to setAttributes. Further the call is made to jquery.niagara-ajax-1.4.js
        setAttributes: function(req, ord, dataDefn) {
            $.niagara.setAttributes("testPath", req, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var $xml = $(xmlDoc);
                var functName;
                $xml.find("MethodResponse").each(function() {
                    var method = $(this);
                    functName = $(method).attr('name');
                });
                if (functName == "setAttributes" && typeof(dataDefn) != "undefined") {
                    ord = ord + '/Scheduling';
                    var forcepollStr = $util.pollconfigXML(ord, dataDefn, "Force Poll");
                    $util.forcePollUpdateConfig(forcepollStr, ord, dataDefn);

                }

            }); //end of setAttributes ajax call

        },
        forcePollUpdateConfig: function(forcepollStr, ord, dataDefn) {
            $.niagara.postReq("testPath", forcepollStr, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var $xml = $(xmlDoc);
                var name;
                $xml.find("MethodResponse").each(function() {
                    var method = $(this);
                    name = $(method).attr('name');
                });
                if (name == "invoke") {
                    var updateConfigStr = $util.pollconfigXML(ord, "", "Update Config");
                    $.niagara.postReq("testPath", updateConfigStr, function(obj) {});

                }

            });

        },

        forcePoll_updateConfig: function(nodeId, data) {

            var req = {
                attrs: {
                    name: 'invoke',
                    uid: 'forcePoll_updateConfig'
                },
                children: [{
                    nodeId: nodeId + '/Scheduling',
                    data: data,
                    action: 'Force Poll'
                }]
            };

            var forcePollReq = TMPLS.genericProphetReq([req])

            req.children[0].action = 'Update Config';

            var updateConfigReq = TMPLS.genericProphetReq([req])

            dataEye.ajax(forcePollReq, function(res) {

                dataEye.ajax(updateConfigReq, function(res) {

                });

            });

        },
        //Set override value for the lighting
        setLightingOverride: function(req, ord, dataDefn) {
            $.niagara.setOverride("testPath", req, function(obj) {


                var xmlDoc = $.parseXML(obj);
                var $xml = $(xmlDoc);
                var functName;
                $xml.find("MethodResponse").each(function() {
                    var method = $(this);
                    functName = $(method).attr('name');
                });

            }); //end of setOverride ajax call

        }, //parse nav file for Chiller Plant
        parseNavInfo: function(xml) {
            var xmlparse = $.parseXML(xml);
            var $xmlStr = $(xmlparse);
            var nodeArr = [];
            var tableArr = [];
            $xmlStr.find("node").each(function() {
                var arr = [];
                var tableHeader = [];
                var child;
                var ordChild;
                var node = $(this);
                var nodeName = $(node).attr('name');
                //(test2.match(/schInt/g))
                if (nodeName.match(/btn/g) || nodeName.match(/col/g)) {
                    var nodeId = $(node).attr('ord');
                    var name = $(node).attr('name');

                    $(this).find("node").each(function() {
                        var nodeNameChild = $(this).attr('name');

                        if (nodeNameChild.match(/hdr/g)) {
                            var nameChild = $(this).attr('name');
                            ordChild = $(this).attr('ord');
                            child = nameChild;
                            var rowValues = [];

                            $(this).find("node").each(function() {

                                var nodeNameInnerChild = $(this).attr('name');
                                var nodeNameInnerChildOrd = $(this).attr('ord');
                                rowValues.push({
                                    "ptName": nodeNameInnerChild,
                                    "ptOrd": nodeNameInnerChildOrd
                                });

                            });
                            tableHeader.push({
                                "hdrName": child,
                                "hdrOrd": ordChild,
                                "hdrVal": rowValues
                            });

                        }

                    });

                    var btnName = (name).split(':');

                    arr.push(btnName[1]);
                    nodeArr.push(arr);
                    tableArr.push({
                        "btn": arr,
                        "hdr": tableHeader
                    });

                }
            });

            return tableArr;
        },

        //parse the nav info for equipment units.Equipment unit points are plotted in UI based on left and right xml tag.
        parseUnitNavInfo: function(xml) {
            var xmlparse = $.parseXML(xml);
            var $xmlStr = $(xmlparse);
            var unitNavArr = [];

            $xmlStr.find("node").each(function() {
                var node = $(this);
                var nodeName = $(node).attr('name');

                if (nodeName.match(/col:Left/g)) {
                    var colLeft = [];

                    $(this).find("node").each(function() {

                        var colVal = $(this);
                        var colName = $(colVal).attr('name');
                        var colOrd = $(colVal).attr('ord');

                        colLeft.push({
                            "ptName": colName,
                            "ptOrd": colOrd
                        });
                    });
                    unitNavArr.push({
                        "left": colLeft
                    })
                }
                if (nodeName.match(/col:Right/g)) {
                    var colRight = [];

                    $(this).find("node").each(function() {

                        var colVal = $(this);
                        var colName = $(colVal).attr('name');
                        var colOrd = $(colVal).attr('ord');

                        colRight.push({
                            "ptName": colName,
                            "ptOrd": colOrd
                        });

                    });
                    unitNavArr.push({
                        "right": colRight
                    })
                }

            });


            return unitNavArr;
        },
        //parse the childNodes from the xml string response. This is only for ProphetNodes
        getNodeArr: function(xml) {
            var xmlparse = $.parseXML(xml);
            var $xmlStr = $(xmlparse);
            var nodeArr = [];
            $xmlStr.find("node").each(function() {
                var arr = [];
                var node = $(this);
                var nodeType = $(node).attr('type');
                if (nodeType == 'csi3prophet:ProphetNode') {
                    var nodeId = $(node).find("nodeId").text();
                    var name = $(node).find("name").text();
                    var pathFromParent = "/" + $(node).find("pathFromParent").text();
                    var parentpath = nodeId.replace(pathFromParent, "");
                    var vaArr = parentpath.split("/");
                    var parentName = vaArr[vaArr.length - 1];
                    arr.push(name);
                    arr.push(nodeId);
                    //arr.push(parentName);
                    //arr.push(parentpath);
                    nodeArr.push(arr);
                }
            });
            return nodeArr;
        }, //parse the childNodes from the xml string response. This function is created for lighting.html page, since it needs attributes.
        // called by file lightingAnalytics.js and lightingAnalyticsNew.js
        getlightingNodeArr: function(xml) {
            var xmlparse = $.parseXML(xml);
            var $xmlStr = $(xmlparse);
            var nodeArr = [];
            $xmlStr.find("node").each(function() {
                var arr = [];
                var node = $(this);
                var nodeType = $(node).attr('type');
                if (nodeType == 'csi3prophet:ProphetNode' || nodeType == 'csi3prophet:ProphetTemplateNode') {
                    var nodeId = $(node).find("nodeId").text();
                    var name = $(node).find("name").text();
                    var displayName;
                    var attrArr = $(node).find("attributes").text();
                    $(node).find("attributes").each(function() {
                        var attributesArr = $(this);

                        $(attributesArr).find("attr").each(function() {
                            var attrVal = $(this);
                            var test2 = $(attrVal).attr('n');
                            if (test2 == "disLoc") {
                                displayName = $(attrVal).text();
                            }

                        });

                    });
                    var pathFromParent = "/" + $(node).find("pathFromParent").text();
                    var parentpath = nodeId.replace(pathFromParent, "");
                    var vaArr = parentpath.split("/");
                    var parentName = vaArr[vaArr.length - 1];
                    arr.push(name);
                    arr.push(nodeId);
                    arr.push(displayName);
                    nodeArr.push(arr);
                }
            });

            return nodeArr;
        }, //Function to count the exterior,interior,photocell and deck flags
        getLightingNodeAttrInfo: function(xml) {
            var xmlparse = $.parseXML(xml);
            var $xmlStr = $(xmlparse);
            var nodeArr = [];
            var nodeMap;
            $xmlStr.find("node").each(function() {
                var arr = [];
                var node = $(this);
                var nodeType = $(node).attr('type');
                if (nodeType == 'csi3prophet:ProphetNode') {
                    var nodeId = $(node).find("nodeId").text();
                    var name = $(node).find("name").text();
                    var displayName, schExtPhotocellCounter, schIntPhotocellCounter, schDeckPhotocellCounter;
                    schIntPhotocellCounter = 0;
                    schExtPhotocellCounter = 0;
                    schDeckPhotocellCounter = 0;
                    var attrArr = $(node).find("attributes").text();
                    $(node).find("attributes").each(function() {
                        var attributesArr = $(this);

                        $(attributesArr).find("attr").each(function() {
                            var attrVal = $(this);
                            var test2 = $(attrVal).attr('n');

                            if (test2.match(/schInt/g)) {
                                schIntPhotocellCounter = schIntPhotocellCounter + 1;
                            }
                            if (test2.match(/schExt/g)) {
                                schExtPhotocellCounter = schExtPhotocellCounter + 1;

                            }
                            if (test2.match(/schDec/g)) {
                                schDeckPhotocellCounter = schDeckPhotocellCounter + 1;

                            }

                        });

                    });

                    var pathFromParent = "/" + $(node).find("pathFromParent").text();
                    var parentpath = nodeId.replace(pathFromParent, "");
                    var vaArr = parentpath.split("/");
                    var parentName = vaArr[vaArr.length - 1];
                    //  arr.push(name);
                    //  arr.push(nodeId);
                    // arr.push(dispalyName);
                    // arr.push({"ext":schExtPhotocellCounter});
                    // arr.push({"int":schIntPhotocellCounter});
                    nodeMap = {
                        "mallName": name,
                        "siteOrd": nodeId,
                        "ext": schExtPhotocellCounter,
                        "int": schIntPhotocellCounter,
                        "deck": schDeckPhotocellCounter
                    };

                    //  nodeArr.push(arr);
                }
            });
            return nodeMap;
        },
        getlightingTemplateNodeArr: function(xml) {
            var xmlparse = $.parseXML(xml);
            var $xmlStr = $(xmlparse);
            var nodeArr = [];
            $xmlStr.find("node").each(function() {
                var arr = [];
                var node = $(this);
                var nodeType = $(node).attr('type');
                if (nodeType == 'csi3prophet:ProphetTemplateNode' || nodeType == 'csi3prophet:ProphetNode') {
                    var nodeId = $(node).find("nodeId").text();
                    var name = $(node).find("name").text();
                    var dispalyName;

                    var attrArr = $(node).find("attributes").text();
                    $(node).find("attributes").each(function() {
                        var attributesArr = $(this);

                        $(attributesArr).find("attr").each(function() {
                            var attrVal = $(this);
                            var test2 = $(attrVal).attr('n');
                            if (test2 == "disName") {
                                dispalyName = $(attrVal).text();

                            }
                        });

                    });

                    var pathFromParent = "/" + $(node).find("pathFromParent").text();
                    var parentpath = nodeId.replace(pathFromParent, "");
                    var vaArr = parentpath.split("/");
                    var parentName = vaArr[vaArr.length - 1];
                    arr.push(name);
                    arr.push(nodeId);
                    arr.push(dispalyName);

                    //arr.push(parentName);
                    //arr.push(parentpath);
                    nodeArr.push(arr);
                }
            });
            return nodeArr;
        }, //parse the template nodes. This is a separate function since the xml response contains nodetype as csi3prophet:ProphetTemplateNode
        getTemplateNodeArr: function(xml) {
            var xmlparse = $.parseXML(xml);
            var $xmlStr = $(xmlparse);
            var nodeArr = [];
            $xmlStr.find("node").each(function() {
                var arr = [];
                var node = $(this);
                var nodeType = $(node).attr('type');
                if (nodeType == 'csi3prophet:ProphetTemplateNode') {
                    var nodeId = $(node).find("nodeId").text();
                    var name = $(node).find("name").text();
                    var pathFromParent = "/" + $(node).find("pathFromParent").text();
                    var parentpath = nodeId.replace(pathFromParent, "");
                    var vaArr = parentpath.split("/");
                    var parentName = vaArr[vaArr.length - 1];
                    arr.push(name);
                    arr.push(nodeId);
                    //arr.push(parentName);
                    //arr.push(parentpath);
                    nodeArr.push(arr);
                }
            });
            return nodeArr;
        },
        getDataNodeArr: function(xml) {
            var xmlparse = $.parseXML(xml);
            var $xmlStr = $(xmlparse);
            var nodeArr = [];
            var data;
            $xmlStr.find("dataDefinition ").each(function() {
                var node = $(this);
                var name = $(node).find("name").text();
                data = $(node).find("data").text();
            });
            // return nodeArr;
            return data;
        },
        createRequestString: function(nodeId, data, timeRange, aggregation, interval, rollup) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='getTrend' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + nodeId + "</nodeId>" +
                "<data>" + data + "</data>" +
                "<timeRange>" + timeRange + "</timeRange>" +
                "<aggregation>" + aggregation + "</aggregation>" +
                "<interval>" + interval + "</interval>" +
                "<rollup>" + rollup + "</rollup>" +
                "</Method>" +
                "</ProphetRequest>";
            return req;
        },
        getTableQuery: function(ord, query) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='getTable' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + ord + "</nodeId>" +
                "<query>" + query + "</query>" +
                "<headers>displayName</headers>" +
                "</Method>" +
                "</ProphetRequest>";
            return req;
        },
        getTableQuery1: function(ord, query) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='getTable' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + ord + "</nodeId>" +
                "<query>" + query + "</query>" +
                "<headers>displayName</headers>" +
                "</Method>" +
                "</ProphetRequest>";
            //$util.extractPowerTableResponse1(req); //reference to powerAnalyticsUtil.js

            return req;
        },
        getGateWay: function(ord) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='getChildNodes' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + ord + "</nodeId>" +
                " <tags>gateway</tags>" +
                "</Method>" +
                "</ProphetRequest>";

            return req;

        },
        modalBusy: function(text, interval) {
            $('#loadingMask').remove();
            if ($('#loadingMask').length >= 0) {
                var html = '<div style="position: absolute; top: 0; left: 0; z-index:9995;" id="loadingMask"><div style="opacity: 0.8; height: 90px; width: 120px; position: absolute; top: 36%; left: 43%; z-index:9997;" id="loading"><img style="margin-top: 7px; margin-left: auto; margin-right: auto; display: block; z-index:9999; opacity: 1;" src="images/loading.gif" /><br/><h4 style="text-align: center; margin-top: 0; margin-left: auto; margin-right: auto; padding-left: 7px; color: #2E2E2E; opacity: 1; z-index:9999">' + text + '...</h4></div></div>';
                $('body').append(html);

                //Get the screen height and width
                var maskHeight = $(document).height() + 'px';
                var windowWidth = $(window).width();
                var maskWidth = windowWidth + 'px';
                var windowHeight = $(window).height();

                /* Center the inner loading window */
                $('#loadingMask').css({
                    'height': maskHeight,
                    'width': maskWidth
                });
                var loadHeight = windowHeight / 2 - $('#loading').height() / 2;
                loadHeight += 'px';
                var loadWidth = windowWidth / 2 - $('#loading').width() / 2;
                loadWidth += 'px';
                $('#loading').css({
                    'top': loadHeight,
                    'left': loadWidth
                });
                // timeout and remove after two minutes...
                var intvl = 60000;
                if (interval)
                    intvl = interval;
                setTimeout(function() {
                    $util.modalDone();
                }, intvl);
            }
        },
        modalDone: function() {
            $('#loadingMask').fadeOut(400, function() {
                $(this).remove();
            });
        },
        subscribeSummaryReq: function(arr, uid) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='subscribe' uid='" + uid + "'>";
            for (var i = 0; i < arr.length; i++) {
                req = req + "<getValue uid='" + arr[i].uid + "' nodeId='" + arr[i].nodeId + "' data='" + arr[i].data + "' />";
                //+"tags='"+arr[i].tags+"' />";
            }
            req = req + "</Method>" +
                "</ProphetRequest>";
            return req;
        },

        subscribeNavTableReq: function(arr, uid) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='subscribe' uid='" + uid + "'>";
            for (var i = 0; i < arr.length; i++) {
                req = req + "<getValue uid='" + arr[i][0].uid + "' nodeId='" + arr[i][0].nodeId + "' data='" + arr[i][0].data + "' />";
            }
            req = req + "</Method>" +
                "</ProphetRequest>";
            return req;
        },
        subscribeHvacTableReq: function(arr, uid) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='subscribe' uid='" + uid + "'>";
            for (var i = 0; i < arr.length; i++) {
                req = req + "<getValue uid='" + arr[i][0].uid + "' nodeId='" + arr[i][0].nodeId + "' data='" + arr[i][0].data + "' />";
            }
            req = req + "</Method>" +
                "</ProphetRequest>";
            return req;
        },
        subscribeLightingReq: function(arr, uid) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='subscribe' uid='" + uid + "'>";
            for (var i = 0; i < arr.length; i++) {
                req = req + "<getValue uid='" + arr[i].uid + "' nodeId='" + arr[i].nodeId + "' data='" + arr[i].data + "' />";
            }
            req = req + "</Method>" +
                "</ProphetRequest>";
            return req;
        },
        subscribeReq: function(arr, data1, data2) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='subscribe' uid='" + arr + "'>" +
                "<getValue " +
                "uid='" + arr + "?" + data1 + "' " +
                "nodeId='" + arr + "' " +
                "data='" + data1 + "'/>" +
                "<getValue " +
                "uid='" + arr + "?" + data2 + "' " +
                "nodeId='" + arr + "' " +
                "data='" + data2 + "'/></Method></ProphetRequest>";
            return req;
        },
        unsubscribe: function(uid) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='unsubscribe' uid='" + uid + "'/>" +
                "</ProphetRequest>";
            return req;

        },
        subscribePoints: function(req) {
            $.niagara.postReq("testPath", req, function(obj) {
                var xmlDoc = $.parseXML(obj);
                var $xml = $(xmlDoc);
                var parseVal;
                $xml.find("value").each(function() {
                    xmlObj = $(this);
                    var uid = xmlObj.attr("uid");
                    var val = xmlObj.attr("v");
                    var gaugeVal = parseFloat(val);
                    gaugeVal = gaugeVal.toFixed(2);
                    var output = $util.insertCommas(val);
                    $(uid).html(output);

                    if (uid == '#powerData') {
                        gauges.powerData.setValue(gaugeVal);

                    } else if (uid == '#energyData') {
                        gauges.energyData.setValue(gaugeVal);
                    }
                });

            });

        },
        subscribeLightingPoints: function(req, uid) {
            $.niagara.postReq("testPath", req, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var $xml = $(xmlDoc);
                var parseVal;
                $xml.find("value").each(function() {
                    xmlObj = $(this);
                    var uid = xmlObj.attr("uid");
                    var val = xmlObj.attr("v");
                    var output = val.toString();
                    $(uid).html(output);
                });

            });

            var pollreq = $util.pollReq(uid);

            $util.kickoffPolling({
                fxn: $util.pollLightingPoints,
                args: [pollreq],
                interval: 10000
            });

        },
        subscribeHvacTable: function(responseHvac, uid) {

            $.niagara.postReq("testPath", responseHvac, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var $xml = $(xmlDoc);
                var parseVal;


                $xml.find("value").each(function() {
                    xmlObj = $(this);
                    var uid = xmlObj.attr("uid");
                    var status = xmlObj.attr("status");

                    var val = xmlObj.attr("v");
                    if (isNaN(val)) {
                        val = val;
                    } else {
                        val = Math.round(val * Math.pow(10, 2)) / Math.pow(10, 2);
                    }
                    $("#" + uid).html(val);

                });

            });

            var pollreq = $util.pollReq(uid);

            $util.kickoffPolling({
                fxn: $util.pollNavTable,
                args: [pollreq, uid],
                interval: 6000,
                pollQueue: 'equipTables_Intervals'
            });

        },

        subscribeNavTable: function(navReq, uid) {

            $.niagara.postReq("testPath", navReq, function(xml) {

                var subscribeData = $util.parseSubscribeXml(xml);

                var xmlDoc = $.parseXML(xml);
                var $xml = $(xmlDoc);
                var parseVal;
                $xml.find("MethodResponse").each(function() {
                    var method = $(this);
                    name = $(method).attr('name');
                    var uidRes = $(method).attr('uid');
                    var test = $(this).find("error").text();
                    if (test == "Missing data") {
                        $("#" + uidRes).parent().remove();
                    }

                });

                $xml.find("value").each(function(i, e) {
                    xmlObj = $(this);
                    var uidRes = xmlObj.attr("uid");
                    var status = xmlObj.attr("status");
                    var units = xmlObj.attr("units");
                    var val = xmlObj.attr("v");
                    var type = $(e).attr('type');

                    if (type) {
                        var trueText = $(e).attr('trueText');
                        var falseText = $(e).attr('falseText')
                    }

                    if (type === 'boolean' && trueText && falseText) {

                        if (val === 'false' || val === '0') {
                            $("#" + uidRes).html(falseText);
                        } else {
                            $("#" + uidRes).html(trueText);
                        }

                    } else {
                        if (val && isNaN(val)) {
                            val = val;
                        } else if (val) {
                            val = Math.round(val * Math.pow(10, 2)) / Math.pow(10, 2);
                        }
                        if (status == "disabled") {
                            // var output = val.toString();
                            $("#" + uidRes).html(val);
                            $("#" + uidRes).css({
                                'color': 'red'
                            });
                        } else {
                            $("#" + uidRes).html(val);

                        }
                    }

                });

            });

            var pollreq = $util.pollReq(uid);

            $util.kickoffPolling({
                fxn: $util.pollNavTable,
                args: [pollreq, uid],
                interval: 6000,
                pollQueue: 'equipTables_Intervals'
            });



        },
        pollNavTable: function(responseHvac, uid) {


            $.niagara.postReq("testPath", responseHvac, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var $xml = $(xmlDoc);
                var parseVal;
                $xml.find("value").each(function(i, e) {
                    xmlObj = $(this);
                    var uid = xmlObj.attr("uid");
                    var status = xmlObj.attr("status");

                    var val = xmlObj.attr("v");

                    var type = $(e).attr('type');

                    if (type) {
                        var trueText = $(e).attr('trueText');
                        var falseText = $(e).attr('falseText')
                    }

                    if (type === 'boolean' && trueText && falseText) {

                        if (val === 'false' || val === '0') {
                            $("#" + uid).html(falseText);
                        } else {
                            $("#" + uid).html(trueText);
                        }

                    } else {

                        if (val && isNaN(val)) {
                            val = val;
                        } else if (val) {
                            val = Math.round(val * Math.pow(10, 2)) / Math.pow(10, 2);
                        }
                        if (status == "disabled") {
                            // var output = val.toString();
                            $("#" + uid).html(val);
                            $("#" + uid).css({
                                'color': 'red'
                            });

                        } else {
                            $("#" + uid).html(val);

                        }

                    }
                });

            });
        },

        //subscribe function for newlighting.html
        subscribeLightingArr: function(req, uid, globalOrd, parentId) {
            $.niagara.postReq("testPath", req, function(obj) {

                $util.displayCircuitData(obj, globalOrd, parentId);



            });

            var pollreq = $util.pollReq(uid);

            $util.kickoffPolling({
                fxn: $util.pollLightingArr,
                args: [pollreq, globalOrd, parentId],
                interval: 15000,
                pollQueue: 'lighting_pollIntervals'
            });

        },
        //polling for lighting page
        pollLightingPoints: function(req) {
            $.niagara.postReq("testPath", req, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var $xml = $(xmlDoc);
                var parseVal;
                $xml.find("value").each(function() {
                    xmlObj = $(this);
                    var uid = xmlObj.attr("uid");
                    var val = xmlObj.attr("v");
                    var output = val.toString();
                    $(uid).html(output);
                });

            });

        }, //poll function for newlighting.html
        pollLightingArr: function(req, globalOrd, parentId) {
            $.niagara.postReq("testPath", req, function(obj) {
                $util.displayCircuitData(obj, globalOrd, parentId);
            });

        },
        displayCircuitData: function(obj, globalOrd, parentId) { // tear-jearker, please re-work, seriously, this has to do this lighting, and should be in lighting.js

            var xmlDoc = $.parseXML(obj);
            var $xml = $(xmlDoc);
            var parseVal;
            var parentUID;
            $xml.find("MethodResponse").each(function() {
                var method = $(this);
                parentUID = $(method).attr('uid');
            });
            if (parentUID == (globalOrd[globalOrd.length - 1])) {

                $xml.find("value").each(function() {
                    xmlObj = $(this);
                    var uid = xmlObj.attr("uid");
                    var status1 = xmlObj.attr("status");

                    var val = xmlObj.attr("v");
                    var output = val.toString();
                    uid = uid.split("-");

                    if (uid[0] == "#Panel #overrideData" || uid[0] == "#Group #overrideData") //check condition to update the o/p lable + override dropdown
                    {

                        overrideVal = output;
                        if (status1 == "overriden" || status1 == "overridden") {
                            if (output == "false") {
                                //  $('#overrideData').val("0");//ie off
                                //  $("#outputData").html("off"+uid[1]);
                                if ($('#lightingStatus i').length > 0) {
                                    $('#lightingStatus').find('i').remove();
                                }
                                $('#' + parentId + ' #overrideData').val("0"); //ie off
                                $('#' + parentId + " #outputData").html("off" + uid[1]);

                            } else {
                                //$('#overrideData').val("1");//ie on
                                //$("#outputData").html("on"+uid[1]);
                                if ($('#lightingStatus i').length > 0) {
                                    $('#lightingStatus').find('i').remove();
                                }
                                $('#lightingStatus').prepend('<i class="icon icon-dot status-' + status1 + '" title="' + status1 + '" style="padding-right: 5px;"></i>');
                                $('#' + parentId + ' #overrideData').val("1"); //ie on
                                $('#' + parentId + " #outputData").html("on" + uid[1]);

                            }
                        } else {
                            // $('#overrideData').val("2");//ie auto
                            // $("#outputData").html(output+"- "+uid[1]);
                            if ($('#lightingStatus i').length > 0) {
                                $('#lightingStatus').find('i').remove();
                            }

                            $('#' + parentId + ' #overrideData').val("2"); //ie auto
                            $('#' + parentId + " #outputData").html(output + "- " + uid[1]);
                        }
                    } else {
                        if (uid[2] != null) {
                            $(uid[2] + " option").each(function() {
                                if (uid[2] == "#Panel #photocellInnerData") {
                                    photocellInnerFlag = output;
                                }
                                if (output == $(this).text() || output == $(this).text().replace(/ /g, '')) {
                                    $(uid[2]).val($(this).val());

                                    if (uid[2] == "#Panel #photocellInfoData" || uid[2] == "#Group #photocellInfoData") {

                                        // var photoCellInfoVal=$('.photocellInfoData').val()
                                        var photoCellInfoVal;
                                        if (uid[2] == "#Panel #photocellInfoData") {
                                            photoCellInfoVal = $('#Panel #photocellInfoData').val()
                                        } else {
                                            photoCellInfoVal = $('#Group #photocellInfoData').val()
                                        }

                                        if (photoCellInfoVal == 'ext') { // $('#photocellInnerData option').remove();
                                            $('#Panel #photocellInnerData option').remove();
                                            $('#Group #photocellInnerData option').remove();
                                            for (var i = 1; i <= extCntVal; i++) {
                                                // $('#photocellInnerData').append("<option value="+i+" >Exterior"+i+"</option>");
                                                $('#Panel #photocellInnerData').append("<option value=Exterior" + i + ">Exterior" + i + "</option>");
                                                $('#Group #photocellInnerData').append("<option value=Exterior" + i + " >Exterior" + i + "</option>");

                                            }
                                            $('#Panel #photocellInnerData').val(photocellInnerFlag)


                                        }
                                        if (photoCellInfoVal == 'int') { //$('#photocellInnerData option').remove();
                                            $('#Panel #photocellInnerData option').remove();
                                            $('#Group #photocellInnerData option').remove();
                                            for (var i = 1; i <= intCntVal; i++) {
                                                //  $('#photocellInnerData').append("<option value="+i+" >Interior"+i+"</option>");
                                                $('#Panel #photocellInnerData').append("<option value=Interior" + i + ">Interior" + i + "</option>");
                                                $('#Group #photocellInnerData').append("<option value=Interior" + i + ">Interior" + i + "</option>");

                                            }
                                            $('#Panel #photocellInnerData').val(photocellInnerFlag);


                                        }
                                        if (photoCellInfoVal == 'deck') { //$('#photocellInnerData option').remove();
                                            $('#Panel #photocellInnerData option').remove();
                                            $('#Group #photocellInnerData option').remove();

                                            for (var i = 1; i <= deckCntVal; i++) {
                                                $('#Panel #photocellInnerData').append("<option value=Interior" + i + ">Deck" + i + "</option>");
                                                $('#Group #photocellInnerData').append("<option value=Interior" + i + " >Deck" + i + "</option>");

                                            }
                                            $('#Panel #photocellInnerData').val(photocellInnerFlag)

                                        }
                                        if (photoCellInfoVal == 'none') {
                                            // $('#photocellInnerData option').remove();
                                            $('#Panel #photocellInnerData option').remove();
                                            $('#Group #photocellInnerData option').remove();

                                            // $('#photocellInnerData').append("<option value='0' >None</option>");
                                            $('#Panel #photocellInnerData').append("<option value='0' >None</option>");
                                            $('#Group #photocellInnerData').append("<option value='0' >None</option>");

                                        }

                                    } //end of uid[2] photocellInfoData check


                                }

                            });

                        } else {
                            // if (['#effectiveEndData', '#effectiveStartData'].indexOf(uid[0]) !== -1) {
                            //   if (output != 0) {
                            //     $(uid[0]).html(output);
                            //   }
                            // } else if (uid[0] === '#photocellCommandData'){

                            //   var dataz = $('#photocellCommandData').data();

                            //   if (dataz && dataz.nodePath === parentUID) {
                            //     var outputz = output === "true" ? output : dataz.value;
                            //     $('#photocellCommandData').html(outputz);
                            //   }

                            //   $('#photocellCommandData').data({
                            //     nodePath: parentUID,
                            //     value: output
                            //   });

                            // } else {
                            $(uid[0]).html(output);
                            //}
                        }
                    }


                });
            } //end of if parent uid condition


        },
        setRemoteOverideXML: function(ord, data, booleanVal) {
            var xml = "<ProphetRequest version='1'>" +
                "<Method name='invoke' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + ord + "</nodeId>" +
                "<data>" + data + "</data>" +
                "<action>Set</action>" +
                "<parameter>" + booleanVal + "</parameter>" +
                "</Method>" + "</ProphetRequest>";
            return xml;
        },
        insertCommas: function(n) {
            var s = Math.round(n * Math.pow(10, 2)) / Math.pow(10, 2); // 2 decimal places
            var s = s.toString();
            var ssplt = s.split(".");
            s = Number(ssplt[0]).toLocaleString();
            s = s.replace(/\..+/, "");
            return s + "." + (ssplt[1] || "00"); // if only integer numbers required simply return s;
        },
        extractTableMallResponse: function(req, cb) {
            $.niagara.getTable("testPath", req, function(xml) {

                var data = $util.parseTableXml(xml);

                if ( !! data.rows.length) {
                    queryActiveTempAndStatusForNodes(data);
                }

                scheduleSummaryHVAC('Mall', data);

                $('#EquipmentTables #MallUnits tbody').empty();
                $('#EquipmentTables #MallUnits').append(TMPLS.equipmentListRows(data.rows));

                /* hvacDebug!! */
                $('#EquipmentTables #MallUnits tr').click(function() {

                    var unitData = $(this).data();
                    if (unitData.isSelected) {
                        $(this).toggleClass('selected');
                        $('#settingsRow').toggle();
                    } else {
                        $('#MallUnits tr').attr("isSelected", "false");
                        $(this).attr("isSelected", "true");

                        var unitPath = unitData.nodeId;
                        $('.graphicHVACView').attr({
                            href: '/ord?station:%7C' + unitPath + '%7Cview:pxViewEquip',
                            target: '_blank'
                        });

                        $.each(window.equipTables_Intervals, function(i, e) {
                            clearInterval(e);
                        })
                        window.equipTables_Intervals = [];

                        $("#colright").empty();
                        $("#colleft").empty().append($util.loaderHTML);

                        if ($('#content').width() <= 1300) {

                            $('#settingsRow').remove();
                            var hvacTableSettings = $('#bodyHVAC #lightingData').html();
                            $(this).after('<tr id="settingsRow"><td colspan="10"></td></tr>');
                            $('#settingsRow td').append(hvacTableSettings);

                        }
                        var data = $(this).data();
                        var slotPath = data.nodeId;
                        var unitText = data.name;

                        var unitNavReq = $util.getNode(slotPath);
                        $hvacUtil.hvacUnitDataPlot(unitNavReq, unitText, slotPath);

                        var url = '/ord?station:%7C' + slotPath + '%7Cview:pxViewShort';

                        $(".hvac-equip tr").removeClass('highlight');
                        $(this).addClass('highlight');

                        $('#hvacTableiFrame').attr('src', url);
                    }
                });

                if (cb) {
                    cb();
                }

            });

        },
        extractTableMiscResponse: function(req, cb) {
            $.niagara.getTable("testPath", req, function(obj) {

                var data = $util.parseTableXml(obj);

                if ( !! data.rows.length) {
                    queryActiveTempAndStatusForNodes(data);
                }

                scheduleSummaryHVAC('Miscellaneous', data);

                $('#EquipmentTables #MiscellaneousUnits tbody').empty();
                $('#EquipmentTables #MiscellaneousUnits').append(TMPLS.equipmentListRows(data.rows));

                $('#EquipmentTables #MiscellaneousUnits tr').click(function() {

                    var unitData = $(this).data();
                    if (unitData.isSelected) {
                        $('#settingsRow').toggle();
                    } else {
                        $('#MiscellaneousUnits tr').attr("isSelected", "false");
                        $(this).attr("isSelected", "true");
                        var unitPath = unitData.nodeId;

                        $('.graphicHVACView').attr({
                            'href': '/ord?station:%7C' + unitPath + '%7Cview:pxViewEquip',
                            'target': '_blank'
                        });

                        if ($('#content').width() <= 1300) {

                            $('#settingsRow').remove();
                            var hvacTableSettings = $('#bodyHVAC #lightingData').html();
                            $(this).after('<tr id="settingsRow"><td colspan="10"></td></tr>');
                            $('#settingsRow td').append(hvacTableSettings);

                        }

                        var unitText = unitData.name;
                        var unitNavReq = $util.getNode(unitPath);
                        $hvacUtil.hvacUnitDataPlot(unitNavReq, unitText, unitPath);

                        var url = '/ord?station:%7C' + unitPath + '%7Cview:pxViewShort';

                        $(".hvac-equip tr").removeClass('highlight');
                        $(this).addClass('highlight');

                        $('#hvacTableiFrame').attr('src', url);
                    }
                });

                if (cb) {
                    cb();
                }

            });

        }, //for tenant units
        extractTableTenantResponse: function(req, cb) {
            $.niagara.getTable("testPath", req, function(obj) {

                var data = $util.parseTableXml(obj);

                if ( !! data.rows.length) {
                    queryActiveTempAndStatusForNodes(data);
                }

                scheduleSummaryHVAC('Tenant', data);

                $('#EquipmentTables #TenantUnits tbody').empty();
                $('#EquipmentTables #TenantUnits').append(TMPLS.equipmentListRows(data.rows));

                $("#EquipmentTables #TenantUnits tr").not(":first").click(function() {

                    var unitData = $(this).data();
                    if (unitData.isSelected) {
                        $('#settingsRow').toggle();
                    } else {
                        $('#TenantUnits tr').attr("isSelected", "false");
                        $(this).attr("isSelected", "true");
                        var unitPath = unitData.nodeId;

                        $('.graphicHVACView').attr({
                            'href': '/ord?station:%7C' + unitPath + '%7Cview:pxViewEquip',
                            'target': '_blank'
                        });

                        if ($('#content').width() <= 1300) {

                            $('#settingsRow').remove();
                            var hvacTableSettings = $('#bodyHVAC #lightingData').html();
                            $(this).after('<tr id="settingsRow"><td colspan="10"></td></tr>');
                            $('#settingsRow td').append(hvacTableSettings);

                        }

                        var unitText = unitData.name;

                        var unitNavReq = $util.getNode(unitPath);
                        $hvacUtil.hvacUnitDataPlot(unitNavReq, unitText, unitPath);
                        var url = '/ord?station:%7C' + unitPath + '%7Cview:pxViewShort';

                        $(".hvac-equip tr").removeClass('highlight');
                        $(this).addClass('highlight');

                        $('#hvacTableiFrame').attr('src', url);
                    }
                });

                if (cb) {
                    cb();
                }

            });

        },
        extractLightingTableResponse: function(req, LChosen, param_value, parentId, rename) {
            var flag;
            var newDataFinal = [];
            $.niagara.getTable("testPath", req, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var xml = obj;
                var rowCnt = 0;
                var newData = [];
                $(xml).find("r").each(function() {
                    var row = [];
                    var r = $(this);
                    var k = 0;
                    $(r).find("c").each(function() {
                        c = $(this);
                        if (k == 0) {
                            var d = c.text();
                            row.push(d);
                        }
                        if (k == 1) {
                            var f = c.text();
                            row.push(f);
                        }
                        if (k == 2) {
                            var f = c.text();
                            row.push(f);

                        }
                        if (k == 3) {
                            var f = c.text();
                            row.push(f);

                        }
                        if (k == 4) {
                            var f = c.text();
                            row.push(f);
                        }
                        if (k == 5) {
                            var f = c.text();
                            row.push(f);

                        }
                        k++;
                    });

                    newData.push(row);
                });

                if (rename) {
                    var lineNumber = $('#lightingAcc p.active').attr('data-linenumber');

                    $(LChosen).next().empty();
                    $('.ulLiMenu > ul > li > div').not(LChosen).removeClass('active');
                    //$(LChosen).toggleClass('active');
                    ////


                } else {
                    $(LChosen).next().empty();
                }

                $(LChosen).next().empty();

                $(LChosen).next().prepend('<li id="headingsLi">' +
                    '<div id="headings">' +
                    '<p>Status</p>' +
                    '<p>Circuit #</p>' +
                    '<p>Display Name</p>' +
                    '<p>Schedule</p>' +

                    '<p>Output</p>' +
                    '</div>' +
                    '</li>');

                for (var i = 0; i < newData.length; i++) {
                    var status = newData[i][5];
                    if (status !== 'ok' && status !== '{null}' && status.length !== 0) {
                        $(LChosen).next().append('<li><p id="' + newData[i][0] + '" data-lineNumber="' + i + '" value="' + newData[i][1] + '"><span class="four"><i id=equipData' + newData[i][0] + '" class="icon icon-dot status-' + status + '" title="' + status + '"></i></span><span class="one">' + newData[i][2] + '</span><span class="two">' + newData[i][1] + '</span><span class="three">' + newData[i][3] + '</span><span class="four">' + newData[i][4] + '</span></p></li>');
                    } else {
                        $(LChosen).next().append('<li><p id="' + newData[i][0] + '" data-lineNumber="' + i + '" value="' + newData[i][1] + '"><span class="four"></span><span class="one">' + newData[i][2] + '</span><span class="two">' + newData[i][1] + '</span><span class="three">' + newData[i][3] + '</span><span class="four">' + newData[i][4] + '</span></p></li>');
                    }
                }

                if (rename) {
                    $('#lightingAcc p[data-lineNumber=' + lineNumber + ']').addClass('active');
                }

                $('.ulLiMenu > ul > li > ul > li > p').on('click', function() {

                    var pLicked = $(this);

                    $('#photocellCommandData, #effectiveEndData, #effectiveStartData, #outputData').html('<img src="img/loading-16.gif">');


                    $('.ulLiMenu > ul > li > ul > li > p').not(this).removeClass('active');
                    $(this).addClass('active');

                    if ($('#content').width() <= 1300) {

                        $('#lightingDataLiNow').remove();
                        var lightingDataNow = $('#bodyLighting #lightingData').html();

                        pLicked.parent().after('<li id="lightingDataLiNow"></li>');
                        $('#lightingDataLiNow').append(lightingDataNow);


                    }

                    if (window.lighting_pollIntervals) {
                        $.each(window.lighting_pollIntervals, function(i, e) {
                            clearInterval(e);
                        });
                    }



                    $('.veil').css('display', 'none');

                    var CId = $(this).attr('id');
                    var panelText = $(this).parent().parent().parent().find('p:first').text();

                    ordClicked = CId;
                    var CValue = $(this).attr('value');

                    var Circuittext = $(this).children('span:first').text();

                    var Ctext = Circuittext.replace("C", "Circuit ");

                    $('#' + parentId + ' #circuitNameData').text(panelText + ":" + Ctext);
                    $('#' + parentId + ' #displayNameData').text(CValue);

                    var sunData = CId.split("/Unknown");
                    sunData = sunData[0];


                    var subscribePoints = [{
                            uid: "#sunriseData" + "-" + Circuittext,
                            nodeId: param_value + "/Scheduling",
                            data: "prophetData:Haystack/schedules/sunrise"
                        }, {
                            uid: "#sunsetData" + "-" + Circuittext,
                            nodeId: param_value + "/Scheduling",
                            data: "prophetData:Haystack/schedules/sunset"
                        }, {
                            uid: "#Panel #overrideData" + "-" + Circuittext,
                            nodeId: CId,
                            data: "prophetData:Haystack/lighting/boolean/lightingCmdBool"
                            //data: "prophetData:GGP/Scheduling/lightingControlOut"
                        }, {
                            uid: "#zoneOpt" + "-" + Circuittext + "-#" + parentId + " #zoneData",
                            nodeId: CId,
                            data: "prophetData:Haystack/schedules/string/zone"
                        }, {
                            uid: "#groupOpt" + "-" + Circuittext + "-#" + parentId + " #groupData",
                            nodeId: CId,
                            data: "prophetData:Haystack/schedules/string/group"
                        }, {
                            uid: "#schedulingOpt" + "-" + Circuittext + "-#" + parentId + " #schedulingData",
                            nodeId: CId,
                            data: "prophetData:Haystack/schedules/string/schedule"
                        }, { // old                                                               // uses either old or new for now
                            uid: "#effectiveStartData" + "-" + Circuittext,
                            nodeId: CId,
                            data: "prophetData:Haystack/schedules/string/effectiveStartLtg"
                        },
                        // { // new
                        //     uid: "#effectiveStartData" + "-" + Circuittext,
                        //     nodeId: CId,
                        //     data: "prophetData:GGP/Scheduling/scheduleStart"
                        // },
                        { // old
                            uid: "#effectiveEndData" + "-" + Circuittext,
                            nodeId: CId,
                            data: "prophetData:Haystack/schedules/string/effectiveEndLtg"
                        },
                        // { // new
                        //     uid: "#effectiveEndData" + "-" + Circuittext,
                        //     nodeId: CId,
                        //     data: "prophetData:GGP/Scheduling/scheduleEnd"
                        // },
                        { // old
                            uid: "#photocellCommandData" + "-" + Circuittext,
                            nodeId: CId,
                            data: "prophetData:Haystack/schedules/boolean/photocellEnable_multi"
                        },
                        // { // new
                        //     uid: "#photocellCommandData" + "-" + Circuittext,
                        //     nodeId: CId,
                        //     data: "prophetData:GGP/Scheduling/photocell/photocellEnable"
                        // },
                        {
                            uid: "#photocellOpt" + "-" + Circuittext + "-#photocellData",
                            nodeId: CId,
                            data: "prophetData:Haystack/schedules/string/photocell"
                        }, {
                            uid: "#photocellOptInfo" + "-" + Circuittext + "-#" + parentId + " #photocellInfoData",
                            nodeId: CId,
                            data: "prophetData:Haystack/schedules/string/photocell"
                        }, {
                            uid: "#photocellOptInnerInfo" + "-" + Circuittext + "-#" + parentId + " #photocellInnerData",
                            nodeId: CId,
                            data: "prophetData:Haystack/schedules/string/photocellFlag"
                        }, {
                            uid: "#specialOpt" + "-" + Circuittext + "-#" + parentId + " #specialEventData",
                            nodeId: CId,
                            data: "prophetData:Haystack/schedules/string/specialEvent"
                        }
                    ];
                    var uid = CId;
                    globalOrd.push(uid); //push all the ords that are clicked
                    var req = $util.subscribeLightingReq(subscribePoints, uid);
                    $util.subscribeLightingArr(req, uid, globalOrd, parentId);

                }); //inner active li end

            });


        },

        extractLightingGroupTableResponse: function(req, LChosen, param_value, parentId) {
            var flag;
            var newDataFinal = [];
            $.niagara.getTable("testPath", req, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var xml = obj;
                var rowCnt = 0;
                var newData = [];
                $(xml).find("r").each(function() {
                    var row = [];
                    var r = $(this);
                    var k = 0;
                    $(r).find("c").each(function() {
                        c = $(this);
                        if (k == 0) {
                            var d = c.text();
                            row.push(d);
                        }
                        if (k == 1) {
                            var f = c.text();
                            row.push(f);
                        }
                        if (k == 2) {
                            var f = c.text();
                            row.push(f);

                        }
                        if (k == 3) {
                            var f = c.text();
                            row.push(f);

                        }
                        if (k == 4) {
                            var f = c.text();
                            row.push(f);
                        }
                        if (k == 5) {
                            var f = c.text();
                            row.push(f);

                        }
                        k++;
                    });

                    newData.push(row);
                });

                $(LChosen).next().empty();

                if (newData.length > 0) {

                    $(LChosen).next().prepend('<li id="headingsLi">' +
                        '<div id="headings">' +
                        '<p>Circuit #</p>' +
                        '<p>Description</p>' +
                        '<p>Schedule</p>' +
                        '<p>Output</p>' +
                        '</div>' +
                        '</li>');

                    for (var i = 0; i < newData.length; i++) {
                        $(LChosen).next().append('<li><p id="' + newData[i][2] + '" value="' + newData[i][3] + '"><span class="one">' + newData[i][0] + ":" + newData[i][1] + '</span><span class="two">' + newData[i][3] + '</span><span class="three">' + newData[i][4] + '</span><span class="four">' + newData[i][5] + '</span></p></li>');
                    }

                } else {
                    $(LChosen).next().prepend('<li><p>&nbsp;There are no circuits here.</p></li>');
                }

                $('.ulLiMenu > ul > li > ul > li > p').on('click', function() {
                    var pLicked = $(this);

                    if ($('#content').width() <= 1300) {

                        $('#lightingDataLiNow').remove();
                        var lightingDataNow = $('#bodyLighting #lightingData').html();
                        $('#bodyLighting #lightingData').css({
                            'position': 'absolute',
                            'left': '9999px',
                            'top': '0'
                        }).removeClass('keepSeen');

                        pLicked.parent().after('<li id="lightingDataLiNow"></li>');
                        $('#lightingDataLiNow').append(lightingDataNow);


                    }


                    $('.ulLiMenu > ul > li > ul > li > p').not(this).removeClass('active');
                    $(this).addClass('active');

                    $('.veil').css('display', 'none');

                    var CId = $(this).attr('id');

                    ordClicked = CId;
                    var CValue = $(this).attr('value');
                    var Circuittext = $(this).children('span:first').text();
                    //  var Ctext = Circuittext.replace("C", "Circuit ");
                    var Ctext = Circuittext;

                    $('#' + parentId + ' #circuitNameData').text(Circuittext);
                    $('#' + parentId + ' #displayNameData').text(CValue);

                    var sunData = CId.split("/Unknown");
                    sunData = sunData[0];


                    var subscribePoints = [{
                        uid: "#Group #sunriseData" + "-" + Circuittext,
                        nodeId: param_value + "/Scheduling",
                        data: "prophetData:Haystack/schedules/sunrise"
                    }, {
                        uid: "#Group #sunsetData" + "-" + Circuittext,
                        nodeId: param_value + "/Scheduling",
                        data: "prophetData:Haystack/schedules/sunset"
                    }, {
                        uid: "#Group #overrideData" + "-" + Circuittext,
                        nodeId: CId,
                        data: "prophetData:Haystack/lighting/boolean/lightingCmdBool"
                        //data: "prophetData:GGP/Scheduling/lightingControlOut"
                    }, {
                        uid: "#Group #zoneOpt" + "-" + Circuittext + "-#" + parentId + " #zoneData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/zone"
                    }, {
                        uid: "#Group #groupOpt" + "-" + Circuittext + "-#" + parentId + " #groupData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/group"
                    }, {
                        uid: "#Group #schedulingOpt" + "-" + Circuittext + "-#" + parentId + " #schedulingData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/schedule"
                    }, {
                        uid: "#Group #effectiveStartData" + "-" + Circuittext,
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/effectiveStartLtg"
                    }, {
                        uid: "#Group #effectiveEndData" + "-" + Circuittext,
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/effectiveEndLtg"
                    }, {
                        uid: "#Group #photocellCommandData" + "-" + Circuittext,
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/boolean/photocellEnable"
                    }, {
                        uid: "#Group #photocellOpt" + "-" + Circuittext + "-#" + parentId + " #photocellData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/photocell"
                    }, {
                        uid: "#Group #photocellOptInfo" + "-" + Circuittext + "-#" + parentId + " #photocellInfoData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/photocell"
                    }, {
                        uid: "#Group #photocellOptInner" + "-" + Circuittext + "-#" + parentId + " #photocellInnerData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/photocellFlag"
                    }, {
                        uid: "#Group #specialOpt" + "-" + Circuittext + "-#" + parentId + " #specialEventData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/specialEvent"
                    }];
                    var uid = CId;
                    globalOrd.push(uid); //push all the ords that are clicked
                    var req = $util.subscribeLightingReq(subscribePoints, uid);
                    $util.subscribeLightingArr(req, uid, globalOrd, parentId);

                }); //inner active li end

            });


        },
        extractLightingGroupTableResponse1: function(req, LChosen, parentId, param_value) {
            var flag; //responseQuery,LChosen,tabClicked,param_value
            var newDataFinal = [];
            $.niagara.getTable("testPath", req, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var xml = obj;
                var rowCnt = 0;
                var newData = [];
                $(xml).find("r").each(function() {
                    var row = [];
                    var r = $(this);
                    var k = 0;
                    $(r).find("c").each(function() {
                        c = $(this);
                        if (k == 0) {
                            var d = c.text();
                            row.push(d);
                        }
                        if (k == 1) {
                            var f = c.text();
                            row.push(f);
                        }
                        if (k == 2) {
                            var f = c.text();
                            row.push(f);

                        }
                        if (k == 3) {
                            var f = c.text();
                            row.push(f);

                        }
                        if (k == 4) {
                            var f = c.text();
                            row.push(f);
                        }
                        if (k == 5) {
                            var f = c.text();
                            row.push(f);

                        }
                        k++;
                    });

                    newData.push(row);
                });


                var lineNumber = $('#' + parentId + " #lightingAcc p.active").attr('data-linenumber');

                $(LChosen).next().empty();
                $('.ulLiMenu > ul > li > div').not(LChosen).removeClass('active');
                //$(LChosen).toggleClass('active');
                ////

                $(LChosen).next().prepend('<li id="headingsLi">' +
                    '<div id="headings">' +
                    '<p>Circuit #</p>' +
                    '<p>Display Name</p>' +
                    '<p>Schedule</p>' +
                    '<p>Output</p>' +
                    '</div>' +
                    '</li>');

                for (var i = 0; i < newData.length; i++) {
                    $(LChosen).next().append('<li><p id="' + newData[i][2] + '" value="' + newData[i][3] + '"><span class="one">' + newData[i][0] + ":" + newData[i][1] + '</span><span class="two">' + newData[i][3] + '</span><span class="three">' + newData[i][4] + '</span><span class="four">' + newData[i][5] + '</span></p></li>');
                }
                $('#lightingAcc p[data-lineNumber=' + lineNumber + ']').addClass('active');

                $('.ulLiMenu > ul > li > ul > li > p').on('click', function() {
                    var pLicked = $(this);
                    $('.ulLiMenu > ul > li > ul > li > p').not(this).removeClass('active');
                    $(this).addClass('active');

                    if ($('#content').width() <= 1300) {

                        $('#lightingDataLiNow').remove();
                        var lightingDataNow = $('#bodyLighting #lightingData').html();

                        pLicked.parent().after('<li id="lightingDataLiNow"></li>');
                        $('#lightingDataLiNow').append(lightingDataNow);


                    }

                    $('.veil').css('display', 'none');

                    var CId = $(this).attr('id');

                    ordClicked = CId;
                    var CValue = $(this).attr('value');
                    var Circuittext = $(this).children('span:first').text();
                    //  var Ctext = Circuittext.replace("C", "Circuit ");
                    var Ctext = Circuittext;
                    $('#' + parentId + ' #circuitNameData').text(Circuittext);
                    $('#' + parentId + ' #displayNameData').text(CValue);

                    var sunData = CId.split("/Unknown");
                    sunData = sunData[0];


                    var subscribePoints = [{
                        uid: "#Group #sunriseData" + "-" + Circuittext,
                        nodeId: param_value + "/Scheduling",
                        data: "prophetData:Haystack/schedules/sunrise"
                    }, {
                        uid: "#Group #sunsetData" + "-" + Circuittext,
                        nodeId: param_value + "/Scheduling",
                        data: "prophetData:Haystack/schedules/sunset"
                    }, {
                        uid: "#Group #overrideData" + "-" + Circuittext,
                        nodeId: CId,
                        data: "prophetData:Haystack/lighting/boolean/lightingCmdBool"
                        //data: "prophetData:GGP/Scheduling/lightingControlOut"
                    }, {
                        uid: "#Group #zoneOpt" + "-" + Circuittext + "-#" + parentId + " #zoneData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/zone"
                    }, {
                        uid: "#Group #groupOpt" + "-" + Circuittext + "-#" + parentId + " #groupData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/group"
                    }, {
                        uid: "#Group #schedulingOpt" + "-" + Circuittext + "-#" + parentId + " schedulingData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/schedule"
                    }, {
                        uid: "#Group #effectiveStartData" + "-" + Circuittext,
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/effectiveStartLtg"
                    }, {
                        uid: "#Group #effectiveEndData" + "-" + Circuittext,
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/effectiveEndLtg"
                    }, {
                        uid: "#Group #photocellCommandData" + "-" + Circuittext,
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/boolean/photocellEnable"
                    }, {
                        uid: "#Group #photocellOpt" + "-" + Circuittext + "-#" + parentId + " #photocellData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/photocell"
                    }, {
                        uid: "#Group #photocellOptInfo" + "-" + Circuittext + "-#" + parentId + " #photocellInfoData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/photocell"
                    }, {
                        uid: "#Group #photocellOptInner" + "-" + Circuittext + "-#" + parentId + " #photocellInnerData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/photocellFlag"
                    }, {
                        uid: "#Group #specialOpt" + "-" + Circuittext + "-#" + parentId + " #specialEventData",
                        nodeId: CId,
                        data: "prophetData:Haystack/schedules/string/specialEvent"
                    }];
                    var uid = CId;
                    globalOrd.push(uid); //push all the ords that are clicked
                    var req = $util.subscribeLightingReq(subscribePoints, uid);
                    $util.subscribeLightingArr(req, uid, globalOrd, parentId);

                }); //inner active li end

            });


        },
        extractPowerTableResponse: function(req) {
            $.niagara.getTable("testPath", req, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var xml = obj;
                var rowCnt = 0;
                var newData = [];
                $(xml).find("r").each(function() {
                    var row = [];
                    var r = $(this);
                    var k = 0;
                    $(r).find("c").each(function() {
                        c = $(this);
                        if (k == 0) {
                            var d = c.text();
                            row.push(d);
                        }
                        if (k == 1) {
                            var f = c.text();
                            var result = Math.round(f * Math.pow(10, 2)) / Math.pow(10, 2);
                            result = result / 1000;
                            row.push(result);
                        }
                        if (k == 2) {
                            var f = c.text();
                            var result = Math.round(f * Math.pow(10, 2)) / Math.pow(10, 2);
                            result = parseInt(result);
                            row.push(result);

                        }
                        if (k == 3) {
                            var f = c.text();
                            row.push(f);

                        }


                        k++;
                    });

                    newData.push(row);
                });
                for (var i = 0; i < newData.length; i++) {
                    $('<tr>').append($('<td id="' + newData[i][3] + '">').html(newData[i][0]))
                        .append($('<td>').text(newData[i][1] + ' kW'))
                        .append($('<td>').html(newData[i][2] + ' kWh'))
                        .appendTo('#powerTable');

                }
                $('tr').not(':first, .accordionInner tr').on('click', function() {

                    $('tr').removeClass('highlight');
                    $(this).addClass('highlight');
                });
                $('table.forGage tr').not(':first').on('click', function() {
                    // var sem = $(this).children('td:first-child').text();
                    // var power = $(this).children('td:nth-child(2)').text().replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
                    // var energy = $(this).children('td:nth-child(3)').text().replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
                    // $('#powerGauges h2').text(sem);
                    // gauges.powerData.setValue(power);
                    // gauges.energyData.setValue(energy);
                });

                $('tr').not(':first').on('click', function() {
                    $('.veil').animate({
                        opacity: 0
                    }, 200, 'linear', function() {
                        $('.veil').css('display', 'none');

                    });
                });

            });

        },
        extractPowerTableParentNodes: function(req) {

            $.niagara.getChildNodes("testpath", req, function(obj) {

                var xml = obj;
                var nodeValArr = $util.getPowerNodeArr(xml);
                var statusQuery = [];
                statusQuery.callback = function(data) {
                    _.each(data, function(d) {
                        if (d.value !== undefined && d.value !== 'ok') {
                            $('#' + d.uid + '').append('<i class="icon icon-dot status-' + d.value + '" title="' + d.value + '" style="padding-left: 31px;"></i>');
                        }

                    });
                }
                var rowHighlight = $('#powerTable').find('.highlight').index() + 1;
                $("#powerTable").find("tr:gt(0)").remove(); //prevent from removing the first row
                for (var i = 0; i < nodeValArr.length; i++) {

                    statusQuery.push({
                        uid: nodeValArr[i][0],
                        nodeId: nodeValArr[i][1],
                        data: "prophetData:GGP/Equipment/string/StatusString"
                    });
                    $('#powerTable').append('<tr class="power"> <td id="' + nodeValArr[i][0] + '"style="width:23%"> </td> <td id="' + nodeValArr[i][1] + '">' +  checkNull(nodeValArr[i][0]) + '</td> <td data-id=' + nodeValArr[i][1] + ' class="editLoc" style="width:45%;"><span class="LocationEdit">' +  checkNull(nodeValArr[i][2]) + '</span></td>  <td data-id=' + nodeValArr[i][1] + ' id="' +  checkNull(nodeValArr[i][3]) + '" class="editAcc"><span class="LocationEdit">' +  checkNull(nodeValArr[i][3]) + '</span></td> </tr> ');
                }

                function checkNull(value){
                     if(value!==undefined){
                        return value;
                     }else{
                        return "";
                     }
                }
                dataEye.getDataValuesForNodes(statusQuery);
                var rowHighlight = $('.power').find('.highlight').index() + 1;
                //$("#powerTable").find("tr:gt(0)").remove(); //prevent from removing the first row

                if (rowHighlight != 0) {
                    $('#power').find('tr:nth-child(' + rowHighlight + ')').addClass('highlight');
                }

                //Edit logic

                $('#powerTable tr').on('click', '#editLocationId,#editAccountId', function(e) {
                    var elem = $(this).prev(); // elem = $('p');
                    editingText = elem.html();
                    elem.empty();
                    elem.html('<input type="text" value="' + editingText + '" class="panelTextBoxParent" style="width:50%">');
                    $('.panelTextBoxParent').focus();
                    $(this).parent().append('<span class="editPower checkboxingNowPower" id="panelCheckingboxingnow"><i class="fa fa-check"></i></span><span class="editPower XBoxPower" style="right: -4px"><i class="fa fa-times"></i></span>');
                    $(this).remove();
                    e.stopPropagation()
                });


                $('#powerTable tr').on('click', '#panelCheckingboxingnow', function(e) {
                   //Logic to save attibute
                    var powerNodeid = $(this).parent().attr('data-id');
                    var powerAttrRes;
                    if ($(this).parent().attr('class') === "editAcc") {
                        powerAttrRes = $util.setAttributesXML(powerNodeid, "disAccountNumber", $(this).parent().find('input').val());
                    } else {
                        powerAttrRes = $util.setAttributesXML(powerNodeid, "disLoc", $(this).parent().find('input').val());
                    }

                    $util.setAttributes(powerAttrRes, powerNodeid);
                    $(this).parent().find('.LocationEdit').html($('.panelTextBoxParent').val());
                    if ($(this).parent().attr('class') === "editAcc") {
                        $(this).parent().find('span.checkboxingNowPower').removeClass('checkboxingNowPower').removeAttr("id").attr('id', 'editAccountId').addClass('startEdit').html('<i class="fa fa-pencil-square-o"></i>');
                    } else {
                        $(this).parent().find('span.checkboxingNowPower').removeClass('checkboxingNowPower').removeAttr("id").attr('id', 'editAccountId').addClass('startEdit').html('<i class="fa fa-pencil-square-o"></i>');
                    }
                    $(this).parent().find('.XBoxPower').remove();
                    e.stopPropagation()
                });

                $('.editLoc span').on('click', '.panelTextBoxParent', function(e) {
                    e.stopPropagation();
                });
                $('.editAcc span').on('click', '.panelTextBoxParent', function(e) {
                    e.stopPropagation();
                });
                $('#powerTable tr').on('click', '.XBoxPower', function(e) {
                    
                    $(this).parent().find('.LocationEdit').html($(this).parent().find('input').val());
                    if ($(this).parent().attr('class') === "editAcc") {
                        $(this).parent().find('span.checkboxingNowPower').removeClass('checkboxingNowPower').removeAttr("id").attr('id', 'editAccountId').addClass('startEdit').html('<i class="fa fa-pencil-square-o"></i>');
                    } else {
                        $(this).parent().find('span.checkboxingNowPower').removeClass('checkboxingNowPower').removeAttr("id").attr('id', 'editAccountId').addClass('startEdit').html('<i class="fa fa-pencil-square-o"></i>');
                    }

                    $(this).parent().find('.XBoxPower').remove();
                    e.stopPropagation();
                });

                $('tr').not(':first, .accordionInner tr,#editLocationId,.panelTextBoxParent').click(function(e) {
                    //clickPowerTableRow = $(this);
                    if (powertable.loading === "false") {

                        $('tr').removeClass('highlight');
                       var inputLength=$('.panelTextBoxParent');
                        if($('.panelTextBoxParent').length!==0){
                            for(i=0;i<inputLength.length;i++){
                                $(inputLength[i]).parent().html($(inputLength[i]).val());
                            }
                             
                        }else{
                             $(this).find("span.LocationEdit").html($('.panelTextBoxParent').val());
                        }
                        
                        $('tr>td.editLoc>span.editPower').remove();
                        $('tr>td.editAcc>span.editPower').remove();
                        $(this).addClass('highlight');
                        
                        //$(this).find('td.editLoc').append('<span id="editLocationId" class="editPower"></span>');
                        $(this).find('td.editLoc').append('<span id="editLocationId" class="editPower"><i class="fa fa-pencil-square-o"></i></span>');
                        $(this).find('td.editAcc').append('<span id="editAccountId" class="editPower"><i class="fa fa-pencil-square-o"></i></span>');
                        
                        //plot graph for parent nodes
                        //var name = $(this).find('td:nth-child(2)').text();
                        //powerMeters(nodeValArr, name);
                    }
                   
                });

            });


        },


        extractPowerTableChildNodes: function(req, LChosen, param_value, parentId, rename) {
            var color = ['red', 'blue', 'green'];
            $.niagara.getTable("testPath", req, function(obj) {

                var xmlDoc = $.parseXML(obj);
                var xml = obj;
                var rowCnt = 0;
                var newData = [];

                $(xml).find("r").each(function() {
                    var row = [];
                    var r = $(this);
                    var k = 0;
                    $(r).find("c").each(function() {
                        c = $(this);
                        if (k == 0) {
                            var d = c.text();
                            if(d!==undefined){
                            row.push(d);
                            }else{
                                row.push("");
                            }
                        }
                        if (k == 1) {
                            var f = c.text();
                            if(f!==undefined){
                              row.push(f);
                            }else{
                              row.push("");
                            }
                            
                        }
                        if (k == 2) {
                            var f = c.text();
                            var result = Math.round(f * Math.pow(10, 2)) / Math.pow(10, 2);
                            result = result / 1000;
                            if(result!==undefined){
                               row.push(result.toFixed(0));
                            }else{
                                 row.push("");
                            }
                           
                        }
                        if (k == 3) {
                            var f = c.text();
                            var result = Math.round(f * Math.pow(10, 2)) / Math.pow(10, 2);
                             if(result!==undefined){
                               row.push(result.toFixed(0));
                            }else{
                                 row.push("");
                            }
                        }
                        if (k == 4) {
                            var f = c.text();
                            f = f.split(',');
                            var val;
                            var tagArr = [];
                            for (var i = 0; i < f.length; i++) {
                                val = f[i];
                                //val = val.substring(0, 1);
                                //val = val.toUpperCase();
                                tagArr.push(val);
                            }
                        
                            row.push(tagArr);
                        }
                        if (k == 5) {
                            var sub = c.text();
                            if(sub!==undefined){
                               row.push(sub);
                            }else{
                                row.push("");
                            }
                            
                        }
                        k++;
                    });

                    newData.push(row);
                });


                var rowHighlight = $('.power').find('.highlight').index() + 1;
                //$("#powerTable").find("tr:gt(0)").remove(); //prevent from removing the first row
                if (rename) {
                    

                    $(LChosen).next().empty();
                    $('#powerTable > tbody > tr ').not(LChosen).removeClass('active');
                    //$(LChosen).toggleClass('active');
                    ////


                } else {
                    $(LChosen).next().empty();
                }
                $(LChosen).next().empty();
                $(LChosen).next().prepend('<td colspan="4"><table> <thead> <tr> <th>Status</th>' +
                    '<th>Sem</th>' +
                    '<th>Name</th>' +
                    '<th>SubMeter</th>' +
                    '<th>Power</th>' +
                    '<th>EnergyToday</th>' +

                    '</tr></thead><tbody');

                var statusQuery = [];
                statusQuery.callback = function(data) {
                    _.each(data, function(d) {
                        if (d.value !== undefined && d.value !== 'ok') {
                            $('#' + d.uid + '').append('<i class="icon icon-dot status-' + d.value + '" title="' + d.value + '" style="padding-left: 10px;"></i>');
                        }

                    });
                }

                for (var i = 0; i < newData.length; i++) {
                    statusQuery.push({
                        uid: newData[i][0],
                        nodeId: newData[i][1],
                        data: "prophetData:GGP/Equipment/string/StatusString"
                    });

                    $('<tr>').append($('<td id="' + newData[i][0] + '"style="width:23%"> </td>'))

                        .append($('<td id="' + newData[i][1] + '">').html(newData[i][0]))      
                        .append($('<td data-id="' + newData[i][1] + '" style="width:30%" class=disName> ').text(newData[i][4] + ' '))
                        .append($('<td class=disSubMeter>').text(newData[i][5] + ' '))
                        .append($('<td style="width:20%">').text(newData[i][2] + ' kW'))
                        .append($('<td style="width:20%">').html(newData[i][3] + ' kWh'))

                        .appendTo('#childTr table');

                    //  $("."+clickPowerTableRow).addClass('highlight');

                }
                dataEye.getDataValuesForNodes(statusQuery);
                window.newData1 = newData;

                $('#childTr table').on('click', 'tr', function(e) {
                    

                    $('#powerCharts').css({"display":"block", "opacity": "1" });
                    $('#PowerData').css('display', 'block');
                    $('#displayPowerName').html($(this).find('.disName').html());
                    $('#displaysubmeter').html($(this).find('.disSubMeter').html());
                    $('#displayPowerName').attr('data-id', $(this).find('.disName').attr('data-id'));
                    $('#displaysubmeter').attr('data-id', $(this).find('.disName').attr('data-id'));
                    
                    //plot graph for childNodes
                    var name = $(this).find('td:nth-child(2)').text();
                    powerMeters(newData1, name);
                    e.stopPropagation();
                });

                $('div .leftLabels').on('click', '.startEdit', function(e) {
                    var elem = $(this).prev(); // elem = $('p');
                    editingText = elem.html();
                    elem.empty();
                    
                    elem.html('<input type="text" value="' + editingText + '" id="panelTextBox" style="width:75%; border: 1px solid;">');
                    $('#panelTextBox').focus();
                    $(this).parent().append('<span class="editPower checkboxingNowPower" id="panelCheckingboxingnow" style="right: 42px"><i class="fa fa-check"></i></span><span class="editPower XBoxPower" style="right: 36px"><i class="fa fa-times"></i></span>');
                    $(this).parent().find('.startEdit').remove();
                    e.stopPropagation()
                });

                $('div .leftLabels').on('click', '#panelCheckingboxingnow', function(e) {
                    //Logic to save attibute
                    var powerNodeid = $(this).parent().find('#displayPowerName').attr('data-id');
                    var powerAttrRes;
                    powerAttrRes = $util.setAttributesXML(powerNodeid, $(this).parent().find('#displayPowerName').attr('data-name'), $(this).parent().find('input').val());
                    $util.setAttributes(powerAttrRes, powerNodeid);
                    $(this).parent().find('p').html($('#panelTextBox').val());
                    $(this).parent().find('span.checkboxingNowPower').removeClass('checkboxingNowPower').removeAttr("id").attr('class', 'editPower').addClass('startEdit').html('<i class="fa fa-pencil-square-o"></i>');
                    $(this).parent().find('.XBoxPower').remove();
                    e.stopPropagation()
                });

                $('div .leftLabels').on('click', '.XBoxPower', function(e) {
                    $(this).parent().find('p').html($(this).parent().find('input').val());
                   
                    $(this).parent().find('span.checkboxingNowPower').removeClass('checkboxingNowPower').removeAttr("id").attr('class', 'editPower').addClass('startEdit').html('<i class="fa fa-pencil-square-o"></i>');
                    

                    $(this).parent().find('.XBoxPower').remove();
                    e.stopPropagation();
                });

                if (rowHighlight != 0) {
                    $('#power').find('tr:nth-child(' + rowHighlight + ')').addClass('highlight');
                }

                $('tr').not(':first, .accordionInner tr').on('click', function() {
                    clickPowerTableRow = $(this);
                     
                    if (powertable.loading === "false") {
                        $('tr').removeClass('highlight');
                        $(this).addClass('highlight');
                        $('.pveil').css('display', 'none');
                    }

                });


                
                powertable.loading = "false";
            });

        },
        getPowerNodeArr: function(xml) {
            var xmlparse = $.parseXML(xml);
            var $xmlStr = $(xmlparse);
            var nodeArr = [];
            $xmlStr.find("node").each(function() {
                var arr = [];
                var node = $(this);
                var nodeType = $(node).attr('type');
                if (nodeType == 'csi3prophet:ProphetNode' || nodeType == 'csi3prophet:ProphetTemplateNode') {
                    var nodeId = $(node).find("nodeId").text();
                    var name = $(node).find("name").text();
                    var displayName;
                    var disAccount;
                    var attrArr = $(node).find("attributes").text();
                    $(node).find("attributes").each(function() {
                        var attributesArr = $(this);

                        $(attributesArr).find("attr").each(function() {
                            var attrVal = $(this);
                            var test2 = $(attrVal).attr('n');
                            if (test2 == "disLoc") {
                                displayName = $(attrVal).text();
                            }
                            if (test2 == "disAccountNumber") {
                                disAccount = $(attrVal).text();
                            }

                        });

                    });
                    var pathFromParent = "/" + $(node).find("pathFromParent").text();
                    var parentpath = nodeId.replace(pathFromParent, "");
                    var vaArr = parentpath.split("/");
                    var parentName = vaArr[vaArr.length - 1];
                    arr.push(name);
                    arr.push(nodeId);
                    arr.push(displayName);
                    arr.push(disAccount);
                    nodeArr.push(arr);
                }
            });

            return nodeArr;
        },
        //Chart for peak demand and Energy Consumption
        drawDemandEnergyChart: function(chartval, peakenergyReqStr, index, ord, timeRange) {
            $util.modalBusy("Loading");

            $.niagara.getTrend("testpath", peakenergyReqStr, function(obj) {
                $util.modalDone();

                var xmlDoc = $.parseXML(obj);
                var $xml = $(xmlDoc);
                var rowCnt = 0;
                var newData = [];
                $xml.find("r").each(function() {
                    var row = [];
                    var r = $(this);
                    var k = 0;
                    $(r).find("c").each(function() {
                        c = $(this);
                        if (k == 0) {
                            var time = c.text().split("T");
                            var dateArr = time[0];
                            var timeArr = time[1];
                            var date = dateArr.split("-");
                            time = timeArr.split(":");
                            var hr = time[0];
                            var min = time[1];
                            //alert("AAAAAA");
                            //var str = date[0]+"-"+date[1]-1+"-"+date[2]+"-"+hr+" "+min+" "+0;
                            var t = new Date(date[0], date[1] - 1, date[2], hr, min, 0, 0);
                            row.push(t.getTime());

                        }
                        if (k == 1) {
                            var f = parseFloat(c.text());
                            var result = Math.round(f * Math.pow(10, 2)) / Math.pow(10, 2);
                            row.push(result);
                        }
                        k++;
                    });

                    newData.push(row);
                });

                if (index == 1) {
                    var energyseries = $demandEnergyChart.get("kWH");
                    if (energyseries != null) {
                        energyseries.remove();
                    }
                    $demandEnergyChart.addSeries({
                        name: 'kWH',
                        type: 'column',
                        color: '#b0bf88',
                        yAxis: 0,
                        id: 'kWH',
                        pointPadding: 0.3,
                        groupPadding: 0.3,
                        borderWidth: 0,
                        shadow: false,
                        pointWidth: 27,
                        data: newData
                    });
                    var peakenergyReqStr = $util.createRequestString(ord, "prophetData:Haystack/elecMeter/numeric/elecMeterRealPowerNum", timeRange, "sum", "fifteenMinutes", "avg");
                    $util.drawDemandEnergyChart(chartval, peakenergyReqStr, 2, ord, timeRange);
                }
                if (index == 2) {
                    var powerseries = $demandEnergyChart.get("kW");
                    if (powerseries != null) {
                        powerseries.remove();
                    }
                    $demandEnergyChart.addSeries({
                        name: 'kW',
                        type: 'spline',
                        color: '#50471d',
                        yAxis: 1,
                        id: 'kW',
                        data: newData,
                        marker: {
                            radius: 3,
                            symbol: 'circle',
                            fillColor: '#50471d'
                        }
                    });
                    var dayOATReqStr = $util.createRequestString(ord, "prophetData:Haystack/weather/temperature/numeric/outdoorAirTemperatureNOAANum", timeRange, "avg", "fifteenMinutes", "avg");
                    $util.drawDemandEnergyChart(chartval, dayOATReqStr, 3, ord, timeRange);
                }
                if (index == 3) {
                    var oatseries = $demandEnergyChart.get("OAT");
                    if (oatseries != null) {
                        oatseries.remove();
                    }
                    $demandEnergyChart.addSeries({
                        name: 'OAT',
                        type: 'spline',
                        color: '#e58a53',
                        yAxis: 2,
                        id: 'OAT',
                        data: newData,
                        marker: {
                            radius: 3,
                            symbol: 'circle',
                            fillColor: '#e58a53'
                        }
                    });

                }
                $demandEnergyChart.redraw();

            });
        }

    });

    function queryActiveTempAndStatusForNodes(data) {

        var ZONE_CTL_TEMP = 'slot:/DataTree/data/Haystack/hvac/temp/air/numeric/activeZoneControlTempNum';
        var ZONE_CTL_SP = 'slot:/DataTree/data/Haystack/hvac/temp/air/numeric/activeZoneControlSpNum';
        var STATUS = 'prophetData:GGP/Equipment/string/StatusString';

        var normalizeIdRE = /[:\\/]/g;
        //scheduleSummary('Mall', data);
        _.each(data.rows, function(r) {
            var nodeInfo = $util.siteInfoFromNodeId(r.SlotPath);
            var uid = _.uniqueId('equipData-' + nodeInfo.site + '-');
            r.uid = uid;
            r.tempUid = (uid + ZONE_CTL_TEMP).replace(normalizeIdRE, '-');
            r.spUid = (uid + ZONE_CTL_SP).replace(normalizeIdRE, '-');
            r.statusUid = (uid + 'StatusString').replace(normalizeIdRE, '-');
        });

        var activeTempOptions = _.map(data.rows, function(row) {
            return {
                uid: row.uid,
                nodeId: row.SlotPath,
                data: [
                    ZONE_CTL_TEMP,
                    ZONE_CTL_SP,
                    STATUS
                ]
            }
        });
        activeTempOptions.callback = function(data) {
            _.each(data, function(d) {
                var id = '#' + d.uid + d.data.replace(normalizeIdRE, '-');
                $(id).html('');
                if (d.error) {
                    var exclaimHTML = [
                        "<i",
                        "title='",
                        d.error,
                        "'",
                        "class='icon icon-warning' />"
                    ].join(' ');
                    $(id).append(exclaimHTML);
                }
                var content, hasError = false;
                var statuses = d.valueObj.statuses;
                if (_.contains(statuses, '{null}')) {
                    content = 'Sensor error';
                    hasError = true;
                } else {
                    content = d.value;
                }

                if (/StatusString/.test(d.data) && content !== 'ok') {
                    // status result; set class on <i>
                    var statId = '#' + d.uid + 'StatusString';
                    $(statId).addClass('icon icon-dot status-' + content);
                    $(statId).attr('title', content);
                } else {
                    // normal data result (temp or sp)
                    $(id).append(content);
                }
                if (hasError) {
                    $(id).css({
                        color: 'red'
                    });
                }
            });

        }

        dataEye.getDataValuesForNodes(activeTempOptions);

    }
})(jQuery);
