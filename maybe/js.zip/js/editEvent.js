
/******************************************************************
 JS used for editing Events
  Controlco Inc
  Author: Deepti Phadnis
 ******************************************************************/
 
$(function() {
		$( "#startMinuteOffset" ).spinner({
			spin: function( event, ui ) {
				if ( ui.value > 59 ) {
					$( this ).spinner( "value", 0 );
					return false;
				} else if ( ui.value < 0 ) {
					$( this ).spinner( "value", 59 );
					return false;
				}
			}
		});
	});
		$(function() {
		$( "#startHourOffset" ).spinner({
			spin: function( event, ui ) {
				if ( ui.value > 1000 ) {
					$( this ).spinner( "value", -1000 );
					return false;
				} else if ( ui.value < -1000 ) {
					$( this ).spinner( "value", 1000 );
					return false;
				}
			}
		});
	});
			$(function() {
		$( "#endMinuteOffset" ).spinner({
			spin: function( event, ui ) {
				if ( ui.value > 59 ) {
					$( this ).spinner( "value", 0 );
					return false;
				} else if ( ui.value < 0 ) {
					$( this ).spinner( "value", 59 );
					return false;
				}
			}
		});
	});
			$(function() {
		$( "#endHourOffset" ).spinner({
			spin: function( event, ui ) {
				if ( ui.value > 1000 ) {
					$( this ).spinner( "value", -1000 );
					return false;
				} else if ( ui.value < -1000 ) {
					$( this ).spinner( "value", 1000 );
					return false;
				}
			}
		});
	});




jQuery(document).ready(function($) {

 var loc = location.search.substring(1, location.search.length);
 
    var param_value = false;
 var params = loc.split("&");
 param_name = params[0].substring(0,params[0].indexOf('='));
 param_value = params[0].substring(params[0].indexOf('=')+1);
 

 var json = ""+params[1].substring(params[1].indexOf('=')+1);
 json = json.replace(new RegExp("%22", 'g'), "\"");
 var jsonobj = jQuery.parseJSON(json);

 $("#virtualOffset").hide();
 
 var output = [];
  var $data = {
   regionPath : param_value,
   scheduleType : "HVAC",
   scheduleName : "HvacMall"
 };
  
  $( "#dialog" ).dialog({
      autoOpen: false,
      show: {
        effect: "blind",
        duration: 1000
      },
      hide: {
        effect: "explode",
        duration: 1000
      }
    });
 var $currWeeklySchedule = [];
 var $newWeeklySchedule = [];
    var maskHeight = 600;
    var maskWidth = 900;
    var winH = 500;
    var winW = $(document).width();
    
    var hvacList = [];
    var lightingList = [];
    var generalList = [];
    
var oldEventName="";
var newEventName="";
$util.setValueEditBox();

var windLoc = window.location+"";
var schedName="";

if(windLoc.indexOf("editEvent")>0)
{	
	$("#removeExceptionButton").hide();
	oldEventName = jsonobj.title;
	//$util.getExceptionOnDay(param_value,jsonobj);
	schedName = ""+params[0].substring(params[0].indexOf('=')+1);
	$data.scheduleName = schedName;
	$.niagara.getEventClasses($data.scheduleName,function(obj)
			{
			if(obj != null)
			{
				var str = "";
				for(var i = 0;i<obj.value.length;i=i+2)
				{	
				str = str + '<option value="'+obj.value[i]+'">'+obj.value[i+1]+'</option>'; 
				}
				$("#editEventClass").append(str);
			}
			jsonobj = $util.loadEditPage(param_value,jsonobj);
			$util.loadAddEvents();

			});
	 if(jsonobj.selectedSubZone != "")
	 {
		var n =  jsonobj.selectedSubZoneName.split("*");
		if(n[1] == jsonobj.virSchPath)
		{	
			n[0] = unescape(n[0]);
			$("#virOffsetLabel").text("Edit "+n[0]+" offset");
		}	
	 }
	 if(jsonobj.selectedZone != "")
	 {
		var n =  jsonobj.selectedZoneName.split("*");
		if(n[1] == jsonobj.virSchPath)
		{	
			n[0] = unescape(n[0]);
			$("#virOffsetLabel").text("Edit "+n[0]+" offset");
		}	
	 }
	 if(jsonobj.selectedGroup != "")
	 {
		var n =  jsonobj.selectedGroupName.split("*");
		if(n[1] == jsonobj.virSchPath)
		{	
			n[0] = unescape(n[0]);
			$("#virOffsetLabel").text("Edit "+n[0]+" offset");
		}	
	 }
	 
	 $.niagara.getVirtualScheduleOffset($data.scheduleName,jsonobj.virSchPath,function(obj){
			if(obj!=null)
				{
					getOffset(obj.virtualOffset);
				}
		});

}
else if(windLoc.indexOf("indexRelative")>0 && params[1])
{	
	schedName = ""+params[1].substring(params[1].indexOf('=')+1);
	$("#hvac_list").val(schedName);
}	

$("#removeExceptionButton").click(function()
	{
	var actualExceptionName = $("#actualExceptionName").text();
	$.niagara.removeException($data.scheduleName,jsonobj.title,actualExceptionName,function(obj){
		sethref("#removeExceptionButton");
	});
});
	

 $("#backButton").click(function()
		 {
	 sethref("#backButton");
});


	 
	function getOffset(obj)
	{
		$("#startHourOffset").val(obj.startOffsetHours);
		$("#startMinuteOffset").val(obj.startOffsetMin);
		$("#endHourOffset").val(obj.endOffsetHours);
		$("#endMinuteOffset").val(obj.endOffsetMin);

		$("#effectiveStartOffset").text(obj.effecStartOffsetHours+" hrs : "+obj.effecStartOffsetMin+" min");
		$("#effectiveEndOffset").text(obj.effecEndOffsetHours+" hrs : "+obj.effecEndOffsetMin+" min");

		$("#effectiveStart").text(obj.effecStart);
		$("#effectiveEnd").text(obj.effecEnd);
		
	}
	function saveVirtualOffset()
	{
		  var startHourOffset = $("#startHourOffset").val();
		  var startMinuteOffset = $("#startMinuteOffset").val();

		  var endHourOffset = $("#endHourOffset").val();
		  var endMinuteOffset = $("#endMinuteOffset").val();
		  
		  if(jsonobj.isVirtual=="true")
		  {	  
		  $.niagara.saveVirtualScheduleOffset($data.scheduleName,jsonobj.virSchPath,startHourOffset,startMinuteOffset,endHourOffset,endMinuteOffset,function(obj)
		    {
			  if(obj.value == "false")
		      {
		    	  alert("Please check inputs!");
		      }
			  else
				  sethref("#editEventButton");
		     });
		  }
		  else
		    sethref("#editEventButton");
	}
 
 
/****************** Edit Event Submit************************************************************/
 $("#editEventButton").click(function(){
	 
     for(var i=0;i<(output.length);i=i+3)
     {
      var id1 = "#"+output[i];
      output[i+1] = $(id1).val();
     }
  var newEventName = $("#eventName").val();
  
  var eventType = $("#eventType").text();

  var editEventEditStartMode = $("#editEventEditStartMode").val();
  var startHour = $("#startHour").val();
  var startMin = $("#startMin").val();
  var startAmPm = $("#startAmPm").val();

  var editEventEditEndMode = $("#editEventEditEndMode").val();
  var endHour = $("#endHour").val();
  var endMin = $("#endMin").val();
  var endAmPm = $("#endAmPm").val();
  
  var editDay = $("#editEventEditDay").val();
  var editMonth = $("#editEventEditMonth").val();
  var editYear = $("#editEventEditYear").val();
  var  eventClass ="";
  if($("#editEventClass").val()!=null || $("#editEventClass").val()!="")
	  eventClass = $("#editEventClass").val();
 
  if(oldEventName!=newEventName)
  {
	  editEventSubmit(); 
  }
  else if(eventType == "OneTimeEvent")
  {
	  
	  editEventSubmit(); 
  }	  
  
  else if (eventType == "DailyEvent" || eventType == "MondayThroughFridayEvent")
  {
	  if(checkTimesDates(editEventEditStartMode,startHour,startMin,startAmPm,editEventEditEndMode,endHour,endMin,endAmPm,editDay,editMonth,editYear,output))
		  {
		  if(checkSkipDays())
			  $( "#dialog" ).dialog( "open" );
		  	else
		  		 editEventSubmit();
		  }
	  else
		  editEventSubmit(); 
  }
  
  else if (eventType == "DateRangeEvent")
	  {
		  if(checkTimesDates(editEventEditStartMode,startHour,startMin,startAmPm,editEventEditEndMode,endHour,endMin,endAmPm,editDay,editMonth,editYear,output))
		  {
		  if(checkSkipDays() && checkDR() )
			  $( "#dialog" ).dialog( "open" );
		  	else
		  		 editEventSubmit();
		  }
		  else
		  		 editEventSubmit();
	  }  
  else if (eventType == "TradingHoursEvent")
  {
	  if(checkTimesDates(editEventEditStartMode,startHour,startMin,startAmPm,editEventEditEndMode,endHour,endMin,endAmPm,editDay,editMonth,editYear,output))
	  {
		  if(checkSkipDays() && checkTrading() )
			  $( "#dialog" ).dialog( "open" );
	  	  else
	  		 editEventSubmit();
	  }
	  else
	  		 editEventSubmit();
  }
  else if (eventType == "Week And Day Event")
  {
	  
	  if(checkTimesDates(editEventEditStartMode,startHour,startMin,startAmPm,editEventEditEndMode,endHour,endMin,endAmPm,editDay,editMonth,editYear,output))
	  {
		  if(checkSkipDays() && checkWeekAndDay() )
			  $( "#dialog" ).dialog( "open" );
	  	  else
	  		 editEventSubmit();
	  }
	  else
	  		 editEventSubmit();
  }

  else if (eventType == "WeeklyEvent")
  {
	  
	  if(checkTimesDates(editEventEditStartMode,startHour,startMin,startAmPm,editEventEditEndMode,endHour,endMin,endAmPm,editDay,editMonth,editYear,output))
	  {
		  if(checkSkipDays() && checkWeekly() )
			  $( "#dialog" ).dialog( "open" );
	  	  else
	  		 editEventSubmit();
	  }
	  else
	  		 editEventSubmit();
  }
  else if (eventType == "MonthlyEvent")
  {
	  
	  if(checkTimesDates(editEventEditStartMode,startHour,startMin,startAmPm,editEventEditEndMode,endHour,endMin,endAmPm,editDay,editMonth,editYear,output))
	  {
		  if(checkSkipDays() && checkMonthly() )
			  $( "#dialog" ).dialog( "open" );
	  	  else
	  		 editEventSubmit();
	  }
	  else
	  		 editEventSubmit();
  }
  else if (eventType == "YearlyEvent")
  {
	  
	  if(checkTimesDates(editEventEditStartMode,startHour,startMin,startAmPm,editEventEditEndMode,endHour,endMin,endAmPm,editDay,editMonth,editYear,output))
	  {
		  if(checkSkipDays() && checkYearly() )
			  $( "#dialog" ).dialog( "open" );
	  	  else
	  		 editEventSubmit();
	  }
	  else
	  		 editEventSubmit();
  }
  
  else
  {
	  editEventSubmit(); 
  }

	  
});
 
 $("#thisDay").click(function(){
	 
	    for(var i=0;i<(jsonobj.output.length);i=i+3)
	    {
	     var id1 = "#"+jsonobj.output[i];
	     jsonobj.output[i+1] = $(id1).val();
	    }
	 var newEventName = $("#eventName").val();
	 
	 var eventType = $("#eventType").text();

	 var editEventEditStartMode = $("#editEventEditStartMode").val();
	 var startHour = $("#startHour").val();
	 var startMin = $("#startMin").val();
	 var startAmPm = $("#startAmPm").val();

	 var editEventEditEndMode = $("#editEventEditEndMode").val();
	 var endHour = $("#endHour").val();
	 var endMin = $("#endMin").val();
	 var endAmPm = $("#endAmPm").val();
	 var editDay = $("#editEventEditDay").val();
	 var editMonth = $("#editEventEditMonth").val();
	 var editYear = $("#editEventEditYear").val();
	 
	 
	 $.niagara.addException($data.scheduleName,newEventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,editEventEditStartMode,editEventEditEndMode,editDay,editMonth,editYear,eventType,jsonobj.output,function(obj){
	 $( "#dialog" ).dialog( "close" );
	 saveVirtualOffset();
	 //sethref("#editEventButton");
	 });
 });
 $("#allDays").click(function(){
	 editEventSubmit(); 
 });
 $('.window .close').click(function (e) {
     e.preventDefault();
     $('#mask, .window').hide();
 });     
  
 $('#mask').click(function () {
     $(this).hide();
     $('.window').hide();
 });   



function checkDR()
{
	   var bool = false;
	   var editStartDay = $("#editStartDay").val();
	   var editStartMonth = $("#editStartMonth").val();
	   var editStartYear = $("#editStartYear").val();
	   var editEndDay = $("#editEndDay").val();
	   var editEndMonth = $("#editEndMonth").val();
	   var editEndYear = $("#editEndYear").val();
	   
	   if(editStartDay == jsonobj.drStartDay && editStartMonth == jsonobj.drStartMonth && editStartYear == jsonobj.drStartYear &&
			   editEndDay == jsonobj.drEndDay && editEndMonth == jsonobj.drEndMonth && editEndYear == jsonobj.drEndYear)
		   bool =  true;
	   else
		   bool =  false;
	   return bool;

}
function checkTrading()
{
	   var bool = false;
	   var tradStartOffset = $("#startOffset").val();;
	   var tradEndOffset = $("#endOffset").val();
	   
	   if(tradStartOffset == jsonobj.tradStartOffset && tradEndOffset == jsonobj.tradEndOffset)
		   bool =  true;
	   else
		   bool =  false;
	   return bool;
}

function checkWeekAndDay()
{
	   var bool = false;
       var day = $('#WNDeditEventEditWeekDay').val();
       var week = $('#WNDeditEventEditWeek').val();
       var month = $('#WNDeditEventEditMonth').val();
	   
	   if(day == jsonobj.wdDay && week == jsonobj.wdWeek && month == jsonobj.wdMonth)
		   bool =  true;
	   else
		   bool =  false;
	   
	   
	   return bool;
}

function checkWeekly()
{
	   var bool = false;
       var day = $('#weeklyEditWeekDay').val();
	   
	   if(day == jsonobj.wWeekday)
		   bool =  true;
	   else
		   bool =  false;
	   return bool;
}
function checkMonthly()
{
	   var bool = false;
       var day = $('#monthlyEditDay').val();
	   
	   if(day == jsonobj.mWeekday)
		   bool =  true;
	   else
		   bool =  false;
	   return bool;
}

function checkYearly()
{
	   var bool = false;
       var day = $('#yearlyEditDay').val();
       var month = $('#yearlyEditMonth').val();
	   
	   if(day == jsonobj.yWeekday && month == jsonobj.yMonth)
		   bool =  true;
	   else
		   bool =  false;
	   return bool;
}

function checkSkipDays()
{
	  var skipDays1 = [];
	  $('input:checkbox[name="skipDays"]:checked').each(function(index) 
	    { 
	     skipDays1.push($(this).val());
	    });
	  
	  var bool = true;
	  for(var i=0;i<skipDays1.length;i++)
		  {
		  	if(jsonobj[skipDays1[i]]=="true")
		  	{	
		  		bool = true;
		  		
		  	}
		  	else
		  	{	
		  		bool = false;
		  		break;
		  	}	
		  }
	  return bool;
}

function checkOutputs()
{
	for(var i=0;i<(jsonobj.output.length);i=i+3)
    {
     var id1 = "#"+jsonobj.output[i];
     if(jsonobj.output[i+1]!=$(id1).val())
    {	 
    	 bool = true;
    	 break;
    } 
    else
    {	 
    	 bool = false;
    	
    }
    }
	return bool;
}


function checkTimesDates(editEventEditStartMode,startHour,startMin,startAmPm,editEventEditEndMode,endHour,endMin,endAmPm,editDay,editMonth,editYear,output)
{
	
	if((editEventEditStartMode!=jsonobj.startMode) || (editEventEditEndMode!=jsonobj.endMode) ||
			  (startHour!=jsonobj.startH) || (startMin!=jsonobj.startM) || (startAmPm!=jsonobj.startAP) ||
			  (endHour!=jsonobj.endH) || (endMin!=jsonobj.endM) || (endAmPm!=jsonobj.endAP) || (checkOutputs()))
	 
	  {
		return true;  
	  }
	else
		{
		return false;
		//editEventSubmit(); 
		}
}
 
function editEventSubmit()
{
	for(var i=0;i<(jsonobj.output.length);i=i+3)
    {
     var id1 = "#"+jsonobj.output[i];
     jsonobj.output[i+1] = $(id1).val();
    }
 var newEventName = $("#eventName").val();
 
 var eventType = $("#eventType").text();
 
 var editEventEditStartMode = $("#editEventEditStartMode").val();
 var startHour = $("#startHour").val();
 var startMin = $("#startMin").val();
 var startAmPm = $("#startAmPm").val();

 var editEventEditEndMode = $("#editEventEditEndMode").val();
 var endHour = $("#endHour").val();
 var endMin = $("#endMin").val();
 var endAmPm = $("#endAmPm").val();
 
 var  eventClass ="";
 if($("#editEventClass").val()!=null || $("#editEventClass").val()!="")
	  eventClass = $("#editEventClass").val();

 $.niagara.renameEvent($data.scheduleName,oldEventName,newEventName, function(obj){
	  var eventName=obj.value;
	  
	  if(eventType == "DailyEvent")
	  { 
	  var skipDays1 = [];
	  $('input:checkbox[name="skipDays"]:checked').each(function(index) 
	    { 
	     skipDays1.push($(this).val());
	    });
	  $.niagara.editDailyEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,skipDays1,editEventEditStartMode,editEventEditEndMode,eventType,jsonobj.output,eventClass,function(obj){
		  if(obj.value!=null && obj.value!="false")
		  {	  
		  $( "#dialog" ).dialog( "close" );
		  saveVirtualOffset();
		  }
		  else
			 console.log("Bad inputs");
	   });
	  }
	  else if(eventType == "MondayThroughFridayEvent")
	  { 
	  var skipDays1 = [];
	  $('input:checkbox[name="skipDays"]:checked').each(function(index) 
	    { 
	     skipDays1.push($(this).val());
	    });
	  $.niagara.editDailyEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,skipDays1,editEventEditStartMode,editEventEditEndMode,eventType,jsonobj.output,eventClass,function(obj){
		  if(obj.value!=null && obj.value!="false")
		  {	  
		  $( "#dialog" ).dialog( "close" );
		  saveVirtualOffset();
		  }
		  else
			  alert("Please check inputs");
	   });
	  }
	
	  else if(eventType == "TradingHoursEvent")
	  {
	  var skipDays = [];
	  $('input:checkbox[name="skipDays"]:checked').each(function(index) 
	    { 
	     skipDays.push($(this).val());
	    });
	  var startOffset = $("#startOffset").val();
	  var endOffset = $("#endOffset").val();
	  $.niagara.editTradingHoursEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,skipDays,editEventEditStartMode,editEventEditEndMode,eventType,startOffset,endOffset,jsonobj.output,eventClass,function(obj){
		  if(obj.value!=null && obj.value!="false")
		  {	  
		  $( "#dialog" ).dialog( "close" );
		  saveVirtualOffset();
		  }
		  else
			  alert("Please check inputs");
	   });
	  }
	  else if(eventType == "WeeklyEvent")
	  {
	  var editDay = $("#weeklyEditWeekDay").val();
	  $.niagara.editWeeklyEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,editEventEditStartMode,editEventEditEndMode,eventType,editDay,jsonobj.output,eventClass,function(obj){
		  if(obj.value!=null && obj.value!="false")
		  {	  
		  $( "#dialog" ).dialog( "close" );
		  saveVirtualOffset();
		  }
		  else
			  alert("Please check inputs");
	   });
	  }
	  else if(eventType == "MonthlyEvent")
	  {
	  var skipDays = [];
	  $('input:checkbox[name="skipDays"]:checked').each(function(index) 
	    { 
	     skipDays.push($(this).val());
	    });
	  var editDay = $("#monthlyEditDay").val();
	  $.niagara.editMonthlyEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,editEventEditStartMode,editEventEditEndMode,eventType,skipDays,editDay,jsonobj.output,eventClass,function(obj){
		  if(obj.value!=null && obj.value!="false")
		  {	  
		  $( "#dialog" ).dialog( "close" );
		  saveVirtualOffset();
		  }
		  else
			  alert("Please check inputs");
	   });
	  }
	  else if(eventType == "YearlyEvent")
	  {
	  var skipDays = [];
	  $('input:checkbox[name="skipDays"]:checked').each(function(index) 
	    { 
	     skipDays.push($(this).val());
	    });
	  var editDay = $("#yearlyEditDay").val();
	  var editMonth = $("#yearlyEditMonth").val();
	
	  $.niagara.editYearlyEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,editEventEditStartMode,editEventEditEndMode,eventType,skipDays,editDay,editMonth,jsonobj.output,eventClass,function(obj){
		  if(obj.value!=null && obj.value!="false")
		  {	  
		  $( "#dialog" ).dialog( "close" );
		  saveVirtualOffset();
		  }
		  else
			  alert("Please check inputs");
	   });
	  }
	  
	  else if(eventType == "WeekAndDayEvent")
	  { 
	   var skipDays = [];
	   $('input:checkbox[name="skipDays"]:checked').each(function(index) 
	     { 
	      skipDays.push($(this).val());
	     });
	   var WNDeditEventEditWeekDay = $("#WNDeditEventEditWeekDay").val();
	   var WNDeditEventEditWeek = $("#WNDeditEventEditWeek").val();
	   var WNDeditEventEditMonth = $("#WNDeditEventEditMonth").val();
	   
	   $.niagara.editWeekAndDayEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,skipDays,editEventEditStartMode,editEventEditEndMode,WNDeditEventEditWeekDay,WNDeditEventEditWeek,WNDeditEventEditMonth,eventType,jsonobj.output,eventClass,function(obj){
			  if(obj.value!=null && obj.value!="false")
			  {	  
			  $( "#dialog" ).dialog( "close" );
			  saveVirtualOffset();
			  }
			  else
				  alert("Please check inputs");
	    });
	   
	  }
	  else if(eventType == "OneTimeEvent")
	  { 
	   var editDay = $("#editEventEditDay").val();
	   var editMonth = $("#editEventEditMonth").val();
	   var editYear = $("#editEventEditYear").val();
	   
	   $.niagara.editOneTimeEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,editEventEditStartMode,editEventEditEndMode,editDay,editMonth,editYear,eventType,jsonobj.output,eventClass,function(obj){
			  if(obj.value!=null && obj.value!="false")
			  {	  
			  $( "#dialog" ).dialog( "close" );
			  saveVirtualOffset();
			  }
			  else
				  alert("Please check inputs");
	    });
	   }
	  else if(eventType == "DateRangeEvent")
	  { 
	   var skipDays = [];
	   $('input:checkbox[name="skipDays"]:checked').each(function(index) 
	    { 
	     skipDays.push($(this).val());
	    });
	   var editStartDay = $("#editStartDay").val();
	   var editStartMonth = $("#editStartMonth").val();
	   var editStartYear = $("#editStartYear").val();
	   var editEndDay = $("#editEndDay").val();
	   var editEndMonth = $("#editEndMonth").val();
	   var editEndYear = $("#editEndYear").val();
	   
	   $.niagara.editDateRangeEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,editEventEditStartMode,editEventEditEndMode,editStartDay,editStartMonth,editStartYear,editEndDay,editEndMonth,editEndYear,skipDays,eventType,jsonobj.output,eventClass,function(obj){
			  if(obj.value!=null && obj.value!="false")
			  {	  
			  $( "#dialog" ).dialog( "close" );
			  saveVirtualOffset();
			  }
			  else
				  alert("Please check inputs");
	    });
	   }
	  
	  });
	
	
} 

 $("#deleteEventButton").click(function(){
  var eventName = $("#eventName").val();
  var eventType = $("#eventType").text();

   $.niagara.deleteEvent($data.scheduleName,eventName,eventType,function(obj){
	   sethref("#deleteEventButton");
    });
 }); 
 
     
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     
    $('#mask').click(function () {
        $(this).hide();
        $('.window').hide();
    });         

 /* Get the metering present datapoint and store its result */
 
    function sethref(obj)
    {
    	
    	 var arr = params[0].split("/");
    		var sched = arr[arr.length-1];
    		params[0]="";
    		
    		for(var i=0;i<arr.length-1;i++)
    		{	
    			if(i<arr.length-2)
    				params[0] = params[0]+arr[i]+"/";
    			else
    				params[0] = params[0]+arr[i];
    		}
    		var alink = "indexRelative.html?"+params[0]+"&sched="+sched+"&isVirtual="+jsonobj.isVirtual+"&virSchPath="+jsonobj.virSchPath;
    		alink = alink +"&selectedGroupName="+jsonobj.selectedGroupName+"&selectedZoneName="+jsonobj.selectedZoneName+"&selectedSubZoneName="+jsonobj.selectedSubZoneName;
    		$(obj).attr('href',alink);	
    		location.href = alink;

    }    
 $(window).unload(function() {
//  clearInterval(intr);
 });
 
 /*var intr = setInterval(function(){
  var date = $util.normalizeDate();
  $util.getMonthlySchedule(date,$data.scheduleName);
 },
 20000);*/
 
 //$.niagara.BatchPoll.printPollList();
});
