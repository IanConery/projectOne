/*****************************************************************
 * Name: 
 * Version: 
 * Date: {}
 * Copyright: 2013 Controlco, CSI3
 *
 *
 * @author: Brian Murrell
 *****************************************************************/

define(function(require) {

    var NodeModel = require('models/node-model');

    require('backbone');
    require('underscore');
    var xml2json = require('xml2json');
    var getChildNodesTmpl = require('hbars!xmlDataEyeReqTmpls/get-child-nodes-template');


    var NodeCollection = Backbone.Collection.extend({

        model: NodeModel,

        defaults: {},

        // initialize: function() {

        // },

        url: '/prophet',

        fetch: function(options) {

            this.fetching = options.nodeId = options.fetching;
            var xmlReqData = xmlIfy(options);

            var self = this;

            var success = function(xmlData) {

                var response = deXmlIfy(xmlData);
                var serverNodes;
                if (response.node) {
                    serverNodes = _.isArray(response.node) ? response.node : [response.node];
                } else {
                    serverNodes = [];
                }
                
                var nodes = [];
                _.each(serverNodes, function(node) {
                    NodeModel.prototype.transformServerValues(node);
                    if (node.attributes) {
                        node.attrs = node.attributes.attr;
                        delete node.attributes;
                    }
                    nodes.push( new self.model(node) ); 
                });

                self.reset(nodes);

            }
            var ajaxConfig = {
                url: this.url, 
                data: xmlReqData,
                type: 'POST', 
                dataType: 'text',
                contentType: 'text/xml',
                success: success
            };
           
            $.ajax(ajaxConfig);
        }

    }); 

    function xmlIfy(options) {
        options.uid = options.uid || _.uniqueId();
        var xml = getChildNodesTmpl(options);
        return xml;
    }

    function deXmlIfy(xmlData) {
        var d = xml2json($.parseXML(xmlData),'');
        var da = JSON.parse(d);

        return da.ProphetResponse.MethodResponse;

    }

    return NodeCollection;

});