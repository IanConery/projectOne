/*****************************************************************
 * Name: TrendCollection
 * Version:  0.1
 * Date: 1-aug-2013
 * Copyright: 2013 Controlco, CSI3
 *
 *
 * @author: Brian Murrell
 *****************************************************************/

define(function(require) {
    require('backbone');
    var TrendPoint = require('models/trend-point');
    var getTrendTmpl =  TMPLS.getTrend;

    var TrendCollection = Backbone.Collection.extend({

        model: TrendPoint,

        initialize: function(models, options) {
            this.options = options;
        },

        fetch: function(options) {

            var ajaxConfig = {
                url: "/p?http://172.28.20.16/prophet",
                data: this.xmlIfy(),
                type: 'POST',
                dataType: 'text',
                contentType: 'text/xml',
                parse: true
            };
            options = _.extend({}, ajaxConfig, options);

            return Backbone.Collection.prototype.fetch.call(this, options);
        },

        // return a subset of this collection where uid matches passed uid
        forUid: function(uid) {
            return this.where({uid: uid});
        },

        parse: function(xmlResponse, options) {
            var responses = deXmlIfy(xmlResponse);
            var trendRequests = this.options.trendRequests;
            var trends = [], type, tables, rows, self = this;

            // flatten possible multiple method responses into this collection
            _.each(responses, function(resp) {
                if (!_.isArray(resp.t)) resp.t = [resp.t];
                type = _.findWhere(trendRequests, {uid: resp.uid}).type;
                if (resp.error) {
                    self.error = self.error || {};
                    self.error[resp.uid] = resp.error;
                } else {
                    if (resp.t) {
                        tables = _.isArray(resp.t) ? resp.t : [resp.t];
                    } else {
                        tables = [];
                    }
                    _.each(tables, function(table) {
                        if (table.r) {
                            rows = _.isArray(table.r) ? table.r : [table.r];
                        } else {
                            rows = [];
                        }
                        _.each(rows, function(row) {
                            var value, status = '';
                            if ( _.isObject(row.c[1]) ) {
                                value = row.c[1]['#text'];
                                status = row.c[1]['@s'];
                            } else {
                                value = row.c[1];
                            }

                            trends.push( {
                                isoDate: row.c[0],
                                value: value,
                                status: status,
                                uid: resp.uid,
                                serverInterval: table['@interval'],
                                type: type
                            } );
                        });
                    });
                }
            });

            return trends;
        },

        xmlIfy: function(options) {
            var data = options || this.options;
            _.each(data.trendRequests, function(r) {
                r.uid = r.uid || _.uniqueId();
                if (r.tags) r.tags = r.tags.join(',');
            });
            var xml = getTrendTmpl(data);
            return xml;
        },

        url: '/prophet'
    });


    function deXmlIfy(xmlData) {
        var d = xml2json($.parseXML(xmlData),'');
        var da = JSON.parse(d);
        var responses = da.ProphetResponse.MethodResponse;
        if (responses) {
            if ( !_.isArray(responses) )
                responses = [responses];
            _.each(responses, function(r) {r.uid = r['@uid']; delete r['@uid'];})
        } else {
            responses = [];
        }
        return responses;
    }

    return TrendCollection;

});