/*****************************************************************
 * Name: DataDefinitionCollection
 * Version: 1.0
 * Date: 2013-09-12
 * Copyright: 2013 Controlco, CSI3
 *
 * Provides collection for points that are trendable
 *
 * @author: Brian Murrell
 *****************************************************************/

define(function(require) {

    var DataDefinitionModel = require('models/data-definition-model');
    require('xml2json');
    var getDDTmpl = TMPLS.getDataDefinition;

    var DataDefinitionCollection = Backbone.Collection.extend({

        initialize: function(models, options) {
            this.options = options;
        },

        model: DataDefinitionModel,

        trended: function() {
            return this.filter(function(m) {
                return m.get('trended');
            })
        },

        selected: function() {
            return this.filter(function(m) {
                return m.get('selected');
            });
        },

        clearSelected: function() {
            _.each(this.models, function(m) {
                m.set('selected', false);
            });
        },

        fetch: function(options) {
            var ajaxConfig = {
                url: this.url,
                data: this.xmlIfy(),
                type: 'POST',
                dataType: 'text',
                contentType: 'text/xml',
                parse: true
            };
            options = _.extend({}, ajaxConfig, options);

            return Backbone.Collection.prototype.fetch.call(this, options);

        },

        url: '/p?http://'+server+'/prophet',

        comparator: function(dd) {
            return dd.get('name');
        },

        parse: function(xmlResponse, options) {
            var dataDefinitions = deXmlIfy(xmlResponse);
            return dataDefinitions;
        },

        xmlIfy: function(options) {
            var data = options || this.options;
            data.uid = data.uid || _.uniqueId();
            var xml = getDDTmpl(data);
            return xml;
        }
    });

    function deXmlIfy(xmlData) {
        var jsonStr = xml2json($.parseXML(xmlData), '');
        var prophetResponse = JSON.parse(jsonStr).ProphetResponse;
        var methodResponses =
            _.isArray(prophetResponse.MethodResponse) ?
            prophetResponse.MethodResponse :
            [prophetResponse.MethodResponse];

        // save the original uid
        var dataDefs = _.map(methodResponses, function(m) {
            return _.extend(m.dataDefinition, {uid: m['@uid']});
        });
        return dataDefs;
    }

    return DataDefinitionCollection;
});