/******************************************************************
 Controlco Inc.
 * Author: Deepti Phadnis
 ******************************************************************/

$(function() {
		$( "#startMinuteOffset" ).spinner({
			spin: function( event, ui ) {
				if ( ui.value > 59 ) {
					$( this ).spinner( "value", 0 );
					return false;
				} else if ( ui.value < 0 ) {
					$( this ).spinner( "value", 59 );
					return false;
				}
			}
		});
	});
		$(function() {
		$( "#startHourOffset" ).spinner({
			spin: function( event, ui ) {
				if ( ui.value > 1000 ) {
					$( this ).spinner( "value", -1000 );
					return false;
				} else if ( ui.value < -1000 ) {
					$( this ).spinner( "value", 1000 );
					return false;
				}
			}
		});
	});
			$(function() {
		$( "#endMinuteOffset" ).spinner({
			spin: function( event, ui ) {
				if ( ui.value > 59 ) {
					$( this ).spinner( "value", 0 );
					return false;
				} else if ( ui.value < 0 ) {
					$( this ).spinner( "value", 59 );
					return false;
				}
			}
		});
	});
			$(function() {
		$( "#endHourOffset" ).spinner({
			spin: function( event, ui ) {
				if ( ui.value > 1000 ) {
					$( this ).spinner( "value", -1000 );
					return false;
				} else if ( ui.value < -1000 ) {
					$( this ).spinner( "value", 1000 );
					return false;
				}
			}
		});
	});

			
			
 jQuery(document).ready(function($) {

 var loc = location.search.substring(1, location.search.length);
 
    var param_value = false;
 var params = loc.split("&");
 var schName = params[0].substring(params[0].indexOf('=')+1);
 var virSchName = params[1].substring(params[1].indexOf('=')+1);
 var disName = params[2].substring(params[2].indexOf('=')+1);
 disName = unescape(disName);
 
 disName = " Edit " +disName;
 $("#disName").text(disName);
 
 var json = ""+params[3].substring(params[3].indexOf('=')+1);
 json = json.replace(new RegExp("%22", 'g'), "\"");
 var jsonobj = jQuery.parseJSON(json);
 
 
 var output = [];
  var $data = {
   regionPath : schName,
   scheduleType : "HVAC",
   scheduleName : "HvacMall"
 };
 var $currWeeklySchedule = [];
 var $newWeeklySchedule = [];
    var maskHeight = 600;
    var maskWidth = $(document).width();
    var winH = 500;
    var winW = $(document).width();
    
    var hvacList = [];
    var lightingList = [];
    var generalList = [];
   
    
$.niagara.getVirtualScheduleOffset(schName,virSchName,function(obj){
	if(obj!=null)
		{
			getOffset(obj.virtualOffset);
		}
});
 
function getOffset(obj)
{
	$("#startHourOffset").val(obj.startOffsetHours);
	$("#startMinuteOffset").val(obj.startOffsetMin);
	$("#endHourOffset").val(obj.endOffsetHours);
	$("#endMinuteOffset").val(obj.endOffsetMin);

	$("#effectiveStartOffset").text(obj.effecStartOffsetHours+" hrs : "+obj.effecStartOffsetMin+" min");
	$("#effectiveEndOffset").text(obj.effecEndOffsetHours+" hrs : "+obj.effecEndOffsetMin+" min");

	$("#effectiveStart").text(obj.effecStart);
	$("#effectiveEnd").text(obj.effecEnd);
	
}
 $("#backButton").click(function()
		 {
	 sethref("#backButton");
	 	
});

 

 $("#groupEditSave").click(function(){

  var startHourOffset = $("#startHourOffset").val();
  var startMinuteOffset = $("#startMinuteOffset").val();

  var endHourOffset = $("#endHourOffset").val();
  var endMinuteOffset = $("#endMinuteOffset").val();
  
    $.niagara.saveVirtualScheduleOffset(schName,virSchName,startHourOffset,startMinuteOffset,endHourOffset,endMinuteOffset,function(obj)
    {
      if(obj.value != "false")
      {
    	  //alert("Offsets updated!");
    	  /*$.niagara.getVirtualScheduleOffset(schName,virSchName,function(obj){
    			if(obj!=null)
    				{
    					getOffset(obj.virtualOffset);
    				}
    		});*/
    	  sethref("#groupEditSave");
      }
      else
      {
    	  alert("Please check inputs!");
      }	  
     });
 }); 
 
 
 function sethref(obj)
 {
 	
 	 var arr = params[0].split("/");
 		var sched = arr[arr.length-1];
 		params[0]="";
 		for(var i=0;i<arr.length-1;i++)
 		{	
 			if(i<arr.length-2)
 				params[0] = params[0]+arr[i]+"/";
 			else
 				params[0] = params[0]+arr[i];
 		}
 		var alink = "indexRelative.html?"+params[0]+"&sched="+sched+"&isVirtual="+jsonobj.isVirtual+"&virSchPath="+jsonobj.virSchPath;
 		alink = alink +"&selectedGroupName="+jsonobj.selectedGroupName+"&selectedZoneName="+jsonobj.selectedZoneName+"&selectedSubZoneName="+jsonobj.selectedSubZoneName;
 		$(obj).attr('href',alink);	
 		location.href = alink;

 }
     
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     
    $('#mask').click(function () {
        $(this).hide();
        $('.window').hide();
    });         

 /* Get the metering present datapoint and store its result */
  
 $(window).unload(function() {
 // clearInterval(intr);
 });
 
 /*var intr = setInterval(function(){
  var date = $util.normalizeDate();
  $util.getMonthlySchedule(date,$data.scheduleName);
 },
 20000);*/
 
 //$.niagara.BatchPoll.printPollList();
}); 