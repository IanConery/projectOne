
define(function(require) {

    require('backbone');

    var renderIndicesChart      = require('chart-loader/indices-chart');
    var renderAZTChart          = require('chart-loader/azt-chart');
    
    var renderPredictionChart   = require('chart-loader/predictionChart');
    var PieChartPrediction      = require('chart-loader/pieChartLoader');
    
    var renderPeakEnergyChart   = require('chart-loader/peak-energy-chart');
    var renderKwhChart          = require('chart-loader/kwh-chart');
    var renderStdDeviationChart = require('chart-loader/std-deviation-chart');
     var RealEnergyComparision = require('chart-loader/RealEnergyComparision');

    var renderChart = function(options) {
        switch (options.chartType) {
            case 'azt':
                renderAZTChart(options);
                break;
            case 'indices':
                renderIndicesChart(options);
                break;
            case 'PredictionChart':
                renderPredictionChart(options);
                break;
            case 'peakEnergy':
                renderPeakEnergyChart(options);
                break;
            case 'kwh':
                renderKwhChart(options);
                break;
            case 'stdDeviation':
                renderStdDeviationChart(options);
                break;
            case 'PieChartPrediction':
                PieChartPrediction(options);
                break;
            case 'RealEnergyComparision':
                RealEnergyComparision(options);
                break;        
            default:
                throw "chart type " + options.chartType + " not currently supported";
        }
    };

    return {
        renderChart: renderChart
    };

});


