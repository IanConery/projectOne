// JavaScript Document
/*****************************************************************
 * Name: jquery.niagara-ajax
 * Version: 1.4
 * Date: 7/20/2010
 * Copyright: 2010 Controlco
 *
 * This is a jQuery plug-in library enabling the Ajax code for
 * dealing with Webeye/Niagara and all the related functionality,
 * including many helper and support functions.
 *
 * This code implements most of the internal functionality &
 * callback functions needed for creating polling of the Niagara
 * server for data via AJAX and invoking "set" operations to pass
 * data to update the Niagara server database.
 *****************************************************************/

/*(function(f) {
        window.setTimeout = f(window.setTimeout);   // overwrites the global function!
        window.setInterval = f(window.setInterval); // overwrites the global function!
    })(function(f) {
        return function(c, t) {
            var a = [].slice.call(arguments, 2);    // gathers the extra args
            return f(function() {
                c.apply(this, a);                   // passes them to your function
            }, t);
        };
});*/

;(function() {

    /* Caching was causing a problem. With further testing we might be able
       to remove this... */
    //$.ajaxSetup({cache: false});

    var root = this;
    var $ = root.jQuery;

    /*******************************************************
     * Initialization function
     *
     * We can put any code in here that we need to set
     * the stationData values or do any other code we have
     * to have happen at start-up.
     *******************************************************/
    (function() {

    })();

    $.exists = function(selector) {return ($(selector).length > 0);}
    $.parentExists = function(childSel, parentSel) { return ($(childSel).parent(parentSel).length > 0); }

    /**********************************************************************
     * $.niagaraGet
     *
     * An object that encapsulates everything related to the Niagara/Webeye
     * server functionality in its own namespace. This object is a singleton
     * that contains all the methods and server/station data for accessing
     * the Niagara/Webeye server via jQuery/AJAX.
     ***********************************************************************/
    root.niagaraGet = $.niagaraGet = {

        // We set up some constants here, but they can be overridden through the
        // initialization function (or other initialization functions in other
        // plug-ins), and we can have additional properties added here via
        // jQuery.extend(), etc.
        // ord?station:|file:^nav/Mall%20in%20Columbia/HVAC/CentPlant.nav
        stationData : {
            CSI3_SCHEDULE : '/UserData',
            CSI3_ALARM : '/csi3Alarm',
            //  CSI3_Nav : '/ord?station:|file:^nav/Four%20Seasons/HVAC/ChillerPlant.nav',
            //   CSI3_Nav : '/ord?station:|file:^nav/Mall%20in%20Columbia/HVAC/CentPlant.nav',

             LOGOUT    : '/logout',
             PREFIX_PATH : '/csi3/read?path=',
             PREFIX_WRITE_PATH : '/csi3/write?path=',
             PREFIX_ACTION_PATH : '/csi3/action?path=',
             PREFIX_WATCH_PATH : '/csi3/watch?path=',
             PREFIX_WATCH : '/csi3/watch?',
             PREFIX_BATCH_SUB : '/csi3/watch',
             PREFIX_TREND_PATH : '/csi3/trend?path=',
             LOCALHOST_STRING : "localhost",
             TEST_HOST_PATH: "request.getRemoteAddr",
             /*PREFIX_PATH : 'get_test.php?path=',
             PREFIX_WRITE_PATH : 'invoke_test.php?path=',*/
             APPENDIX_VALUE : 'value=',
             APPENDIX_TREND_PATH : 'timeRange=',
             WATCH_SUBSCRIBE : 'action=subscribe',
             //WATCH_SUBSCRIBER_PREFIX : "subscriber=",
             WATCH_UNSUBSCRIBE : 'action=unsubscribe',
             WATCH_UNSUBSCRIBE_ALL : 'action=unsubscribeAll',
             WATCH_POLL : 'action=poll',
             WRITE_TIMEOUT : 5000,
             BATCH_POLL_ID : 'id',
             BATCH_POLL_INTERVAL : 5000,
             DEFAULT_DT : 'json', // Default datatype for Ajax requests is JSON
             IMAGE_OK : 'images/green-LED-20.png', // These can be initialized from somewhere else.
             IMAGE_ALARM : 'images/red-LED-20.png', // These can be initialized from somewhere else.
             IMAGE_DOWN : 'images/yellow-LED-20.png', // These can be initialized from somewhere else.
             IMAGE_FAULT : 'images/gold-LED-20.png', // These can be initialized from somewhere else.
             IMAGE_OVERRIDEN : 'images/blue-LED-20.png', // These can be initialized from somewhere else.
             IMAGE_NULL : 'images/black-LED-20.png',
             IMAGE_OFF : 'images/black-LED-20.png',
             IMAGE_DISABLED : 'images/gray-LED-20.png',
             IMAGE_FORBIDDEN : 'images/fuscia-LED-20.png',

             isLocalHost : null,
             HOST_IP : null,
             LOG_BUFFER_SZ : 75
       },

       /*****************************************************************************
        * n_ajax()
        *
        * This method implements the core, low-level AJAX functionality. It makes a
        * call to the jQuery.ajax() method, passing along the parameters and dealing
        * with the context object by either passing it through or binding it to a
        * jQuery.proxy(). Don't mess with this function if you don't know what you're
        * doing. Try to use the higher level methods in $.niagara.Poll,
        * $.niagara.BatchPoll, or the $.niagara.query() method, above.
        *
        *  url - the url to call including the path/datapoint name/value.
        *  callback - the AJAX callback function (if ctxt, will be bound to it)
        *  context - object that is bound to the callback function ("this").
        *  data - additional name/value pair data to be attached to the URL.
        *  dt - the datatype of the call - 'json' is default.
        *****************************************************************************/
   n_ajax : function(url, callback, ctxt, data, dt, err) {
    var sel = null;
    var cb = null;
    var e = function(xhr, status, exception) {
       var a = '$.niagara-ajax: Request failed - ' + this.url  +
          'Status: ' + status + '\n' + 'XHR Status: ' + xhr.status + '\n' +
          'XHR Ready State: ' + xhr.readyState + '\n' + 'Error code:' + exception;
       //console.log(a);
       $.niagaraGet.Alert.error(a, status, xhr);
       //alert(c);
      };
    if (err)
     e = err;
    if (ctxt == null) {
     //console.log("ctxt was null");
     cb = callback; // if there's no ctxt, then just pass the callback through...
    }
    else if (typeof ctxt == "string") {
    //console.log("ctxt was typeof String");
     sel = $(ctxt); // if the ctxt is a string get a selector object.
     cb = $.proxy(callback, sel);
    }
    else if (typeof ctxt == "object")
    {
     //console.log("ctxt was typeof Object");
     sel = ctxt; // if the ctxt is already an object, bind the proxy to it.
     cb = $.proxy(callback, sel);
    }

    var ajaxConfig = {
        url: url,  // Niagara server URL path goes here...tested successfully with dummy PHP file...
        data: data,
        context: sel,
        type:  'GET',   // All operations will be "GET" apart from the Batch Subscribe for 'watch'...
        dataType: 'text',
        success: cb,
        error: e
     };

      $.ajax(ajaxConfig);
    sel = null;
    cb = null;
   },

   /********************************************************************
    * checkSuccess()
    *
    * We need to use this to check the status of 'xhr' in our callback
    * functions because some funkiness can happen with our call that
    * needs to be passed up to our higher level console application
    * functionality, etc, and it needs to know if the server is
    * unavailable, etc. See the comment in the below section of code,
    * for details.
    *
    * xhr - the xhr object returned in the jQuery.ajax request callback.
    *********************************************************************/
   checkSuccess : function(xhr) {

    if (xhr.status == "200" && xhr.statusText == "OK") {
     return true;
    }
    else if (xhr.status == "0" && xhr.readyState == "4") {
     /***************************************************************
      * The W3C spec apparently says that a network abort is
      * defined as XHR status == 0 and XHR readyState == 4,
      * unforuntately it's treated as "success" by jQuery as a result.
      ****************************************************************/
     var a = '$.niagara - Network error: Ajax request aborted because network or server may not be available. XHR Status: ' + xhr.status + ' XHR Ready State: ' + xhr.readyState;
     //alert(a);
     //console.log(a);
     $.niagaraGet.Alert.error(a, status, xhr);
     return false;
    }
    else {
     var b = '$.niagara - Unknown error: Ajax returned unknown condition - server may not be available. XHR Status: ' + xhr.status + ' XHR Ready State: ' + xhr.readyState;
     //console.log(a);
     $.niagaraGet.Alert.error(b, status, xhr);
     //alert(b);
     return false;
    }
   },
     getUserLogin : function(path,callback, context){
     try {
      if (path) {
       var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
    //   var data = 'json={"'+path+'"}';
       var data = path;
       this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },
      getNavFile : function(path,callback, context){
     try {
      if (path) {
       var url = path // eg. + setpoint.toString()
    //   var data = 'json={"'+path+'"}';
       var data = "";
       this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },
     //To update alarm info, once notes are saved by user.
    getProfileInfo : function(path,siteStr,callback, context){
     try {
      if (path) {
       var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
       var data = 'json={"action":"getProfileInfo","path":"'+path+'","siteInfo":"'+siteStr+'"}';
       this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },
     
     setAttributes : function(path,data,callback, context){
        try {
          if (path) {
            var url = 'http://172.28.20.16/prophet';  // eg. + setpoint.toString()
             var data = data;
             this.n_ajax( url,callback, context, data, "xml");
            }
          }
         catch(ex) {
         $.niagara.Alert.exception(ex);
           }
         },
       //To retrieve attributes for nodes
    getAttr : function(path,ord,callback, context){
     try {
      if (path) {
      var url = $.niagaraGet.stationData.CSI3_SCHEDULE;
          var data = 'json={"action":"getAttr","path":"'+path+'","ordInfo":"'+ord+'"}';
          this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },   //updateAttr
     updateAttr : function(path,ord,data,callback, context){
     try {
      if (path) {
      var url = $.niagaraGet.stationData.CSI3_SCHEDULE;
          var data = 'json={"action":"updateAttr","path":"'+path+'","ordInfo":"'+ord+'","data":"'+data+'"}';
          this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },
      //To retrieve child attributes for nodes
      getChildAttr : function(path,ord,callback, context){
     try {
      if (path) {
        var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
          var data = 'json={"action":"getChildAttr","path":"'+path+'","ordInfo":"'+ord+'"}';
          this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },
     redirectMap : function(path,loc,callback, context){
     try {
      if (path) {
       var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
       var data = 'json={"action":"redirectMap","path":"'+path+'","windowLoc":"'+loc+'"}';
       this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },
      getAlarms : function(path,index,noOfAlarms,callback, context){
    try {
     if (path) {
      var url = $.niagaraGet.stationData.CSI3_ALARM;  // eg. + setpoint.toString()
      var data = 'json={"action":"getAlarms","index":"'+index+'","noOfAlarms":"'+noOfAlarms+'","source":"'+path+'"}';
     // alert(data);
      this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
     }
    }
    catch(ex) {
     $.niagara.Alert.exception(ex);
    }
    },
       //To update alarm info, once notes are saved by user.
  /*  updateProfileInfo : function(path,siteStr,callback, context){
     try {
      if (path) {
       var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
       var data = 'json={"action":"updateProfileInfo","path":"'+path+'","siteInfo":"'+siteStr+'"}';
       this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     }*/
    //To update alarm info, once notes are saved by user.
    getOrdInfo : function(path,siteStr,callback, context){
     try {
      if (path) {
       var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
       var data = 'json={"action":"getOrdInfo","path":"'+path+'","siteInfo":"'+siteStr+'"}';
       this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },
    //To update alarm info, once notes are saved by user.
    updateAlarmsSaveNotes : function(path,uuid,puid,notes,callback, context){
     try {
      if (path) {
       var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
       var data = 'json={"action":"updateAlarmsSaveNotes","path":"'+path+'","uuid":"'+uuid+'","puid":"'+puid+'","notestext":"'+notes+'"}';
       alert("update alarm"+data);
       //var data = 'json={"action":"editSchedule","path":"'+path+'","eventName":"'+eventName+'","startHour":"'+startHour+'","startMin":"'+startMin+'","endHour":"'+endHour+'","endMin":"'+endMin+'","startAmPm":"'+startAmPm+'","endAmPm":"'+endAmPm+'","skipDays":"'+skipDays+'","editEventEditStartMode":"'+editEventEditStartMode+'","editEventEditEndMode":"'+editEventEditEndMode+'","eventType":"'+eventType+'"}';
       this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },//
     //To obtain childalarms associated to each puid
     getChildAlarms : function(path,puid,callback, context){
      try {
       if (path) {
        var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
        var data = 'json={"action":"getChildAlarms","path":"'+path+'","puid":"'+puid+'"}';
       // alert("child alarm"+data);
       // var data = 'json={"action":"editSchedule","path":"'+path+'","eventName":"'+eventName+'","startHour":"'+startHour+'","startMin":"'+startMin+'","endHour":"'+endHour+'","endMin":"'+endMin+'","startAmPm":"'+startAmPm+'","endAmPm":"'+endAmPm+'","skipDays":"'+skipDays+'","editEventEditStartMode":"'+editEventEditStartMode+'","editEventEditEndMode":"'+editEventEditEndMode+'","eventType":"'+eventType+'"}';
        this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
       }
      }
      catch(ex) {
       $.niagaraGet.Alert.exception(ex);
      }
      },
     //To retrieve alarm info based on filters
     filter : function(path,priority,state,ackState,timeRange,index,noOfAlarms,callback, context){
      try {
       if (path) {
        var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
        var data = 'json={"action":"filter","path":"'+path+'","priority":"'+priority+'","state":"'+state+'","ackState":"'+ackState+'","timeRange":"'+timeRange+'","index":"'+index+'","noOfAlarms":"'+noOfAlarms+'"}';
       // alert("filter alarm"+data);
        this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
       }
      }
      catch(ex) {
       $.niagaraGet.Alert.exception(ex);
      }
      },
     ackAlarm : function(path,uuid,callback, context){
      try {
       if (path) {
        var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
        var data = 'json={"action":"ackAlarm","path":"'+path+'","uuid":"'+uuid+'"}';
        alert("ackAlarm"+data);
        this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
       }
      }
      catch(ex) {
       $.niagaraGet.Alert.exception(ex);
      }
      },

   /*
   *getChildren : to get children of a particular parent
   *
   */
            getChildren : function(path, callback, context){
    try {
     if (path) {
      var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
      var data = 'json={"action":"getChildren","path":"'+path+'"}';
      this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
     }
    }
    catch(ex) {
     $.niagaraGet.Alert.exception(ex);
    }
    },
                getUser : function(path, data,callback, context){
    try {
     if (path) {
      var url = '/prophet';  // eg. + setpoint.toString()
     // var data = 'json={"action":"getChildren","path":"'+path+'"}';
                                        var data=data;
      this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
     }
    }
    catch(ex) {
     $.niagaraGet.Alert.exception(ex);
    }
    },
   /*
   *getWeeklySchedule : to get weekly schedule of an area
   *
   */
   getMonthlySchedule : function(path, date, callback, context, data){
    try{
     if (path) {
      var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
      var data = 'json={"action":"getMonthlySchedule","path":"'+path+'","date":"'+date+'"}';
      this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
     }
    }
    catch(ex) {
     $.niagaraGet.Alert.exception(ex);
    }
    },

   getWeeklySchedule : function(path, date, callback, context, data){
    try{
     if (path) {
      var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
      var data = 'json={"action":"getWeeklySchedule","path":"'+path+'","date":"'+date+'"}';
      this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
     }
    }
    catch(ex) {
     $.niagaraGet.Alert.exception(ex);
    }
    },
    editDailyEvent : function(path, eventName, startHour, startMin, startAmPm,endHour, endMin, endAmPm,skipDays,editEventEditStartMode,editEventEditEndMode,eventType,callback, context, data){
    try{
     if (path) {
      var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
      var data = 'json={"action":"editSchedule","path":"'+path+'","eventName":"'+eventName+'","startHour":"'+startHour+'","startMin":"'+startMin+'","endHour":"'+endHour+'","endMin":"'+endMin+'","startAmPm":"'+startAmPm+'","endAmPm":"'+endAmPm+'","skipDays":"'+skipDays+'","editEventEditStartMode":"'+editEventEditStartMode+'","editEventEditEndMode":"'+editEventEditEndMode+'","eventType":"'+eventType+'"}';
      this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
     }
    }
    catch(ex) {
     $.niagaraGet.Alert.exception(ex);
    }
    },
    editTradingHoursEvent : function(path, eventName, startHour, startMin, startAmPm,endHour, endMin, endAmPm,skipDays,editEventEditStartMode,editEventEditEndMode,eventType,startOffset,endOffset, callback, context, data){
     try{
      if (path) {
       var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
       var data = 'json={"action":"editSchedule","path":"'+path+'","eventName":"'+eventName+'",';
       var data = data+'"startHour":"'+startHour+'","startMin":"'+startMin+'","endHour":"'+endHour+'",';
       var data = data+'"endMin":"'+endMin+'","startAmPm":"'+startAmPm+'","endAmPm":"'+endAmPm+'",';
       var data = data+'"skipDays":"'+skipDays+'","editEventEditStartMode":"'+editEventEditStartMode+'",';
       var data = data+'"editEventEditEndMode":"'+editEventEditEndMode+'","eventType":"'+eventType+'",';
       var data = data+'"startOffset":"'+startOffset+'","endOffset":"'+endOffset+'"}';
       this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },

    editWeekAndDayEvent : function(path, eventName, startHour, startMin, startAmPm,endHour, endMin, endAmPm,skipDays,editEventEditStartMode,editEventEditEndMode,editDay,editWeek,editMonth,eventType,callback, context, data){

     try{
      if (path) {
       var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
       var data = 'json={"action":"editSchedule","path":"'+path+'","eventName":"'+eventName+'",';
       data = data + '"startHour":"'+startHour+'","startMin":"'+startMin+'","endHour":"'+endHour+'","endMin":"'+endMin+'",';
       data = data + '"startAmPm":"'+startAmPm+'","endAmPm":"'+endAmPm+'","skipDays":"'+skipDays+'",';
       data = data + '"editEventEditStartMode":"'+editEventEditStartMode+'",';
       data = data + '"editEventEditEndMode":"'+editEventEditEndMode+'","editDay":"'+editDay+'","editWeek":"'+editWeek+'",';
       data = data + '"editMonth":"'+editMonth+'","eventType":"'+eventType+'"}';
       this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },
     editOneTimeEvent : function(path, eventName, startHour, startMin, startAmPm,endHour, endMin, endAmPm,editEventEditStartMode,editEventEditEndMode,editDay,editMonth,editYear,eventType,callback, context, data){
      try{
       if (path) {
        var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
        var data = 'json={"action":"editSchedule","path":"'+path+'","eventName":"'+eventName+'",';
        data = data + '"startHour":"'+startHour+'","startMin":"'+startMin+'","endHour":"'+endHour+'","endMin":"'+endMin+'",';
        data = data + '"startAmPm":"'+startAmPm+'","endAmPm":"'+endAmPm+'",';
        data = data + '"editEventEditStartMode":"'+editEventEditStartMode+'",';
        data = data + '"editEventEditEndMode":"'+editEventEditEndMode+'","editDay":"'+editDay+'",';
        data = data + '"editMonth":"'+editMonth+'","editYear":"'+editYear+'","eventType":"'+eventType+'"}';

        this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
       }
      }
      catch(ex) {
       $.niagaraGet.Alert.exception(ex);
      }
      },

    addOneTimeEvent : function(path, eventName, startHour, startMin, startAmPm,endHour, endMin, endAmPm, startTimeMode,endTimeMode,addEventEditDay,addEventEditMonth,addEventEditYear,addEventType,callback, context, data){
     try{
      if (path) {
       var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
       var data = 'json={"action":"addEvent","path":"'+path+'","eventName":"'+eventName+'",';
       data = data+'"startHour":"'+startHour+'","startMin":"'+startMin+'","endHour":"'+endHour+'","endMin":"'+endMin+'",';
       data = data+'"startAmPm":"'+startAmPm+'","endAmPm":"'+endAmPm+'","startTimeMode":"'+startTimeMode+'",';
       data = data+'"endTimeMode":"'+endTimeMode+'","addEventType":"'+addEventType+'","addEventEditDay":"'+addEventEditDay+'","addEventEditMonth":"'+addEventEditMonth+'","addEventEditYear":"'+addEventEditYear+'"}';
       this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
      }
     }
     catch(ex) {
      $.niagaraGet.Alert.exception(ex);
     }
     },
     addWeekAndDayEvent : function(path, eventName, startHour, startMin, startAmPm,endHour, endMin, endAmPm, startTimeMode,endTimeMode,editWeekDay,editWeek,editMonth,addEventType,callback, context, data){
      try{
       if (path) {
        var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
        var data = 'json={"action":"addEvent","path":"'+path+'","eventName":"'+eventName+'",';
        data = data+'"startHour":"'+startHour+'","startMin":"'+startMin+'","endHour":"'+endHour+'","endMin":"'+endMin+'",';
        data = data+'"startAmPm":"'+startAmPm+'","endAmPm":"'+endAmPm+'","startTimeMode":"'+startTimeMode+'",';
        data = data+'"endTimeMode":"'+endTimeMode+'","addEventType":"'+addEventType+'","editWeekDay":"'+editWeekDay+'","editWeek":"'+editWeek+'","editMonth":"'+editMonth+'"}';
        this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
       }
      }
      catch(ex) {
       $.niagaraGet.Alert.exception(ex);
      }
      },
      getEventType : function(path, eventName, callback, context, data){
       try{
        if (path) {

         var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
         var data = 'json={"action":"getEventType","path":"'+path+'","eventName":"'+eventName+'"}';
         this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
        }
       }
       catch(ex) {
        $.niagaraGet.Alert.exception(ex);
       }
       },
       deleteEvent : function(path, eventName, eventType,callback, context, data){
        try{
         if (path) {

          var url = $.niagaraGet.stationData.CSI3_SCHEDULE;  // eg. + setpoint.toString()
          var data = 'json={"action":"deleteEvent","path":"'+path+'","eventName":"'+eventName+'","eventType":"'+eventType+'"}';
          this.n_ajax(url, callback, context, data, $.niagaraGet.stationData.DEFAULT_DT);
         }
        }
        catch(ex) {
         $.niagaraGet.Alert.exception(ex);
        }
        },

   /************************************************************************
    * read
    *
    * A function that gets a Niagara datapoint. A quick read that bypasses
    * the query() call when the need is just to get a datapoint without
    * any need of interval/polling, etc.
    *
    * path - path/datapoint to be set
    * callback - a callback function to handle the results (true/false)
    * context - a context object (selector) to be bound to the callback
    ***********************************************************************/
   read : function(path, callback, context) {
    try {
     if (path) {
      var url = $.niagaraGet.stationData.PREFIX_PATH + path;  // eg. + setpoint.toString()
      //console.log("writeURL: " + url);
      this.n_ajax(url, callback, context, null, $.niagaraGet.stationData.DEFAULT_DT);
     }
    }
    catch(ex) {
     $.niagaraGet.Alert.exception(ex);
    }
   },

   /************************************************************************
    * write
    *
    * A function that sets a Niagara datapoint by passing
    * the Niagara server a value in the URL "GET".  We call
    * $.niagaraGet.query(), but this function might expand to do a few
    * different things in the future, so we want to implement it
    * separately.
    *
    * path - path/datapoint to be set
    * data - data that contains the value to be set for the path/datapoint.
    * callback - a callback function to handle the results (true/false)
    * context - a context object (selector) to be bound to the callback
    ***********************************************************************/
   write: function(path, data, callback, context) {
    try {
     var e = function(xhr, status, exception) {
       var a = '$.niagara-ajax: Request failed - Path: '  + this.path +
          'Status: ' + status + '\n' + 'XHR Status: ' + xhr.status + '\n' +
          'XHR Ready State: ' + xhr.readyState + '\n' + 'Error code:' + exception;
       //console.log(a);
       //console.log("Write error routine");
       $.niagaraGet.Alert.error(a, status, xhr);
       if ($.exists('#loadingMask')) {
        $('#loadingMask').fadeOut(200, function() {
         $(this).remove();
        });
       }
     };
     var url = $.niagaraGet.stationData.PREFIX_WRITE_PATH + path;  // eg. + setpoint.toString()
     //console.log("writeURL: " + url);
     var namevals = $.niagaraGet.stationData.APPENDIX_VALUE + data.toString();
     //console.log("writenamevals: " + namevals);
     this.n_ajax(url, callback, context, namevals, $.niagaraGet.stationData.DEFAULT_DT, e);
    }
    catch(ex) {
     $.niagaraGet.Alert.exception(ex);
    }
   },

   /************************************************************************
    * action
    *
    * A function that calls a Niagara object "action" with optional params.
    *
    * path - path/datapoint to a Niagara object
    * data - data that contains the param for the Niagara object.
    * callback - a callback function to handle the results (true/false)
    * context - a context object (selector) to be bound to the callback
    ***********************************************************************/
   action: function(path, data, callback, context) {
    try {
     var url = $.niagaraGet.stationData.PREFIX_ACTION_PATH + path;  // eg. + setpoint.toString()
     //console.log("writeURL: " + url);
     var namevals = null;
     if (data) {
      namevals = $.niagaraGet.stationData.APPENDIX_VALUE + data.toString();
     }
     else {
      namevals = $.niagaraGet.stationData.APPENDIX_VALUE + "null";
     }
     //console.log("writenamevals: " + namevals);
     this.n_ajax(url, callback, context, namevals, $.niagaraGet.stationData.DEFAULT_DT);
    }
    catch(ex) {
     $.niagaraGet.Alert.exception(ex);
    }
   },
   /************************************************************************
    * watch
    *
    * A method that makes a 'watch' call for "batch polls" through n_ajax.
    *
    * action - "action=": subscribe, poll, unsubscribe, unsubscribeAll
    * id - subscriber name of the batch poll object.
    * callback - a callback function to handle the results (true/false)
    * context - a context object (selector) to be bound to the callback
    * path - path/datapoint to watch
    ***********************************************************************/
   watch : function(action, id, callback, context, path) {
    try {
     var url;
     if (action == $.niagaraGet.stationData.WATCH_SUBSCRIBE || action == $.niagaraGet.stationData.WATCH_UNSUBSCRIBE) {
      url = $.niagaraGet.stationData.PREFIX_WATCH_PATH + path;
     }
     else {
      url = $.niagaraGet.stationData.PREFIX_WATCH;
     }

     var namevals = action + '&' + $.niagaraGet.stationData.BATCH_POLL_ID + '=' + id;
     this.n_ajax(url, callback, context, namevals, $.niagaraGet.stationData.DEFAULT_DT);
    }
    catch(ex) {
     $.niagaraGet.Alert.exception(ex);
    }
   },
   /************************************************************************
    * trend
    *
    * A method that gets a trend for a datapoint through n_ajax.
    *
    * path - path/datapoint to be queried.
    * data - data that contains the value to be sent with the request.
    * callback - a callback function to handle the results (true/false)
    * context - a context object (selector) to be bound to the callback
    ***********************************************************************/
   trend : function(path, data, callback, context) {
    try {
     var url = $.niagaraGet.stationData.PREFIX_TREND_PATH + path;  // eg. + setpoint.toString()
     //console.log("writeURL: " + url);
     var namevals = $.niagaraGet.stationData.APPENDIX_TREND_PATH + data.toString();
     //console.log("writenamevals: " + namevals);
     this.n_ajax(url, callback, context, namevals, $.niagaraGet.stationData.DEFAULT_DT);
    }
    catch(ex) {
     $.niagaraGet.Alert.exception(ex);
    }
   },


   /*******************************************************************
    * Niagara Alert
    *
    * Abstracts the calling of errors, info, and exceptions. Callback
    * functions can be registered for all three types and the lower
    * level layer in this plug-in can writethem at the higher level.
    * Defaults to simple "alert()" messages if there are no registered
    * callback functions.
    *
    * classes - If this parameter is passed in as a string of (one or
    *    more) classes, they will be passed to the callback so
    *           the callback code can optionally apply the classes to
    *           add additional styles to the message text.
    *******************************************************************/
    Alert : {
        error_callback : null,
        info_callback : null,
        exception_callback : null,
        update_log : null,

        setAlertCallback : function(f) {
            this.error_callback = f;
        },

        setInfoCallback : function(f) {
            this.info_callback = f;
        },

        setExceptionCallback : function(f) {
            this.exception_callback = f;
        },

        setUpdateLog : function(f) {
            this.update_log = f;
        },

        error : function(alrt, status, xhr, classes) {
            /*
            if (!this.error_callback)
                alert("Error: " + alrt + "\n" + "Status: " + status + "\n" + "XHR: " + xhr);
            else
                this.error_callback(alrt, status, xhr, classes);
            */
        },

        info : function(alrt, status, xhr, classes) {
            if (!this.info_callback)
                alert("Alert: " + alrt + "Status: " + status + "\n" + "XHR: " + xhr);
            else
                this.info_callback(alrt, status, xhr, classes);
        },

        exception : function(ex) {
            if (!this.exception_callback)
                console.log("A System Error Occured: ", ex);
//                alert("A System Error Occured: " + ex);
            else
                this.exception_callback(ex);
        },

        updateLog : function() {
            if (!this.update_log) {
                alert("Update Log: could not update the log because handler was not registered.");
            }
            else
                this.update_log();
          }
   },

   /*********************************************************
    * testLocalHost
    *
    * This is only a simple way to test if the request is
    * from the localhost. Something from the server should
    * validate/insure localhost requests, since we also
    * have to log-in to the server anyway. We'll call that
    * method from here...
    *********************************************************/
    testLocalHost : function() {
    //if ($.niagaraGet.isLocalHost && $.niagaraGet.isLocalHost == true)
    //  console.log("We are on the localhost: IP Address = " + $.niagaraGet.stationData.HOST_IP);
    //else
    // console.log("Sorry, we're not on the localhost!: IP Address = " + $.niagaraGet.stationData.HOST_IP);
    return $.niagaraGet.stationData.isLocalHost;
    },

    getLocalHost : function() {
    $.niagaraGet.read($.niagaraGet.stationData.TEST_HOST_PATH,
         function(result, status, xhr) {
        if ($.niagaraGet.checkSuccess(xhr)) {
         if (result && result.status == "ok" && result.value) {
          if (result.value == "127.0.0.1" ||
           result.value == "localhost") {
           $.niagaraGet.stationData.isLocalHost = true;
          }
          else {
           $.niagaraGet.stationData.isLocalHost = false;
          }

          $.niagaraGet.stationData.HOST_IP = result.value;
         }
         else {
          $.niagaraGet.Alert.info("Niagara/Webeye Info: getLocalHost: could not obtain Host information from server", status, xhr);
         }
        }
         },
         null);
   },

   /*****************************************************************
    * resultHandler
    *
    * A generic/universal method for processing the results of a
    * callback made by any of the $.niagaraGet methods (read, watch).
    * The method will deal with most situations for an appliance
    * application by applying values to either image (indicator
    * light) graphics or HTML/text DOM types such as <p>  or <input>
    * types. For anything else you can override this with a custom
    * callback supplied to those same methods.
    *
    * context - object (selector) that results will be applied to
    * path - path to a datapoint
    * value - value returned in the callback: result.value
    * m - status returned in the callback: result.status
    * append - string to be appended to the value (i.e. "%")
    *****************************************************************/
    resultHandler : function (context, path, value, m, append, writeFail) {
    //console.log("Inside $.niagaraGet.resultHandler: Context = " + context + " Value = " + value + " Message = " + m + " Append = " + append);
    var msg = null;
    if (m) {
     var arr = m.split(',');
     msg = arr[0];
    }
    //console.log("msg = " + msg);
    var select = $(context);
    if (select.is('img')) {
     var source = null;
     switch(msg) {
      case 'ok':
       if (value == "true" || value == 1 || value == true)
        source = $.niagaraGet.stationData.IMAGE_OK;
       else
        source = $.niagaraGet.stationData.IMAGE_OFF;
       break;
      case 'forbidden':
       source = $.niagaraGet.stationData.IMAGE_FORBIDDEN;
       break;
      case 'disabled':
       source = $.niagaraGet.stationData.IMAGE_DISABLED;
       break;
      case 'overriden':
       source = $.niagaraGet.stationData.IMAGE_OVERRIDEN;
       break;
      case 'fault':
       source = $.niagaraGet.stationData.IMAGE_FAULT;
       break;
      case 'alarm':
       source = $.niagaraGet.stationData.IMAGE_ALARM;
       break;
      case 'down':
       source = $.niagaraGet.stationData.IMAGE_DOWN;
       break;
      case 'null':
       source = $.niagaraGet.stationData.IMAGE_NULL;
       break;
      default:
       source = $.niagaraGet.stationData.IMAGE_OFF;
       break;
     }
     select.attr('src', source);
    }
    else {
     var val = null;
     if (msg == 'ok') {
      if (select.is('input:checkbox') || select.is('input:radio')) {
       val = value.toString();
      }
      else {
       val = value.toString();
       if (append)
        val += append;
      }
     }
     else if (msg != 'ok') {
      if (select.is('input:checkbox') || select.is('input:radio')) {
       val = value.toString();
      }
      else {
       val = msg;
      }
     }
     else {
      val = msg;
     }

     //console.log("Val= " + value);
     var ibtn = $.parentExists(context, '.ibutton-container');

     switch(msg) {
      case 'ok':
       if (ibtn) {
        select.parent('.ibutton-container').removeClass('ibutton-response-disabled ibutton-response-fault ibutton-response-unackedAlarm ibutton-response-null ibutton-response-down ibutton-response-alarm ibutton-response-stale ibutton-response-overriden ibutton-fail ibutton-response-forbidden').addClass('ibutton-ok');
       }
       else {
        select.removeClass('response-disabled response-fault response-unackedAlarm response-null response-down response-alarm response-stale response-overriden write-fail input-fail response-forbidden').addClass('response-ok');
       }
       break;
      case 'forbidden':
       if (ibtn) {
        select.parent('.ibutton-container').removeClass('ibutton-response-disabled ibutton-response-fault ibutton-response-unackedAlarm ibutton-response-null ibutton-response-down ibutton-response-alarm ibutton-response-stale ibutton-response-overriden ibutton-fail ibutton-ok').addClass('ibutton-response-forbidden');
       }
       else {
        select.removeClass('response-disabled response-fault response-unackedAlarm response-null response-down response-alarm response-stale response-overriden write-fail input-fail response-ok').addClass('response-forbidden');
       }
       break;
      case 'fault':
       if (ibtn) {
        select.parent('.ibutton-container').removeClass('ibutton-response-disabled ibutton-response-unackedAlarm ibutton-response-null ibutton-response-down ibutton-response-alarm ibutton-response-stale ibutton-response-overriden ibutton-ok ibutton-fail ibutton-response-forbidden').addClass('ibutton-response-fault');
       }
       else {
        select.removeClass('response-ok response-disabled response-down response-unackedAlarm response-null response-alarm response-stale response-overriden write-fail response-forbidden').addClass('response-fault');
       }
       break;
      case 'disabled':
       if (ibtn) {
        select.parent('.ibutton-container').removeClass('ibutton-response-fault ibutton-response-unackedAlarm ibutton-response-null ibutton-response-down ibutton-response-alarm ibutton-response-stale ibutton-response-overriden ibutton-ok ibutton-fail ibutton-response-forbidden').addClass('ibutton-response-disabled');
       }
       else {
        select.removeClass('response-ok response-fault response-down response-unackedAlarm response-null response-alarm response-stale response-overriden write-fail response-forbidden').addClass('response-disabled');
       }
       break;
      case 'down':
       if (ibtn) {
        select.parent('.ibutton-container').removeClass('ibutton-ok ibutton-response-fault ibutton-response-unackedAlarm ibutton-response-null ibutton-response-disabled ibutton-response-alarm ibutton-response-stale ibutton-response-overriden ibutton-fail ibutton-response-forbidden').addClass('ibutton-response-down');
       }
       else {
        select.removeClass('response-ok response-disabled response-unackedAlarm response-null response-fault response-alarm response-stale response-overriden write-fail response-forbidden').addClass('response-down');
       }
       break;
      case 'alarm':
       if (ibtn) {
        select.parent('.ibutton-container').removeClass('ibutton-ok ibutton-response-fault ibutton-response-unackedAlarm ibutton-response-null ibutton-response-disabled ibutton-response-down ibutton-response-stale ibutton-response-overriden ibutton-fail ibutton-response-forbidden').addClass('ibutton-response-alarm');
       }
       else {
        select.removeClass('response-ok response-disabled response-unackedAlarm response-null response-fault response-down response-stale response-overriden write-fail response-forbidden').addClass('response-alarm');
       }
       break;
      case 'stale':
       if (ibtn) {
        select.parent('.ibutton-container').removeClass('ibutton-ok ibutton-response-fault ibutton-response-unackedAlarm ibutton-response-null ibutton-response-disabled ibutton-response-down ibutton-response-alarm ibutton-response-overriden ibutton-fail ibutton-response-forbidden').addClass('ibutton-response-stale');
       }
       else {
        select.removeClass('response-ok response-disabled response-unackedAlarm response-null response-fault response-down response-alarm response-overriden write-fail response-forbidden').addClass('response-stale');
       }
       break;
      case 'overriden':
       if (ibtn) {
        select.parent('.ibutton-container').removeClass('ibutton-ok ibutton-response-fault ibutton-response-unackedAlarm ibutton-response-null ibutton-response-disabled ibutton-response-down ibutton-response-alarm ibutton-response-stale ibutton-fail ibutton-response-forbidden').addClass('ibutton-response-overriden');
       }
       else {
        select.removeClass('response-ok response-disabled response-unackedAlarm response-null response-fault response-down response-unackedAlarm response-alarm response-stale write-fail response-forbidden').addClass('response-overriden');
       }
       break;
      case 'unackedAlarm':
       if (ibtn) {
        select.parent('.ibutton-container').removeClass('ibutton-ok ibutton-response-fault ibutton-response-overriden ibutton-response-null ibutton-response-disabled ibutton-response-down ibutton-response-alarm ibutton-response-stale ibutton-fail ibutton-response-forbidden').addClass('ibutton-response-unackedAlarm');
       }
       else {
        select.removeClass('response-ok response-disabled response-alarm response-null response-fault response-down response-stale response-overriden write-fail response-forbidden').addClass('response-unackedAlarm');
       }
       break;
      case 'null':
      case null:
       if (ibtn) {
        select.parent('.ibutton-container').removeClass('ibutton-ok ibutton-response-fault ibutton-response-overriden ibutton-response-unackedAlarm ibutton-response-disabled ibutton-response-down ibutton-response-alarm ibutton-response-stale ibutton-fail ibutton-response-forbidden').addClass('ibutton-response-null');
       }
       else {
        select.removeClass('response-ok response-fault response-down response-unackedAlarm response-alarm response-stale response-overriden write-fail response-forbidden').addClass('response-null');
       }
       break;
      case 'failure':
       if (value == "forbidden") {
        $.niagaraGet.Alert.error("Niagara/Webeye System Error: " + path + " : write response failure - permission denied", null, null);
       }
       else {
        $.niagaraGet.Alert.error("Niagara/Webeye System Error: " + path + " : write response failure", null, null);
       }
       break;
      default:
       $.niagaraGet.Alert.error("Niagara/Webeye System Error: $.niagaraGet.resultHandler: msg was undefined", null, null);
       break;
     }

     if (select.is('input:checkbox') || select.is('input:radio')) {
      if (val == true || val == "true" || val == "on" && writeFail != true) {
       if (ibtn)
        select.iButton('toggle', true);
       else
        select.attr('checked', true);
      }
      else if (val == false || val == "false" || val == "off" && writeFail != true) {
       if (ibtn)
        select.iButton('toggle', false);
       else
        select.attr('checked', false);
      }
      else {
       if (ibtn) {
        select.parent('.ibutton-container').addClass('ibutton-fail');
        if (select.is(':checked')) {
         select.iButton('toggle', false);
        }
        else {
         select.attr('toggle', true);
        }
       }
       else {
        select.addClass('ibutton-fail');
        if (select.is(':checked')) {
         select.attr('checked', false);
        }
        else {
         select.attr('checked', true);
        }
       }
      }
     }
     else if (select.is('select')) {
      if (msg == 'ok') {
       if (val == 'true') {
        select.add('option', context).find("option[value='true']").attr("selected","selected");
        //select.val('true');
       }
       else {
        select.add('option', context).find("option[value='false']").attr("selected","selected");
        //select.val('false');
       }
       $(context).add('option', context).find("option[value='error']").remove();
      }
      else {
       var exists = false;
       select.add('option', context).children().each(function() {
        if ($(this).attr('value') == 'error') {
         $(this).attr("selected","selected");
         exists = true;
        }
       });

       if (exists == false) {
        var o = $(context);
        o.append($("<option></option>").attr("value", "error").text(msg));
        $(o).add('option', context).find("option[value='error']").attr("selected","selected");
        o = null;
       }
      }

      if(writeFail && writeFail == true) {
       select.addClass('write-fail');
      }
     }
     else if (select.is('input:text')) {
      select.empty().val(val);
      if(writeFail && writeFail == true) {
       select.addClass('write-fail');
      }
     }
     else {
      select.empty().html(val.toString());
      if(writeFail && writeFail == true) {
       select.addClass('write-fail');
      }
     }
    }


    if (msg != 'ok')
     $.niagaraGet.Alert.error("Niagara/Webeye Read/Write Error: " + path + " Status: " +
             m + " @time: " + new Date().toString(), null, null);
    msg = null;
    select = null;
   }
 }



 /***********************************************************************************
  * $.niagaraGet.Poll
  *
  * Implements the functionality required for setting up polling of a
  * an individual path/datapoint in the Niagara/Webeye server.
  *
  * url - path/datapoint to poll
  * interval - frequency to poll the point in milliseconds
  *           (e.g. 6000 = 6 seconds, 60000 = 1 minute, 60000 * 60 = 1 hour, ...)
  * selector - The CSS selector (".main-img", "#p1", etc) for the poll and
  *     callback - the selector will be bound as the context of the callback.
  * callback - the callback function to invoke for the returned data.
  *            function(result, status, xhr) is required format.
  *            IMPORTANT: Call $.niagaraGet.checkSuccess(xhr) within the function to
  *            check for success of the call or server timeout/unavailability error.
  * append - A string to append to results (i.e., "%").
  *
  ***********************************************************************************/
 $.niagaraGet.Poll = {
  polls : {},

  startPoll : function (url, interval, selector, callback, append) {
   if (!url || !interval || !selector || !callback)
    return false;

   if (this.polls == null)
    this.polls = {};

   try {
    //console.log("$.niagaraGet.Poll.startPoll - interval = " + interval + " selector = " + selector + " url = " + url + " callback = " + callback);
    var temp_id = setInterval(pollCallback, interval, selector, url, callback);

    if (!this.polls[url]) {
     this.polls[url] = [];
    }
    this.polls[url].push({'id' : temp_id, 'interval' : interval, 'selector' : selector, 'append' : append});
    return temp_id;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },


  /*************************************************************
   * pollValue()
   *
   * Automatically poll a value (path) for a given interval,
   * and set the results for the selector (if the selector is
   * a class - e.g. '.main-img' - then the polled value will
   * be set for every DOM object tied to that selector). This
   * method should only be used for DOM objects that are
   * simple text values - e.g. <p> or <input type="textbox">
   *************************************************************/
  pollValue : function(selector, path, interval, append) {
   try {
    var id = setInterval(pollCallback, interval, selector, path, pollValueCallback);
    $.niagaraGet.Poll.setPoll(path, interval, id, selector, append);
    return id;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  /*****************************************************************
   * pollImage()
   *
   * Automatically poll a value (path) for a given interval,
   * and toggle the results for the image selector (if the
   * selector is a class - e.g. '.main-img' - then the polled
   * value will toggle the image of every DOM object tied to
   * that selector). This method should only be used for type
   * '<img>', using the default images supplied in
   * $.niagaraGet.stationData. If you need a more complex
   * image toggling/state method, implement the callback logic
   * yourself, and use the standard $.niagaraGet.Poll object methods
   * to start the poll (or set the poll yourself).
   *
   * NOTE: See the code in 'control-panel.js' for pollMainBurner()
   * or pollPilotBurner() for an example of how you might do this.
   ****************************************************************/
  pollImage : function(selector, path, interval) {
   try {
    var id = setInterval(pollCallback, interval, selector, path, pollImageCallback);
    $.niagaraGet.Poll.setPoll(path, interval, id, selector);
    return id;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  /*************************************************************
   * pollTrend()
   *
   * Automatically poll a trend (path) for a given interval,
   * and set the results for the selector (if the selector is
   * a class - e.g. '.main-img' - then the polled value will
   * be set for every DOM object tied to that selector).
   *************************************************************/
  pollTrend : function(path, data, callback, context, interval) {
   try {
    var id = setInterval(pollTrendCallback, interval, path, data, callback, context);
    $.niagaraGet.Poll.setPoll(path, interval, id, context, null);
    return id;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  /****************************************************************
   * setPoll
   *
   * Use this method if you've created a poll outside this object
   * by calling setInterval() yourself. The poll will be added to
   * the $.niagaraGet.Poll list so that your poll will be tracked and
   * terminated along with all the polls created by
   * $.niagaraGet.Poll.startPoll().
   ****************************************************************/
  setPoll : function(url, interval, id, selector, append) {
   if (!url || !interval || !id || !selector)
    return false;

   if (!this.polls)
    this.polls = {};

   try {

    if (!this.polls[url]) {
     this.polls[url] = [];
    }
    this.polls[url].push({'id' : id, 'interval' : interval, 'selector' : selector, 'append' : append});
    return true;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  /* Return the poll object for a given path/url */
  getPoll : function(url) {
   if (!url || !this.polls) {
    return null;
   }
   else {
    return this.polls[url];
   }
  },

  /* Return the path for a given poll by id (id that was supplied by setInterval() */
  getPathByID : function(id) {
   if (!id || !this.polls)
    return null;
   for (url in this.polls) {
    for (x = 0; x < this.polls[url].length; x++ ) {
     if(id == this.polls[url][x].id)
      return url;
    }
   }
   return null;
  },

  /* Return the poll object for a given id (id that was supplied by setInterval() */
  getPollByID : function(id) {
   if (!this.polls)
    return null;

   for (url in this.polls) {
    for (x = 0; x < this.polls[url].length; x++ ) {
     if(id == this.polls[url][x].id)
      return this.polls[url][x];
    }
   }
   return null;
  },

  /* Return the poll object for a given selector if it exists */
  getPollBySelector : function(sel) {
   if (!this.polls)
    return null;

   var arr = [];
   for (url in this.polls) {
    for (x = 0; x < this.polls[url].length; x++ ) {
     var tmp = this.polls[url][x].selector;
     var selector = $(tmp);
     if(sel == selector)
      arr.push(this.polls[url][x]);
    }
   }
   return arr;
  },

  /* Return the poll object for a specific path and selector if it exists */
  getPollByPathSelector : function(url, sel) {
   if (!this.polls || !this.polls[url])
    return null;

   for (x = 0; x < this.polls[url].length; x++ ) {
    var tmp = this.polls[url][x].selector;
    var selector = $(tmp);
    if(sel == selector) {
     return this.polls[url][x];
    }
   }
   return null;
  },

  /* Stop the poll object associated with the supplied id */
  stopPollByID : function(id) {
   if (!id || !this.polls)
    return false;
   try {
    for (url in this.polls) {
     for (x = 0; x < this.polls[url].length; x++ ) {
      if (id == this.polls[url][x].id) {
       //console.log('Inside stopPollByID...ID = ' + this.polls[url].id);
       /* Clear the poll */
       clearInterval(this.polls[url][x].id);
       this.polls[url][x].id = null;
       //console.log("Interval = " + this.polls[url].interval);
       this.polls[url][x].interval = null;
       this.polls[url][x].selector = null;
       this.polls[url][x].append = null;
       this.polls[url][x] = null;
       /* Then remove the object */
       return true;
      }
     }
    }
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  /* Stop the poll for the object associated with the supplied path */
  stopPoll : function(url) {
   if (!url || !this.polls)
    return false;

   try {
    if (this.polls[url]) {
     for (x = 0; x < this.polls[url].length; x++ ) {
     // console.log("Clearing Poll: " + url);
      clearInterval(this.polls[url][x].id);
     // console.log("Clearing polls...for ID = " + this.polls[url][x].id);
      this.polls[url][x].id = null;
     // console.log("Clearing polls...interval = " + this.polls[url][x].interval);
      this.polls[url][x].interval = null;
     // console.log("Clearing polls...selector = " + this.polls[url][x].selector);
      this.polls[url][x].selector = null;
      this.polls[url][x].append = null;
      this.polls[url][x] = null;
      delete this.polls[url][x];
     }
     delete this.polls[url];
     return true;
    }
    else
     return false;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  /* Clear all polls from the object */
  clearAll : function() {
   try {
    if (!this.polls)
     return false;
    for (url in this.polls) {
     for (x = 0; x < this.polls[url].length; x++ ) {
      /* Clear all the polls with clearInterval() */
      //console.log("Clearing polls...for ID = " + this.polls[url][x].id);
      clearInterval(this.polls[url][x].id);
      this.polls[url][x].id = null;
      //console.log("Clearing polls...interval = " + this.polls[url][x].interval);
      this.polls[url][x].interval = null;
      //console.log("Clearing polls...selector = " + this.polls[url][x].selector);
      this.polls[url][x].selector = null;
      this.polls[url][x].append = null;
      this.polls[url][x] = null;
      delete this.polls[url][x];
      /* Then remove the objects just for clean up */
     }
     this.polls[url] = null;
     delete this.polls[url];
    }
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
   finally {
    this.polls = null;
   }
  }
 }

 pollCallback = function(selector, url, callback) {
  //console.log("Called pollValueCallback...selector: " + selector + " path: " + url);
  $.niagaraGet.read(url, callback, selector);
 }

 pollTrendCallback = function(url, data, callback, context) {
  $.niagaraGet.trend(url, data, callback, context);
 }

 pollValueCallback = function (result, status, xhr) {
  if ($.niagaraGet.checkSuccess(xhr)) {
   if (result) {
    var select = $(this);
    var poll = $.niagaraGet.Poll.getPollByPathSelector(result.path, select.toString());
    if (poll) {
     select.each(function() {
      $.niagaraGet.resultHandler(select, result.path, result.value, result.status, poll.append);
     });
    }
    else {
     $.niagaraGet.Alert.error("$.niagaraGet.Poll: pollValueCallback: could not retrieve poll object", status, xhr);
    }
   }
   else {
    $.niagaraGet.Alert.error("$.niagaraGet.Poll: pollValueCallback: result was undefined", status, xhr);
   }
  }
  select = null;
  poll = null;
  return;
 }

 pollImageCallback = function (result, status, xhr) {

  if ($.niagaraGet.checkSuccess(xhr)) {
   if (result) {
    var select = $(this);
    select.each(function() {
     $.niagaraGet.resultHandler(select, result.path, result.value, result.status, null);
    });
   }
   else {
    $.niagaraGet.Alert.error("$.niagaraGet.Poll: pollValueCallback: result was undefined", status, xhr);
   }
  }
  select = null;
  return;
 }



 /**************************************************************************************
  * $.niagaraGet.BatchPoll
  *
  * This implementes the long poll functionality for the Niagara/Webeye framework.
  * The $.niagaraGet.BatchPoll object creates a new batchPoll() object instance for
  * each new "interval" - the interval becomes the ID or "group" to class all the
  * paths/datapoints that are being requested for that interval period. Each time
  * a new path/setpoint is added to the poll it takes a series of options with it
  * (some options are used by the main $.niagaraGet.BatchPoll object itself, and a
  * sub-set of those options is passed on to the individual batchPoll object instance.
  *
  * path : -> The path/datapoint in the Niagara/Webeye database
  * interval : -> The interval for the time period we want to poll
  *    in milliseconds (e.g. 6000 is 6 secs, 60000 is one
  *    minute, 60000 * 60 is one hour, etc...)
  * value : -> The long poll value - this is attached as "&value = value"
  *       in the request. You can probably always leave the
  *      default which is set for you.
  * selector: -> If you want the poll object to automatically update your
  *     DOM element you include its selector here, such as '#p1'
  *               or 'h3' or '.our-class', etc.
  * append: -> A sub-string element to append after the returned path/datapoint
  *             value, such as a text postscript string value like "%" or "&deg;F",
  *    etc.
  * set_results: -> A true/false flag to indicate whether you want the long poll
  *                  object to automatically set the returned value for your path/datapoint
  *                  to a DOM object with the selector: param.
  * start : -> A true/false flag to tell the long poll object to start polling when
  *             the first item is added or whether to wait for an actual call to the
  *             startPoll(interval) method instead.
  * callback: -> A callback function that can be called for your path/datapoint
  *               that will be passed a simple array containing the path name as arr[0]
  *               and the returned value as arr[1]. You callback function should be:
  *               function(arr) { path = arr[0], value = arr[1], your code goes here... }
  *
  *****************************************************************************************/
 $.niagaraGet.BatchPoll = {

  defaults : {
   path : null,
   id : null,
   interval : $.niagaraGet.stationData.BATCH_POLL_INTERVAL,
   selector: null,
   append: null,
   set_results: true,
   start : true,
   callback: null,
   variable: null
  },

  id : null,
  interval : $.niagaraGet.stationData.BATCH_POLL_INTERVAL,
  bp_timer : null,
  polls : new Array(),
        // This is the standard Niagara/Webeye path/datapoint
        // that we always call giving it this path, plus some
        // indicator that this is a "long poll" request.
        // We'll attach the interval up above as the "id" for
        // the poll group on the server side, so it knows which
        // group (our context) of data points to get back to us...

  doBatchPoll : function(options) {

   try {
    if (options) {

     var opts = $.extend({}, this.defaults, options);

     //var sendPath = true;  // Path is not subscribed, then subscribe it
     for (x = 0; x < this.polls.length; x++) {
      if (opts.path == this.polls[x].path && opts.selector == this.polls[x].selector){
       return;
      }

      /*if(opts.path == this.polls[x].path) {
       sendPath = false;
      }*/
     }

     if (opts.id)
      this.id = opts.id;

     this.polls.push({path : opts.path, selector : opts.selector, append : opts.append,
           set_results: opts.set_results, callback : opts.callback, variable: opts.variable });

     //if (sendPath) {
      $.niagaraGet.watch($.niagaraGet.stationData.WATCH_SUBSCRIBE, this.id, function(result, status, xhr){
       if ($.niagaraGet.checkSuccess(xhr)) {
        if (result.response == 'ok') {
         //console.log("Batch Poll addPoll: result was true");
         return;
        }
        else {
         if (result) {
          $.niagaraGet.Alert.error("Niagara/Webeye Error: batch poll failure: " + result.message);
         }
         else {
          $.niagaraGet.Alert.error("Niagara/Webeye Error: batch poll failure: unknown error");
         }
         $.niagaraGet.BatchPoll.clearPoll(this.path, this.selector);
        //console.log("Long Poll addPoll niagaraInvoke: result was false");
        }
       }
      }, opts, opts.path);

      if (opts.start == true && !this.bp_timer)
       this.startPoll();
     //}

     opts = null;
     return true;
    }
    else
     return false;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  batchSubscribe : function(options) {
   try {
    if (options) {

     // Format: opts.subscribe : [ { path, selector, append, callback, set_results },
     //         { path, selector, append, callback, set_results },
     //         ...            ];
     var opts = $.extend({}, this.defaults, options);

     if (opts.id)
      this.id = opts.id;

     var subscriber_list = "";
     for (y = 0; y < opts.subscribe.length; y++) {

      if (!opts.subscribe[y].path || !opts.subscribe[y].selector)
       continue;

      var exists = false;
      //var sendPath = true;  // Path is not subscribed, then subscribe it
      for (x = 0; x < this.polls.length; x++) {
       if (opts.subscribe[y].path == this.polls[x].path && opts.subscribe[y].selector == this.polls[x].selector) {
        //console.log("Path = " + opts.subscribe[y].path + " exists, breaking...");
        exists = true;
        break;
       }
       /********************************************************
        * See if the path exists already in our subscriber list.
        * If it does we don't need to subscribe it again on the
        * server, so we won't add it to the subscriber_list
        * that we construct, below...
        *****************************************************/
       /*if(opts.subscribe[y].path == this.polls[x].path) {
        sendPath = false;
       }*/
      }

      if (exists == false) {

       var p = opts.subscribe[y].path;
       var s = opts.subscribe[y].selector;

       var a = null;
       if(opts.subscribe[y].append)
        a = opts.subscribe[y].append;

       var r = opts.set_results;
       if (opts.subscribe[y].set_results == false)
         r = opts.subscribe[y].set_results;

       var c = null;
       if (opts.subscribe[y].callback)
        c = opts.subscribe[y].callback;

       var v = null;
       if (opts.subscribe[y].variable) {
        v = opts.subscribe[y].variable;
       }


       this.polls.push({path : p, selector : s, append : a, set_results: r, callback : c, variable : v });
       //if (sendPath == true)
       subscriber_list += p + ",";
      }

     }

     var data = $.niagaraGet.stationData.BATCH_POLL_ID + "=" + this.id + "&" +
        $.niagaraGet.stationData.WATCH_SUBSCRIBE + "&" +
          "path=" + subscriber_list;

     /* There was a Tridium bug that prevented us from using POST with this call. As soon as it's fixed, we will
        change this call back to using a POST request...*/
     $.niagaraGet.n_ajax($.niagaraGet.stationData.PREFIX_WATCH, function(result, status, xhr){
        if ($.niagaraGet.checkSuccess(xhr)) {
        if (result.response == 'ok') {
         //console.log("Batch Poll addPoll: result was true");
         return;
        }
        else {
         if (result && result.message) {
          $.niagaraGet.Alert.error("Niagara/Webeye Error: batch subscribe failure: " + result.message);
         }
         else {
          $.niagaraGet.Alert.error("Niagara/Webeye Error: batch subscribe failure: unknown error");
         }
         var obj = this;
         if (obj) {
          for (i = 0; i < obj.subscribe.length; i++) {
           $.niagaraGet.BatchPoll.clearPoll(obj.subscribe[i].path, obj.subscribe[i].selector);
          }
         }
         obj = null;
         return;
        }
       }
      }, opts, data, $.niagaraGet.stationData.DEFAULT_DT);

     if (opts.start == true && !this.bp_timer)
      this.startPoll();

     opts = null;
     return true;
    }
    else
     return false;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  /**************************************************************************
   * batchUnsubscribe
   *
   * Unusubscribe path/selector pairs from the Niagara/Webeye server.
   * IMPORTANT: If the path you want to unsubscribe is subscribed to a
   * different selector from the one it is paired with in the params
   * list (see below), then the batchUnsubscribe will clear the poll
   * using the clearPoll() method, to remove it from the BatchPoll poll
   * list , but it will not unsubscribe the path from the server
   * (since this would stop updates to another selector being used
   * somewhere else).
   *
   * Options are sent as an array of path/selector objects to unsubscribe --
   * the property is still called 'subscribe' as it is in batchSubscribe:
   *
   * subscribe : [ { path, selector},
   *          { path, selector},
   *    ... ];
   **************************************************************************/
  batchUnsubscribe : function(options) {
   try {
    if (options) {

     // Format: opts.subscribe : [ { path, selector, append, callback, set_results },
     //         { path, selector, append, callback, set_results },
     //         ...            ];
     var opts = $.extend({}, this.defaults, options);

     if (!opts.subscribe || opts.subscribe.length == 0)
     {
      //console.log("opts.subscribe.length was 0");
      return false;
     }

     var subscriber_list = "";
     for (y = 0; y < opts.subscribe.length; y++) {

      if (!opts.subscribe[y].path || !opts.subscribe[y].selector)
       continue;

      var sendPath = true;
      for (x = 0; x < this.polls.length; x++) {
       if(opts.subscribe[y].path == this.polls[x].path && opts.subscribe[y].selector != this.polls[x].selector ) {
        sendPath = false;
       }
      }


      for (x = 0; x < this.polls.length; x++) {
       if (opts.subscribe[y].path == this.polls[x].path && opts.subscribe[y].selector == this.polls[x].selector) {
        //console.log("Path = " + opts.subscribe[y].path + " exists, breaking...");
        if (sendPath) {
         var p = opts.subscribe[y].path;
         subscriber_list += p + ",";
        }
        else {
         $.niagaraGet.BatchPoll.clearPoll(opts.subscribe[y].path, opts.subscribe[y].selector);
        }
       }
      }
     }

     var data = $.niagaraGet.stationData.BATCH_POLL_ID + "=" + this.id + "&" +
        $.niagaraGet.stationData.WATCH_UNSUBSCRIBE + "&" +
        "path=" + subscriber_list;


     /* There was a Tridium bug that prevented us from using POST with this call. As soon as it's fixed, we will
        change this call back to using a POST request...*/
     $.niagaraGet.n_ajax($.niagaraGet.stationData.PREFIX_WATCH, function(result, status, xhr){
        if ($.niagaraGet.checkSuccess(xhr)) {
        var obj = this;
        if (result && result.response != 'ok') {
         if (result.message) {
          $.niagaraGet.Alert.error("Niagara/Webeye Error: batch unsubscribe failure: " + result.message);
         }
         else {
          $.niagaraGet.Alert.error("Niagara/Webeye Error: batch unsubscribe failure: unknown error");
         }
        }
        if (obj) {
         for (i = 0; i < obj.subscribe.length; i++) {
          $.niagaraGet.BatchPoll.clearPoll(obj.subscribe[i].path, obj.subscribe[i].selector);
          //console.log("Cleared poll for path: " + obj.subscribe[i].path + " selector: " + obj.subscribe[i].selector);
         }
        }
        obj = null;
        //$.niagaraGet.BatchPoll.printPollList();
       }
      }, opts, data, $.niagaraGet.stationData.DEFAULT_DT);

     opts = null;
     return true;
    }
    else
     return false;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  getBatchPoll : function() {
   return this;
  },

  getInterval : function() {
   if (this.interval)
    return this.interval;
   else
    return null;
  },

  setInterval : function(ival, start) {
   if (this.bp_timer) {
    this.stopPoll();
   }

   this.interval = ival;

   if (start && start == true) {
    this.startPoll();
   }
  },

  getID : function() {
   return this.id;
  },

  setID : function(id) {
   if (id) {
    this.id = id;
   }
  },

  getBatchPollID : function() {
   return this.bp_timer;
  },

  stopPoll : function() {
   try {
    if (this.bp_timer) {
     clearInterval(this.bp_timer);
     this.bp_timer = null;
     return true;
    }
    else
     return false;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  restartPoll : function() {
   try {
    if (this.bp_timer) {
     //console.log("Restarting Poll for ID: " + this.bp_timer);
     clearInterval(this.bp_timer);
     this.bp_timer = null;
     return this.startPoll();
    }
    else
     return false;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  getPoll : function(path, selector) {
   if (!path || !this.polls || !selector) {
    return null;
   }
   else {
    for (x = 0; x < this.polls.length; x++) {
     if (path == this.polls[x].path && selector == this.polls[x].selector) {
      return this.polls[x];
     }
    }
    return null;
   }
  },

  clearPoll : function(path, selector, unsubscribe) {
   if (!path || !this.polls || !selector )
    return false;
   try {
    for (x = 0; x < this.polls.length; x++) {
     if (path == this.polls[x].path && selector == this.polls[x].selector) {
       //console.log("Clearing poll -> " + this.polls[x].path);
       if(unsubscribe && unsubscribe == true) {
        $.niagaraGet.watch($.niagaraGet.stationData.WATCH_UNSUBSCRIBE, this.id, function(result, status, xhr){
        if ($.niagaraGet.checkSuccess(xhr)) {
         if (result && result.status != 'ok')
          $.niagaraGet.Alert.error("Niagara/Webeye Error:  Could not unsubscribe path", status, xhr);
        }
        else {
         $.niagaraGet.Alert.error("Niagara/Webeye Error: Unsubscribe failed", status, xhr);
        }
       }, selector, path);
      }
      this.polls[x] = null;
      this.polls.splice(x, 1);
      return true;
     }
    }
    return false;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  /**************************************************************************
   * unsubscribe
   *
   * Does an 'unsubscribe' through the $.niagaraGet.watch() method to
   * unsubscribe a path from the server. If the same path is subscribed
   * to any other selector then the method returns false - you can't
   * unsubscribe a path if it is being used to set another selector. This
   * method will not clear the poll from the internal BatchPoll poll list,
   * you have to make a seperate call to clearPoll().
   *
   * Use batchUnsubscribe() to unsubscribe multiple paths at one time.
   * Use clearPoll() to unset a path/selector pair without unsubscribing it
   * from the Niagara/Webeye server.
   *
   * Params:
   *
   * path: path to the datapoint you want to unsubscribe
   * selector: selector you want to unset/unsubscribe
   * ************************************************************************/
  unsubscribe : function(path, selector) {
   if (!path || !this.polls || !selector )
    return false;
   try {

    // If the path is subscribed for more than one selector,
    // do not unsubscribe it -- return false;
    for (x = 0; x < this.polls.length; x++) {
     if(path == this.polls[x].path && selector != this.polls[x].selector ) {
      return false;
     }
    }

    // Otherwise unsubscribe the path, but we don't clear the poll -- a separate
    // call to clearPoll needs to be called by the user...
    for (x = 0; x < this.polls.length; x++) {
     if (path == this.polls[x].path && selector == this.polls[x].selector) {
       $.niagaraGet.watch($.niagaraGet.stationData.WATCH_UNSUBSCRIBE, this.id, function(result, status, xhr){
       if ($.niagaraGet.checkSuccess(xhr)) {
        if (result && result.status != 'ok')
         $.niagaraGet.Alert.error("Niagara/Webeye Error:  Could not unsubscribe path " + this.path, status, xhr);
       }
       else {
        $.niagaraGet.Alert.error("Niagara/Webeye Error: Unsubscribe failed for path " + this.path, status, xhr);
       }
         }, { 'path' : path }, path);
        }
    }
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  getPolls : function() {
   return this.polls;
  },

  startPoll : function() {
   try {

    if (!this.bp_timer) {
     this.bp_timer = setInterval(timerCallback, this.interval);
     return true;
    }
    else
     return false;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  },

  /* A support function for testing. This method will
     print the path and selector of all the polls in
     the "polls" Array. */
  printPollList : function() {
   for (x = 0; x < this.polls.length; x++) {
     console.log("Watch List [" + x + "]: path = " +
     this.polls[x].path + " selector = " + this.polls[x].selector + " set_results = " +  this.polls[x].set_results + " callback" + this.polls[x].callback + " variable" + this.polls[x].variable);
   }
  },

  clearAll : function() {
   try {
    $.niagaraGet.watch($.niagaraGet.stationData.WATCH_UNSUBSCRIBE_ALL,
        this.id,
        function(results, status, xhr){}, null, null);

    if (this.bp_timer) {
     //console.log("Clearing bp_timer...");
     clearInterval(this.bp_timer);
     this.bp_timer = null;
    }

    if (this.polls) {
     for (x = 0; x < this.polls.length; x++)
     {
      //console.log("Clearing Long Poll...path = " + polls[x].path + " selector = " + polls[x].selector + " append = " + polls[x].append + " set_results = " + polls[x].set_results + " callback = " + polls[x].callback);
      this.polls[x] = null;
     }
    }

    this.defaults = null;
    this.polls = null;
    this.interval = null;
   }
   catch(ex) {
    $.niagaraGet.Alert.exception(ex);
   }
  }
 }

 /********************************************************
  * timerCallback
  *
  * This method is called by the timer started in the
  * BatchPoll.startPoll() method. All it does is setup
  * and make the Ajax call.
  ********************************************************/
  timerCallback = function() {
  //console.log('timerCallback called with value of: ' + ival);
  var obj = $.niagaraGet.BatchPoll.getBatchPoll();
  var id = $.niagaraGet.BatchPoll.getID();
  if (obj) {
   $.niagaraGet.watch($.niagaraGet.stationData.WATCH_POLL, id, batchPollCallback, obj, null);
  }
  else {
   $.niagaraGet.Alert.error("Niagara/Webye System Error: $.niagaraGet.BatchPoll: batchPollCallback: could not retrieve BatchPoll object", status, xhr);
  }
  id = null;
  obj = null;
 }

 /*******************************************************
  * batchPollCallback
  *
  * This method is called by the timer started in the
  * BatchPoll.startPoll() method. It handles the
  * Ajax callback results and processing from a
  * BatchPoll "watch".
  *******************************************************/
 batchPollCallback = function(result, status, xhr) {

  var e = "Niagara/Webye System Error: $.niagaraGet.BatchPoll: batchPoll-> batchPollCallback failed";
  var b_poll = this; // BatchPoll object is bound as the context for us,
         // in the $.ajax() call inside the timer callback method, above.
  if (!b_poll) {
   $.niagaraGet.Alert.error(e, status, xhr);
   return;
  }

  if ($.niagaraGet.checkSuccess(xhr) && result)
  {
   var arr = b_poll.getPolls();

   if (!arr)
    $.niagaraGet.Alert.error(e, status, xhr);

   var elements = result.watch;
   for (y = 0; y < elements.length; y++) {
    var name = elements[y][0];
    var value = elements[y][1];
    var msg = elements[y][2];
    //console.log("Name = " + name + " Value = " + value + " Message = " + msg);
    for (x = 0; x < arr.length; x++) {
     var p = arr[x];
     if (p && name == p.path) {
      //console.log("p.path = " + p.path + " p.selector = " + p.selector + " p.set_results = " + p.set_results);
      /******************************************************
       * If there's a callback function then call it...
       *
       * This is where you might want your own callback
       * function to handle a more complex set of logic
       * when receiving the data from the watch callback.
       *
       * path: The path to the datapoint
       * selector: The associated selector for the datapoint
       * value: The returned value from the result object
       * status: The status message from the result object
       * append: A string to appended to the result, i.e. "%"
       ******************************************************/

      //console.log("p.set_results == false");
      if (p.variable && p.variable instanceof Object) {
       //console.log("p.variable && p.variable != null && p.variable instanceof Object");
       p.variable.path = p.path;
       p.variable.selector = p.selector;
       p.variable.value = value;
       p.variable.status = msg;
       p.variable.append = p.append;
       //$p = p.variable;
       /* console.log("p.variable is now " + $p.path + ", " + $p.selector + ", " +
          $p.value + ", " + $p.status + ", " + $p.append);  */
      }

      if (p.callback && typeof p.callback == 'function') {
       //console.log("p.callback was not null!");
       p.callback({'path' : p.path, 'selector' : p.selector,
          'value' : value, 'status' : msg, 'append' : p.append}); // If they don't
                        // want to have the data
                       //automatically set to a selector
               // then they can have it passed back to a callback, but this might get
               // a bit hairy from a performance aspect. */
      }

      if (p.set_results == true) {
       //console.log("p.set_results == true");
       var select = $(p.selector);
       if (select) {
        select.each(function() {
         //console.log("Calling $.niagaraGet.resultHandler");
         $.niagaraGet.resultHandler(select, name, value, msg, p.append);
        });
       }
       else
        $.niagaraGet.Alert.error("Niagara/Webeye System Error: $.niagaraGet.BatchPoll: $(" + p.selector + ") was invalid or undefined", status, xhr);
      }
     }
    }
   }
  }
  // Set all the referenced objects to null to insure we're
  // not holding on to any references that might leak.
  e = null;
  arr = null;
  p = null;
  b_poll = null;
  elements = null;
  name = null;
  value = null;
  msg = null;
  select = null;
 }


 /************************************************************
  * niagaraQuickWrite
  *
  * Calls $.niagaraGet.write() with a path and data to set, then
  * uses the reply to update the value in the current selector
  ************************************************************/
  $.niagaraGetQuickWrite = function(path, data, callback) {
  //console.log("$.fn.niagaraSet...path = " + opts.path + " set = " + opts.set);
  return $.niagaraGet.write(path, data, function(result, status, xhr){
   if ($.niagaraGet.checkSuccess(xhr)) {
    if (result && result.response != "ok") {
     $.niagaraGet.Alert.error("Niagara/Webeye Error: niagaraSet: " + result.message);
    }
    else {
     this.callback();
    }
   }
   else {
    $.niagaraGet.Alert.error("Niagara/Webeye Error: niagaraSet: unknown error");
   }
  }, { 'callback' : callback });
 }


 /************************************************************
  * niagaraAction
  *
  * Calls $.niagara.write with a path and data to set, then
  * uses the reply to update the value in the current selector
  ************************************************************/
  $.niagaraAction = function(path, data, callback) {
  //console.log("$.fn.niagaraSet...path = " + opts.path + " set = " + opts.set);
  return $.niagaraGet.action(path, data, function(result, status, xhr){
   if ($.niagaraGet.checkSuccess(xhr)) {
    if (result && result.response != "ok") {
     $.niagaraGet.Alert.error("Niagara/Webeye Error: niagaraSet: " + result.message);
    }
    else {
     this.callback();
    }
   }
   else {
    $.niagaraGet.Alert.error("Niagara/Webeye Error: niagaraSet: unknown error");
   }
  }, { 'callback' : callback });
 }



 // This is a dummy function to dest the callback behavior...
 /*$.niagaraWrite1 = function(write_path, read_path, data, selector, append, callback) {
   var obj = { 'value' : true }
   if (callback)
    callback(obj);
  }*/

 /***********************************************************************************************
  * $.niagaraWrite()
  *
  * Parameters:
  * write_path  Path to the point to write to;
  * read_path  Path to the point to read back from;
  * data   The value to be written to the write point (write_path)
  * selector  The selector of the DOM elements that will be updated with the
  *              newly written value (".setpoint", "#myInput", "h3", are all valid selectors).
  * append    Text postscript that needs to be appended to the value ("%", "&deg;F", "V", etc).
  * callback  A callback function executed at the end of the write or on write fail/error:
  *    function(obj) { ... }
  *        obj  param will contain all of the above properties (read_path,
  *       write_path, data, selector, append, callback) plus the additional
  *       properies:
  *          value   the value returned by the AJAX call, or the last
  *           value returned if fail.
  *                  success  true if the write/read-back succueeded
  *           (data sent == data read back) else false.
  *************************************************************************************************/
  $.niagaraWrite = function(write_path, read_path, data, selector, append, callback) {
  //console.log("$.fn.niagaraSet...path = " + opts.path + " set = " + opts.set);
  if (!write_path || !selector || data == 'undefined' || data == null)
   return false;

  if (!read_path || read_path == "")
   read_path = write_path;

  var obj = {'path' : read_path, 'write_path' : write_path, 'data' : data, 'selector' : selector, 'append' : append, 'callback' : callback};
  $.niagaraGet.write(write_path, data, function(result, status, xhr){
   if ($.niagaraGet.checkSuccess(xhr)) {
    if (result && result.response == "ok") {
     //console.log('NW: response == ok');
      setTimeout(writeValidate, 100, this);
    }
    else {
     $.niagaraGet.Alert.error("Niagara/Webeye Error: niagaraWrite: " + result.message);
     //console.log("result.response was not ok, selector = " + this.selector + ", result.response = " + result.response + ", path = " + this.path);
     if (result.response == "failure" && result.message == "Permission denied") {
      var html = '<div class="write-tip no-access ' + pathToClass(this.path) + '">Permission denied!...</div>';
      writeToolTip(this.selector, this.path, html, 1500);
      $.niagaraGet.resultHandler(this.selector, this.path, "forbidden", result.response, null, true);
      // Refresh the value after five seconds...
      setTimeout(function() {
       $(this.selector).niagaraGet(this.path);
      },
      5000);
     }
     else {
      var html = '<div class="write-tip ' + pathToClass(this.path) + '">Write failed with error!...</div>';
      writeToolTip(this.selector, this.path, html, 1500);
      $.niagaraGet.resultHandler(this.selector, this.path, result.response, result.response, null, true);
     }
    }
   }
   else {
    $.niagaraGet.Alert.error("Niagara/Webeye Error: niagaraSet: unknown error");
    //$.niagara.resultHandler(this.selector, this.path, 'failure', 'failure', null, true);
   }
  }, obj);
  obj = null;
 }

 function pathToClass(path) {
  var tmp = path.replace(/\./gi,'');  // Strip the . and _ from the path name
  var p = tmp.replace(/_/gi, '');
  return p;
 }

 function writeToolTip(selector, path, html, timeout) {
  //console.log("selector = " + selector);
  var path_class = pathToClass(path);
  var x = 1;
  $(selector).each(function() {
   //console.log("iteration..." + x++);
   var offset = $(this).offset();     // get its position...
   var top = parseInt(offset.top - 11);
   var left = parseInt(offset.left - 15);
   //console.log("p = " + path_class);
   //console.log("Position top: " + top + " left: " + left);
   /* Create a "tooltip" box and display it slightly offest from the value,
      to show what's being read back (until it matches what we attempted to write). */
   $('body').append(html);
   $('.' + path_class + ':last').css({ "top" : top + "px", "left" : left + "px" });
   if (timeout && !isNaN(timeout))
    fadeToolTip(path, timeout);
  });
 }

 function fadeToolTip(path, timeout){
  if (path && !isNaN(timeout)) {
   setTimeout(removeToolTip, timeout, path);
  }
  else
   return false;
 }

 var removeToolTip = function(path) {
  var p = pathToClass(path);
  if ($('.write-tip').hasClass(p)) {
   $('.' + p).fadeOut(400, function() {
    $(this).remove();
   });
  }
 }

 /*************************************
  * writeValidate
  *
  * Attempts to validate the written
  * value in $.niagaraWrite.
  *************************************/
 writeValidate = function(o) {
  /* Call this method for the length of the $.niagaraGet.stationData.WRITE_TIMEOUT value
     typically 5 seconds */
  var id = setInterval(function(obj) {
    /* Read the datapoint and compare the value we got back to
       what we attempted to write */
    $.niagaraGet.read(obj.path, function(result, status, xhr) {
     if ($.niagaraGet.checkSuccess(xhr)) {
      var select = $(this.selector);
      var ctxt = this;
      var path_class = pathToClass(this.path);
      //console.log("this.path = " + this.path + ", path_class = " + path_class);

      //console.log("P = " + path_class);

      /* If the status is "ok", then check the value against what we wrote...*/
      if (result && result.status == "ok") {
       if (result.value.toString() == this.data.toString()) {
 //       console.log('Validate: typeof result.value: ' + typeof result.value + " typeof this.data: " + typeof this.data);
 //       console.log("Path: " + ctxt.path + " values were equal: result.value = " + result.value + " this.data = " + this.data);
        /* If the result is the same as what we wrote, we succeeded, clear the timer to stop it.*/
        clearInterval(id);
        clearTimeout(timeout);
        /* Then set the written value for each DOM object with this selector */
        if (ctxt.callback) {
        // console.log('callback cb_obj called...');
         var cb_obj = ctxt;
         cb_obj.value = result.value;
         cb_obj.success = true;
         ctxt.callback(cb_obj);
         cb_obj = null;
        }

        if (select) {
         select.each(function() {
           $.niagaraGet.resultHandler(select, ctxt.path, result.value, result.status, ctxt.append);
         });
        }

        removeToolTip(this.path);
       }
       else {
        //console.log("Path: " + ctxt.path + " values were not equal: result.value = " + result.value + " this.data = " + this.data);
        /* If the read value is not the same as the write value
           then we're still waiting for the server to update. So
           show the user what's being read back in a little "write tip" */
        if (!$('.write-tip').hasClass(path_class)) { // If there are existing .write-tip's, look for any with
                    // our path as a class...
         if (select) {
          select.each(function() {     // if it doesn't exist, then iterate each item in selector,
           var html = '<div class="write-tip ' + path_class + '">Reading...' +  result.value;
           if (ctxt.append)
            html += ctxt.append;
           html += '</div>';
           writeToolTip(select, ctxt.path, html, null);
          });
         }
        }
       }
      }
      else {
       if (!$('.write-tip').hasClass(path_class)) { // If there are existing .write-tip's, look for any with
                   // our path as a class...
        if (select) {
         select.each(function() {     // if it doesn't exist, then iterate each item in selector,
          var html = '<div class="write-tip ' + path_class + '">Status: ' +  result.status;
          if (ctxt.append)
           html += ctxt.append;
          html += '</div>';
          writeToolTip(select, ctxt.path, html, null);
         });
        }
       }
       $.niagaraGet.Alert.error("Niagara/Webeye System Error: read failure, status: " + result.status, " value: " + result.value, status, xhr);
      }
     }
     select = null;
     ctxt = null;
     path_class = null;
     tmp = null
   }, obj);

  }, 300, o);

  /* Set a timeout to end the read attempts in the setInterval call,
     above, using $.niagaraGet.stationData.WRITE_TIMEOUT, typically 5 seconds */
  var timeout = setTimeout(function(i, data) {
   clearInterval(i); // Kill the timer for the setInterval to stop it.
   /* Need to do one last read attempt to see if the value matched */
   $.niagaraGet.read(data.path, function(result, status, xhr) {
    if ($.niagaraGet.checkSuccess(xhr)) {
     var s = $(this.selector);
     var c = this;
     var setWrite = false;
     if (result && result.value != 'undefined') {
      if(result.value.toString() != this.data.toString()) {
//       console.log('Interval: typeof result.value: ' + typeof result.value + " typeof this.data: " + typeof this.data);

//       console.log("Timeout - Path: " + c.path + " values were not equal: result.value = " + result.value + " this.data = " + c.data);
       if (c.callback && c.callback != null) {
        //console.log("callback o called...");
        var ob = c;
        ob.success = false;
        ob.value = result.value;
        c.callback(ob);
        ob = null;
       }

       /* If the returned read result is still not equal to what we attempted to write
          we stop and display an error message in the Alerts panel for the user */
       $.niagaraGet.Alert.error("Niagara/Webeye System Error: failed to write value: " + this.data + " for datapoint: " + this.path, status, xhr);
       s.each(function() {
        $.niagaraGet.resultHandler(s, c.path, result.value, result.status, c.append, true);
        // Attempt to write the old value back to the point.
       });

       // If everything fails, try to write the old data back - we don't have
       // anything in the callback function because there's nothing to do if
       // this attempt fails as well.
       $.niagaraQuickWrite(c.write_path, this.data, function() {});
      }
      else {
//       console.log("Timeout - Path: " + c.path + " values were equal: result.value = " + result.value + " this.data = " + c.data);
       if (c.callback && c.callback != null) {
        //console.log("callback c called...");
        var cb_obj = c;
        cb_obj.success = true;
        cb_obj.value = result.value;
        c.callback(cb_obj);
        cb_obj = null;
       }

       if (s) {
        //console.log("Calling s.each()...");
        s.each(function() {
         $.niagaraGet.resultHandler(s, c.path, result.value, result.status, c.append);
        });
       }
      }

      removeToolTip(c.path);    // remove the "tooltip" box that might have been created
              // while waiting for the write to take...

      o = null;
      s = null;
      c = null;
     }
    }
   }, data);

   /* Set another timeout to allow for all the read attempts
      to complete, then clear out any remaining write-tip (tooltip)
      boxes that remain on the screen */
   fadeToolTip(this.path, 4000);

  }, $.niagaraGet.stationData.WRITE_TIMEOUT, id, o);
 }




 /************************************************************
  * niagaraSet
  *
  * Calls $.niagaraGet.write with a path and data to set, then
  * uses the reply to update the value in the current selector
  * NOTE: *** Not meant to be used with jQuery chaining****
  ************************************************************/
  $.fn.niagaraSet = function(write_path, read_path, append) {
  //console.log("$.fn.niagaraSet...path = " + opts.path + " set = " + opts.set);
  var data = null;
  var select = $(this);
  if ($(this).is("input")) {
   data = select.val();
  }
  else {
   data = select.html();
  }

  if (!data || data == "") {
   return $.niagaraGet.Alert.info("Niagara/Webye System Info: $.fn.niagaraSet write attempt : data was undefined");
  }
  //console.log("Data = " + data);

  if (append) {
   var str = data.substring(0, data.indexOf(append));
   data = str;
  }
  //console.log("Str = " + data);

  $.niagaraWrite(write_path, read_path, data, select, append, null);
 }


 /************************************************************
  * niagaraGet
  *
  * Calls $.niagaraGet.read with a path and
  * uses the reply to update the value(s) in the selector
  ************************************************************/
 $.fn.niagaraGet = function(path, append) {
  //console.log("$.fn.niagaraSet...path = " + opts.path + " set = " + opts.set);
  return $.niagaraGet.read(path, function(result, status, xhr){
   if ($.niagaraGet.checkSuccess(xhr) && result) {
    var select = $(this);
    select.each(function() {
     $.niagaraGet.resultHandler(select, result.path, result.value, result.status, append);
    });
   }
  }, this);
 }

 /***********************************************************************
  * niagaraGetDatapoint
  *
  * Retrieve a value from the Niagara server and set it in a variable.
  *
  * datapoint - path name of the datapoint to be read
  * val - object[key] { obj: object, key: 'key' } or "object"
  *   and "property name" will be added/set
  * callback - a callback function called at the end of the process, will
  *            be passed the "result" object as a parameter.
  ***********************************************************************/
 $.niagaraGetDatapoint = function(datapoint, val, callback) {
  //console.log("Called $.niagaraGetDatapoint...");
  $.niagaraGet.read(datapoint,
      function(result, status, xhr){
       //console.log("$.niagaraGetDatapoint callback called!");
     if ($.niagaraGet.checkSuccess(xhr) && result != 'undefined' && result != null) {
      var m = result.status.split(",");
      var msg = m[0];
      if (msg == "ok") {
       //console.log(this);
       if (this.obj && this.key)
        this.obj[this.key] = result.value;
       else
        this.value = result.value;
      }
      else
       $.niagaraGet.Alert.error("Niagara/Webeye Error: Could not obtain value for path: " + result.path, status);
      if (callback != null)
       callback(result);
     }
    },
  val);
 }


 //$.niagaraGet.getLocalHost();


 $(window).unload(function() {

  if ($.niagaraGet.BatchPoll)
   $.niagaraGet.BatchPoll.clearAll();

  if ($.niagaraGet.Poll)
   $.niagaraGet.Poll.clearAll();

  if ($.fn.niagaraSet) {
   $.fn.niagaraSet = null;
   delete $.fn.niagaraSet;
  }

  if ($.fn.niagaraGet) {
   $.fn.niagaraGet = null;
   delete $.fn.niagaraGet;
  }

  if ($.niagaraWrite) {
   $.niagaraWrite = null;
   delete $.niagaraWrite;
  }


  if ($.niagaraGet.Alert) {
   $.niagaraGet.Alert = null;
   delete $.niagaraGet.Alert;
  }

  if ($.niagaraGet.BatchPoll) {
   $.niagaraGet.BatchPoll = null;
   delete $.niagaraGet.BatchPoll;
  }

  if ($.niagaraGet.Poll) {
   //console.log("Deleting $.niagaraGet.Poll...");
   $.niagaraGet.Poll = null;
   delete $.niagaraGet.Poll;
  }

  if ($.niagaraGet) {
   $.niagaraGet.stationData = null;
   $.niagaraGet = null;
   delete $.niagaraGet;
  }
 });


 /**************************************************
  * Post Initialization
  **************************************************/
 (function() {
  var pathName = window.location.pathname;
  var pageName = pathName.substring(pathName.lastIndexOf('/') + 1);
  var page = pageName.substring(0, pageName.indexOf('.'));
  page += "_";
  page += ((new Date()).getTime() + "" + Math.floor(Math.random() *
1000000)).substr(0, 18);
  $.niagaraGet.BatchPoll.setID(page/*$.niagaraGet.stationData.BATCH_POLL_INTERVAL*/);
 })();

}).call(this);