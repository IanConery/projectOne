//require.config({baseUrl: 'js'});
//require(['glob-config'], function() {
    // require(['app/home'], function() {
    //     $('.data').html("<img src='img/loading-16.gif' />");
    // });
//});

require.config({
    baseUrl: 'js',
    paths: {
        jquery:         'lib/jquery-1.7.1.min',
        underscore:     'lib/underscore-min',
        modernizr:      'lib/modernizr-2.6.2.min',
        niagaraAjax:    'jquery.niagara-ajax-1.4',
        niagaraAjaxGet: 'jquery.niagara-ajax-get-1.4',
        handlebars:     'lib/handlebars',
        xml2json:       'lib/xml2json',
        backbone:       'lib/backbone',
        hbars:          'lib/hbars',
        json:           'lib/json',
        text:           'lib/text',
        moment:         'lib/moment.min',
        highcharts:     'lib/Highcharts/js/highcharts',
        highchartsMore: 'lib/Highcharts/js/highcharts-more',
        tmpls:          '../tmpls'
    },
    shim: {
        tmpls: {
            deps: ['handlebars']
        },
        underscore: {
            exports: '_'
        },
        backbone: {
            deps: ['underscore', 'jquery'],
            exports: 'Backbone'
        },
        highcharts: {
            exports: "Highcharts",
            deps: ["jquery"]
        },
        highchartsMore: {
            deps: ["highcharts"]
        },
        handlebars: {
            exports: 'Handlebars'
        },
        hbars: {
            deps: ["handlebars"]
        }
    },
    hbars: {
        extension: ".hbs"
    }
});

require(["backbone", "highcharts", "highchartsMore", "chart-loader"], function(Backbone, x, y, chartLoader) {

    var nodeId = getSelectedNodeId();

    chartLoader.renderChart({
        chartType: 'azt',
        nodeId: nodeId,
        renderTo: 'avgZoneTemp'
    });

    chartLoader.renderChart({
        renderTo: 'peak-energy-chart',
        chartType: 'peakEnergy',
        nodeId: nodeId,
        datePicker: true
    });

    chartLoader.renderChart({
        renderTo: 'std-deviation-chart',
        chartType: 'stdDeviation',
        nodeId: nodeId
    });

});

