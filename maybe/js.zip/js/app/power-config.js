require(['glob-config'], function() {
    require(['chart-loader', 'powerMeters', 'highchartsMore'], function(chartLoader) {

            var nodeId = getSelectedNodeId();
            var powernodeId= window.location.search.split('url=')[1];
            hazMetering(nodeId, function(haz) {

                if (haz) {

                    summaryMeteringStuffFTW();
                    doMetersSummaryTabWork();
                      doMonthYearComparisionKwhChart();
                    $('#summaryTab').removeClass('hide');

                } else {

                    $('#bodyPower #summaryTab').remove();
                    $('#summary-content').remove();

                }

            });


            function doMonthYearComparisionKwhChart() {
                chartLoader.renderChart({
                    chartType: 'RealEnergyComparision',
                    nodeId: nodeId + "/Metering/Power",
                    renderTo: 'comparision',
                    dataDefs: [{
                        data: 'prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum',
                        uid: 'LastYear',
                        timeRange: 'yesterday'
                    },{
                        data: 'prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum',
                        uid: 'Thisyear',
                        timeRange: 'today'
                    }],
                    highChartCfg: {
                        title: {
                            text: 'KWH',
                            style: {
                                color: 'gray',
                                fontSize: '14px'
                            }
                        }
                    }
                });


            }

            function summaryMeteringStuffFTW() {}

            chartLoader.renderChart({
                chartType: 'PredictionChart',
               nodeId: powernodeId,
                renderTo: 'predictionChart'
            });

            chartLoader.renderChart({
                chartType: 'PieChartPrediction',
                nodeId: nodeId,
                renderTo: 'consumptionBreakdown'
            });

            chartLoader.renderChart({
                renderTo: 'peak-energy-chart-sum',
                chartType: 'peakEnergy',
                nodeId: nodeId,
                datePicker: true
            });
            chartLoader.renderChart({
                chartType: 'kwh',
                nodeId: nodeId,
                renderTo: 'Daily-kwh-chart',
                dataDefs: [{
                    data: 'prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum',
                    uid: 'elecMeterRealEnergyNum'
                }],
                timeRange: 'current1Month',
                interval: 'oneDay',
                highChartCfg: {
                    title: {
                        text: 'Daily KWH',
                        align: 'left',
                        margin: 25,
                        x: 10,
                        y: 20,
                        style: {
                            color: 'gray',
                            fontSize: '14px'
                        }
                    }
                }
            });

            chartLoader.renderChart({
                chartType: 'kwh',
                nodeId: nodeId,
                renderTo: 'Monthly-kwh-chart',
                dataDefs: [{
                    data: 'prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum',
                    uid: 'elecMeterRealEnergyNum'
                }],
                timeRange: 'current12Months',
                interval: 'oneMonth',
                highChartCfg: {
                    title: {
                        text: 'Monthly KWH',
                        align: 'left',
                        margin: 25,
                        x: 10,
                        y: 20,
                        style: {
                            color: 'gray',
                            fontSize: '14px'
                        }
                    },
                    xAxis: {
                        type: 'datetime',
                        tickInterval: 24 * 3600 * 1000 * 30,
                        labels: {
                            formatter: function() {
                                return Highcharts.dateFormat('%b', this.value)
                            }
                        }
                    }
                }
            });

        }

    );
});

function hazMetering(nodeId, callback) {

    $.ajax({
        url: '/p?http://172.28.20.16/prophet',
        data: '<ProphetRequest version="1"><Method name="getChildNodes" uid="hazMetering"><nodeId>' + nodeId + '</nodeId></Method></ProphetRequest>',
        type: 'POST',
        dataType: 'text',
        contentType: "text/xml",
        timeout: 140000,
        success: function(respXml) {
            var haz = false;
            $.each($(respXml).find('node'), function(i, e) {
                if ($(e).children('name').text() === 'Metering') {
                    haz = true;
                }
            });
            callback(haz);
        }
    });

}
