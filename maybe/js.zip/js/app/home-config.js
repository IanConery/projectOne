require(['glob-config'], function() {
    require(['jquery', 'underscore', 'handlebars', 'tmpls'], function() {

        require(['app/home', 'bootstrap', 'backbone', 'highcharts', 'chosen', 'chart-loader', 'navBar'], function() {
            $('.data').html("<img src='img/loading-16.gif' />");
        })
    });
});
