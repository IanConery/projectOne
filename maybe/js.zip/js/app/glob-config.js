require.config({
    baseUrl: 'js',
    paths: {
        jquery:         '../bower_components/jquery/jquery.min',
        underscore:     '../bower_components/underscore/underscore',
        niagaraAjax:    'jquery.niagara-ajax-1.4',
        niagaraAjaxGet: 'jquery.niagara-ajax-get-1.4',
        handlebars:     'lib/handlebars',
        xml2json:       'lib/xml2json',
        tmpls:          'tmpls',
        backbone:       'lib/backbone',
        hbars:          'lib/hbars',
        json:           'lib/json',
        text:           'lib/text',
        moment:         'lib/moment.min',
        highcharts:     'lib/Highcharts/js/highcharts',
        highchartsMore: 'lib/Highcharts/js/highcharts-more',
        bootstrap:      'lib/bootstrap/js/bootstrap.min',
        chosen:         'lib/jquery-chosen/chosen.jquery',
        chartLoader:    'chart-loader'
    },
    shim: {
        tmpls: {
            deps: ['handlebars']
        },
        underscore: {
            exports: '_'
        },
        backbone: {
            deps: ['underscore', 'jquery'],
            exports: 'Backbone'
        },
        highcharts: {
            exports: "Highcharts",
            deps: ["jquery"]
        },
        highchartsMore: {
            deps: ["highcharts"]
        },
        handlebars: {
            exports: 'Handlebars'
        },
        hbars: {
            deps: ["handlebars"]
        },
        bootstrap: {
            deps: ['jquery']
        },
        chosen: {
            deps: ['jquery']
        }
    },
    hbars: {
        extension: ".hbs"
    }
});
