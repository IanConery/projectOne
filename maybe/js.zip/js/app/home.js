/******************************************************************
 * app/home.js
 *
 * This Javascript code does all the implementation of the code
 * related to the Power page.
 *
 * This code is jQuery ~1.4 dependent and also dependent on the
 * jquery.niagara-ajax.X.js jQuery plug-in for Niagara/Ajax
 * communication with the Niagara server and the
 * jquery.control-panel-1.0.js file, both of which must be loaded
 * first.
 * to retrieve xml data and functions to plot the charts
 *
 * @author: Mithila Paranjpe, Brian Murrell
 ******************************************************************/

define(function(require) {

    require('niagaraAjax');
    require('niagaraAjaxGet');
    require('xml2json');
    require('ggp');
    var chartLoader = require('chart-loader');

    Handlebars.registerPartial('mallDropdown', TMPLS.mallDropdown);

    niagaraGet.getUserLogin("testpath", function(xml) {
        var xmlDoc = $.parseXML(xml);
        var nodeId = util.setUpUser(xmlDoc);

        var getNodeReq = util.getNodeInfo(nodeId);
        niagara.postReq("testPath", getNodeReq, function(xml) {
            var nodeData = util.parseNodeXml(xml);
            var zip = nodeData.attrVal('disZipCode'),
                lng = nodeData.attrVal('disLongitude'),
                lat = nodeData.attrVal('disLatitude');
            if (zip) { $("#zipCodeData").html(zip.value) };
            if (lng) { $("#longitudeData").html(lng.value) };
            if (lat) { $("#latitudeData").html(lat.value) };
        });

        doSubcription(nodeId);

        doPeakEnergyChart(nodeId);

        doIndicesChart(nodeId);
    });

    function doPeakEnergyChart(nodeId) {
        var siteInfo = $util.siteInfoFromNodeId(nodeId);
        chartLoader.renderChart({
            renderTo: 'peak-energy-chart',
            chartType: 'peakEnergy',
            nodeId: nodeId,
            datePicker: true
        });
    }

    function doIndicesChart(nodeId) {
        var siteInfo = $util.siteInfoFromNodeId(nodeId);
        chartLoader.renderChart({
            highChartCfg: {
                chart: {
                    renderTo: 'indices-chart',
                    type: 'line',
                    borderRadius: 0,
                    height: 350
                },
                title: {
                    text: siteInfo.name + " Indices, Last 30 Days"
                }
            },
            chartType: 'indices',
            nodeId: nodeId,
            indices: [
                {data: 'prophetData:Calculations/Metrics/comfortIndex', uid: 'comfort'},
                {data: 'prophetData:Calculations/Metrics/ggpIndex', uid: 'ggp'},
                {data: 'prophetData:Calculations/Metrics/energyIndex', uid: 'energy'}
            ],
            timeRange: 'previous30days',
            interval: 'oneDay'
        });
    }

    function doSubcription(nodeId) {
        //Array structure created for subscription for index.html
        var subscribePoints = [{
                uid: "#oatData",
                nodeId: nodeId,
                data: "prophetData:Haystack/weather/temperature/numeric/outdoorAirTemperatureNOAANum"
            },
            {
                uid: "#relHumidData",
                nodeId: nodeId,
                data: "prophetData:Haystack/weather/humidity/numeric/outdoorAirRelHumidityNOAANum"
            },
            {
                uid: "#dewPtData",
                nodeId: nodeId,
                data: "prophetData:Haystack/weather/temperature/numeric/outdoorAirDewpointNOAANum"
            },
            {
                uid: "#windSpeedData",
                nodeId: nodeId,
                data: "prophetData:Haystack/weather/wind/numeric/windSpeedNum"
            },
            {
                uid: "#stationData",
                nodeId: nodeId,
                data: "prophetData:Haystack/weather/provider/string/weatherProviderStr"
            },
            {
                uid: "#criticalData",
                nodeId: nodeId,
                data: "prophetData:Calculations/Metrics/criticalFault"
            },
            {
                uid: "#safetyData",
                nodeId: nodeId,
                data: "prophetData:Calculations/Metrics/safetyFault"
            },
            {
                uid: "#energyData",
                nodeId: nodeId,
                data: "prophetData:Calculations/Metrics/energyFault"
            },
            {
                uid: "#mallhrsData",
                nodeId: nodeId + "/Scheduling/Schedules/MallHours",
                data: "prophetData:Haystack/schedules/scheduleOut"
            },
            {
                uid: "#sunset2sunriseData",
                nodeId: nodeId + "/Scheduling/Schedules/SunsetToSunrise",
                data: "prophetData:Haystack/schedules/scheduleOut"
            },
            {
                uid: "#hr2sunriseData",
                nodeId: nodeId + "/Scheduling/Schedules/HourToSunrise",
                data: "prophetData:Haystack/schedules/scheduleOut"
            },
            {
                uid: "#sunset2hrData",
                nodeId: nodeId + "/Scheduling/Schedules/SunsetToHour",
                data: "prophetData:Haystack/schedules/scheduleOut"
            },
            {
                uid: "#twentyFourHoursData",
                nodeId: nodeId + "/Scheduling/Schedules/TwentyFourHours",
                data: "prophetData:Haystack/schedules/scheduleOut"
            },
            {
                uid: "#extendedHoursData",
                nodeId: nodeId + "/Scheduling/Schedules/ExtendedHours",
                data: "prophetData:Haystack/schedules/scheduleOut"
            },
            {
                uid: "#mgmtHoursData",
                nodeId: nodeId + "/Scheduling/Schedules/ManagementHours",
                data: "prophetData:Haystack/schedules/scheduleOut"
            },
            {
                uid: "#special1Data",
                nodeId: nodeId + "/Scheduling/Schedules/SpecialEventHours1",
                data: "prophetData:Haystack/schedules/specialEventOut"
            },
            {
                uid: "#special2Data",
                nodeId: nodeId + "/Scheduling/Schedules/SpecialEventHours2",
                data: "prophetData:Haystack/schedules/specialEventOut"
            },
            {
                uid: "#theaterHoursData",
                nodeId: nodeId + "/Scheduling/Schedules/TheaterHours",
                data: "prophetData:Haystack/schedules/scheduleOut"
            },
            {
                uid: "#ggpindData",
                nodeId: nodeId,
                data: "prophetData:Calculations/Metrics/ggpIndex"
            },
            {
                uid: "#comfortindData",
                nodeId: nodeId,
                data: "prophetData:Calculations/Metrics/comfortIndex"
            },
            {
                uid: "#energyindData",
                nodeId: nodeId,
                data: "prophetData:Calculations/Metrics/energyIndex"
            },
            {
                uid: "#treesSavedData",
                nodeId: nodeId,
                data: "prophetData:GGP/emissions/treesSavedNum"
            },
            {
                uid: "#oilSavedData",
                nodeId: nodeId,
                data: "prophetData:GGP/emissions/oilSavedNum"
            },
            {
                uid: "#co2Saved",
                nodeId: nodeId,
                data: "prophetData:GGP/emissions/co2SavedNum"
            },
            {
                uid: "#kwhSavedYo",
                nodeId: nodeId,
                data: "prophetData:GGP/emissions/kwhSavedNum"
            },
            {
                uid: "#avgZoneTempData",
                nodeId: nodeId,
                data: "prophetData:Calculations/Metrics/avgZoneTemp"
            },
            {
                uid: "#homepowerData",
                nodeId: nodeId,
                data: "prophetData:Haystack/elecMeter/numeric/elecMeterRealPowerNum"
            },
            {
                uid: "#genMngData",
                nodeId: nodeId + "/SiteProperties/Contacts",
                data: "prophetData:Haystack/site/string/genMgrName"
            },
            {
                uid: "#gmEmailData",
                nodeId: nodeId + "/SiteProperties/Contacts",
                data: "prophetData:Haystack/site/string/genMgrEmail"
            },
            {
                uid: "#genPhData",
                nodeId: nodeId + "/SiteProperties/Contacts",
                data: "prophetData:Haystack/site/string/genMgrNumber"
            },
            {
                uid: "#opMngData",
                nodeId: nodeId + "/SiteProperties/Contacts",
                data: "prophetData:Haystack/site/string/opMgrName"
            },
            {
                uid: "#opEmailData",
                nodeId: nodeId + "/SiteProperties/Contacts",
                data: "prophetData:Haystack/site/string/opMgrEmail"
            },
            {
                uid: "#opPhData",
                nodeId: nodeId + "/SiteProperties/Contacts",
                data: "prophetData:Haystack/site/string/opMgrNumber"
            },
            {
                uid: "#energyTotalData",
                nodeId: nodeId,
                data: "prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum",
                tags: ['utilityMeter'],
                timeRange: "today"
            }

        ];
        var updateSubscribePoints = function(values) {
            _.each(values, function(val) {

                var $el = $(val.uid);
                $el.html(val.value);
                if (val.v === 'true') {
                    $el.parent('li').css({fontWeight: 'bold'});
                } else {
                    $el.parent('li').css({fontWeight: 'normal'});
                }
            });
        };

        var subscribeUid = _.uniqueId('home');

        var subscribeReq = TMPLS.subscribe({uid: subscribeUid, values: subscribePoints});
        util.subscribe(subscribeReq, subscribeUid, updateSubscribePoints);

        var pollreq = util.pollReq(subscribeUid);

        var pollPoints = function(pollReq, uid, cb) {
            niagara.postReq("testPath", pollReq, function(xml) {
                var pollData = util.parsePollSubcriptionXml(xml);
                cb(pollData.values);
            });
        };

        util.kickoffPolling({
            fxn: pollPoints,
            args: [pollreq, subscribeUid, updateSubscribePoints],
            interval: 10000
        });



    }
});
