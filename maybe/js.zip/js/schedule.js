
/******************************************************************
 * schedule.js
 Controlco Inc
 * Author: Deepti Phadnis
 ******************************************************************/



jQuery(document).ready(function($) {

 var loc = location.search.substring(1, location.search.length);
 
 var param_value = false;
 var params = loc.split("&");
 var ord = params[0].substring(params[0].indexOf('=')+1);
 
 var hvacElement = document.getElementById("HVACButton");
 
$data = {
   regionPath : "",
   scheduleType : "General",
   scheduleName : "",
   virSchPath : ""
 }; 
 $data.regionPath=ord;

 if(params[1] &&  params[1]!=null && params[1]!="")
 {
  $grpZone.schedName=params[1].substring(params[1].indexOf('=')+1);
 }  
 if(params[2] &&  params[2]!=null && params[2]!="")
 {
  $grpZone.isVirtual=params[2].substring(params[2].indexOf('=')+1);
  $grpZone.virSchPath=params[3].substring(params[3].indexOf('=')+1);
  $data.virSchPath = $grpZone.virSchPath;
 }  
 if(params[4] &&  params[4]!=null)
 {
  var s = params[4].substring(params[4].indexOf('=')+1);
  if(s != null)
   $grpZone.selectedGroupName=s;
  else
   $grpZone.selectedGroupName="";
 }
 if(params[5] &&  params[5]!=null)
 {
  var s = params[5].substring(params[5].indexOf('=')+1);
  if(s != null)
   $grpZone.selectedZoneName=s;
  else
   $grpZone.selectedZoneName="";
  
 }  
 if(params[6] &&  params[6]!=null)
 {
  var s = params[6].substring(params[6].indexOf('=')+1);
  if(s != null)
   $grpZone.selectedSubZoneName=s;
  else
   $grpZone.selectedSubZoneName="";
  
 }  
 

 var output = [];
  
 var $currWeeklySchedule = [];
 var $newWeeklySchedule = [];
    
    var hvacList = [];
    var lightingList = [];
    var generalList = [];
    
var oldEventName="";
var newEventName="";
var grpZone={};
var intr;

//$util.setValueEditBox();

var windLoc = window.location+"";

function parseTableXml (xml) {
            var d = $.xml2json(xml, '');
            var da = d.ProphetResponse;
            var methodResponses = _.isArray(da.MethodResponse) ? da.MethodResponse : [da.MethodResponse];
            var uid, props, respRows, rows = [];
            _.each(methodResponses, function(resp) {
                uid = resp['@uid'];
                // the table 'h' header row columns name the properties
                // for the values in the table 'r' row columns
                props = resp.t.h.c;
                if ( !! resp.t.r) {
                    respRows = _.isArray(resp.t.r) ? resp.t.r : [resp.t.r];
                }
                else {
                    respRows = [];
                }

                _.each(respRows, function(row) {
                    var obj = {};
                    _.each(row.c, function(col, i) {
                        obj[props[i]] = col || '';
                    });
                    obj.uid = uid;
                    rows.push(obj);
                })

            });
            return {
                uid: uid,
                rows: rows
            };
        }

function getTableQuery1(ord, query) {
            var req = "xml=<ProphetRequest version='1'>" +
                "<Method name='getTable' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + ord + "</nodeId>" +
                "<query>" + query + "</query>" +
                "<headers>displayName</headers>" +
                "</Method>" +
                "</ProphetRequest>";
           return req; 

        }
function setAttributesRequest(ord,attr,value) {
  var req = "xml=<ProphetRequest version='1'>" +
                "<Method name='setAttributes' uid='"+attr+"'>" +
                "<nodeId>" + ord + "</nodeId>" +
                "<attr n='" + attr + "'>" + value + "</attr>" +
                "</Method>" +
                "</ProphetRequest>";
           return req; 
}
       



 $.niagara.getChildren($data.regionPath,function(obj){
  if(obj.value.length > 0)
    {
	var mallName = $data.regionPath.split('/');
    var query = "bql:select slotPath as 'slotPath',attrs.deName as 'deName', attrs.disName as 'name' from csi3prophet:ProphetNode where declaredTags like 'schedule'";
    var slotPath =  "slot:/DataTree/GGP/GA/"+ mallName[3] +"/Scheduling/Schedules";
    var scheduleRequest= getTableQuery1(slotPath, query);
    var tableData ;

    // Ajax call to get the schedule disName and deName.
    $.ajax({
      url : '/p?http://172.28.20.16/prophet?',
      data: scheduleRequest,
      async: false,
      type:  'GET',   // All operations will be "GET" apart from the Batch Subscribe for 'watch'...
      dataType: 'xml', 
      success: function(response) {
        var res = response.getElementsByTagName("ProphetResponse");
            tableData = parseTableXml(res[0]);
      }

    });
   for(var i=0;i<obj.value.length;i++)
     {
     var sched = {
       name: "name", //disName
       deName: "deName",
       description:"description",
       path:"path",
       requiredPath:"",
       defaultOp:"",
       input:"",
       currOp:"",
       nextOp:""
        };
	
	 _.each(tableData.rows, function(row) {

          if (obj.value[i].name === row.deName) {
            sched.name = row.name;
            sched.deName = row.deName;
            sched.requiredPath = row.slotPath;
          }
     });
    //var scheduleName = obj.value[i].name;
    sched.description = obj.value[i].description;
    sched.path = obj.value[i].path;
    sched.defaultOp = obj.value[i].defaultOp;
    sched.input = obj.value[i].input;
    sched.currOp = obj.value[i].currOp;
    sched.nextOp = obj.value[i].nextOp;
    
     if(obj.value[i].scheduleType=="HVAC")
      hvacList.push(sched);
     else if(obj.value[i].scheduleType=="Lighting")
      lightingList.push(sched);
     else if(obj.value[i].scheduleType=="General")
      generalList.push(sched);
     }
	 var oldTextValue;
     $('#HVAC').on('click','span.startEdit',function() {

      oldTextValue = $("#HVACButton").text();

      $(this).parent().append('<input type="text" value="' + oldTextValue + '">');
      $(this).parent().append('<span class="edit checkboxingNow"></span><span class="edit XBox"></span>');
      $(this).remove();
      $('#HVACButton').prop('disabled', true);
        
     })

     $('#HVAC').on('click','span.checkboxingNow',function() {

        newTextValue = $(this).parent().find('input').val();
       $("#HVACButton").html(newTextValue+'<span class="caret"></span>');

        var editSlotPath = hvacElement.getAttribute('data-id');
        
        //niagara request to set the "disName" attribute value
        var setAttributesReq = setAttributesRequest(editSlotPath,'disName',newTextValue);
        $.niagara.setAttributes("testPath", setAttributesReq);

        //get the list elements and update the appropriate one with newTextValue
        var listElements = document.getElementById("hvac_list").getElementsByTagName("li");
        _.each(listElements, function(liElement){
          if(oldTextValue === liElement.getElementsByTagName("a")[0].text) {
            liElement.getElementsByTagName("a")[0].text = newTextValue;
          } 
        });
		_.each(generalList, function(list){
              if(oldTextValue === list.name) {
                list.name = newTextValue;
              }
         });
		$('#HVACButton').prop('disabled', false);
        $(this).parent().children('input').remove();
        $('.XBox').remove();
        $(this).removeClass('checkboxingNow').addClass('startEdit');

     });

     $('#HVAC').on('click', 'span.XBox', function() {
            $(this).parent().children('input').remove();
            $('#HVACButton').prop('disabled', false);
            $('span.checkboxingNow').removeClass('checkboxingNow').addClass('startEdit');
            $('.XBox').remove();

        });

	 
   $("#isSelected").attr("checked",false);
   var schList = ''; 
     for(var j=0;j<generalList.length;j++)
     {
     schList = schList + '<li><a href="#" value="'+generalList[j].deName+'">'+generalList[j].name+'</a></li>';
     }
     $("#hvac_list").append(schList);
     
    if(generalList.length > 0)
    {
     if(params[1] &&  params[1]!=null && params[1]!="")
     { 
      $data.scheduleName = ""+params[0].substring(params[0].indexOf('=')+1)+"/"+$grpZone.schedName;
      $("#NamePlaceholder h2").text(generalList[0].description);
         var date = $util.normalizeDate();
         var grpSchedName= $grpZone.schedName;
         $("#HVACButton").html(grpSchedName+' <span class="caret"></span>');
         
      
    for(var i=0;i<generalList.length;i++)
    {
     if(generalList[i].deName == $grpZone.schedName)
      {
	  hvacElement.setAttribute("data-id", generalList[i].requiredPath);
        $("#HVACButton").html(generalList[i].name+'<span class="caret"></span>');
      var str = $util.getScheduleValues(generalList[i]);
         $( "#scheduleDesc" ).qtip( {
                content     : {
                 title: "Description",
                 text: str
                },
                position    : {
                    target  : 'mouse'
                },
                style: { classes: 'qtip-blue',
                 'font-size':12},
                 show: { event: 'click'}, 
           
        hide: {event: 'unfocus' } 
             });
      }
    }
    $grpZone.getVirtualHtml($data.scheduleName,"#GroupNames","#GroupButton","#editGroup",'','Sub Schedules <span class="caret"></span>',$grpZone.selectedGroupName);

    if($grpZone.isVirtual=="false")
    {
     $("#isSelected").attr("checked",false);
     $grpZone.checkIsSelected("false");
      $util.getMonthlySchedule(date,$data.scheduleName);
          //getVirtualScheduleList($data.scheduleName);
    } 
    else
    {
//     $("#isSelected").attr("checked",true);
     $grpZone.checkIsSelected("true");
     
     //$grpZone.getVirtualScheduleList($data.scheduleName);
    var date = $util.normalizeDate();
     $util.getVirtualMonthlySchedule(date,$data.scheduleName,$data.virSchPath);
     var d =  $grpZone.schedName;
     var a="",b="",c="";
     
       if($grpZone.selectedGroupName!="")
       {   
      $("#Group").show();
        $("#GroupNames").html("");
//       $grpZone.getVirtualHtml($data.scheduleName,"#GroupNames","#GroupButton","#editGroup",'','Groups <span class="caret"></span>',$grpZone.selectedGroupName);
       $("#editGroup").show();
       var n = $grpZone.selectedGroupName.split("*");
      n[0] = unescape(n[0]);
       a = " / "+n[0];

        $("#editGroup").click(function()
        {
          var jsonStr={
            "isVirtual" : ""+ $grpZone.isVirtual,
            "virSchPath" : $data.virSchPath,
            "selectedGroupName" : $grpZone.selectedGroupName,
            "selectedZoneName" : $grpZone.selectedZoneName,
            "selectedSubZoneName" : $grpZone.selectedSubZoneName
          };
          var jsonF = JSON.stringify(jsonStr);
          var alink = "groupEdit.html?ord="+$data.scheduleName+"&virSchPath="+$data.virSchPath+"&name="+a+"&json="+jsonF; 
          $("#editGroup").attr('href',alink);
       });
       
      $("#Zones").show();
      $("#ZoneButton").show();
       $grpZone.getVirtualHtml(n[1],"#ZoneNames","#ZoneButton","#editZone","#closeZone",'Zones <span class="caret"></span>'); 
       
       
       if($grpZone.selectedZoneName!="")
           {   
       $("#Zones").show();
        var m = $grpZone.selectedGroupName.split("*");
          m[0] = unescape(m[0]);
           
          
          var n = $grpZone.selectedZoneName.split("*");
          n[0] = unescape(n[0]);
          b = " / "+n[0];

          $("#ZoneNames").html("");
          //$grpZone.getVirtualHtml(m[1],"#ZoneNames","#ZoneButton","#editZone","#closeZone",'Zones <span class="caret"></span>',$grpZone.selectedZoneName);
          $("#editZone").show();
          $("#closeZone").css("display","block");
          
          $("#editZone").click(function()
             {
               var jsonStr={
                 "isVirtual" : ""+ $grpZone.isVirtual,
                 "virSchPath" : $data.virSchPath,
                 "selectedGroupName" : $grpZone.selectedGroupName,
                 "selectedZoneName" : $grpZone.selectedZoneName,
                 "selectedSubZoneName" : $grpZone.selectedSubZoneName
               };
               var jsonF = JSON.stringify(jsonStr);
               var alink = "groupEdit.html?ord="+$data.scheduleName+"&virSchPath="+$data.virSchPath+"&name="+b+"&json="+jsonF; 
               $("#editZone").attr('href',alink);
            });
          
           $("#SubZones").show();
           $("#SubZoneButton").show();
            $grpZone.getVirtualHtml(n[1],"#SubZoneNames","#SubZoneButton","#editSubZone","#closeSubZone",'Sub Zones <span class="caret"></span>',$grpZone.selectedSubZoneName); 
          
             if($grpZone.selectedSubZoneName!="")
               {   
            $("#SubZones").show();
            var m = $grpZone.selectedGroupName.split("*");
                 m[0] = unescape(m[0]);
               var n = $grpZone.selectedZoneName.split("*");
              n[0] = unescape(n[0]);

               var o = $grpZone.selectedSubZoneName.split("*");
              o[0] = unescape(o[0]);
              c = " / "+o[0];
              
              $("#SubZoneNames").html("");
              //$grpZone.getVirtualHtml(n[1],"#SubZoneNames","#SubZoneButton","#editSubZone","#closeSubZone",'Sub Zones <span class="caret"></span>',$grpZone.selectedSubZoneName);
              $("#editSubZone").show();
              $("#closeSubZone").css("display","block");
              
            $("#editSubZone").click(function()
          {
            var jsonStr={
              "isVirtual" : ""+ $grpZone.isVirtual,
              "virSchPath" : $data.virSchPath,
              "selectedGroupName" : $grpZone.selectedGroupName,
              "selectedZoneName" : $grpZone.selectedZoneName,
              "selectedSubZoneName" : $grpZone.selectedSubZoneName
            };
            var jsonF = JSON.stringify(jsonStr);
            var alink = "groupEdit.html?ord="+$data.scheduleName+"&virSchPath="+$data.virSchPath+"&name="+c+"&json="+jsonF; 
            $("#editSubZone").attr('href',alink);
         });
              
               }
             
           }
      
       }
       $("#path").text(d+a+b+c);
    }
    
    /*$(window).unload(function() {
     clearInterval(intr);
    });
    
   
    intr = setInterval(function(){
     var date = $util.normalizeDate();
     if($grpZone.isVirtual=="true" && $data.virSchPath!="")
      {
     
     var date = $util.normalizeDate();
     $util.getVirtualMonthlySchedule(date,$data.scheduleName,$data.virSchPath);
      }
     else
      $util.getMonthlySchedule(date,$data.scheduleName);
    },
    20000);*/
     }
     
     else
     {  
   $data.scheduleName = generalList[0].path;
  hvacElement.setAttribute("data-id", generalList[0].requiredPath);
   $("#HVACButton").html(generalList[0].name+'<span class="caret"></span>');
   $("#path").text(generalList[0].name);
      var str = $util.getScheduleValues(generalList[0]);
       
       $( "#scheduleDesc" ).qtip( {
                 content     : {
                  title: "Description",
                  text: str
                 },
                 position    : {
                     target  : 'mouse'
                 },
                 style: { classes: 'qtip-blue',
                  'font-size':12},
                  show: { event: 'click'}, 
            
         hide: {event: 'unfocus' } 
              });
    
    /*var date = $util.normalizeDate();
     $util.getMonthlySchedule(date,$data.scheduleName);

    $(window).unload(function() {
     clearInterval(intr);
    });     
    intr = setInterval(function(){
     var date = $util.normalizeDate();
     $util.getMonthlySchedule(date,$data.scheduleName);
    },
    20000);*/
    $grpZone.getVirtualHtml($data.scheduleName,"#GroupNames","#GroupButton","#editGroup",'Sub Schedules <span class="caret"></span>');
    $grpZone.getScheduleData();
     }
    }
 $("ul#hvac_list li a").click(function(){
    var str = $(this).text();
    var arr=[];
     arr = generalList;
    
    for(var i=0;i<arr.length;i++)
    {
     if(arr[i].name == str)
      {
    hvacElement.setAttribute("data-id", arr[i].requiredPath);
    $("#HVACButton").html(str+'<span class="caret"></span>');  
    $("#path").text(str); 
       $data.scheduleName = arr[i].path;
      var date = $util.normalizeDate();
      $util.getMonthlySchedule(date,$data.scheduleName);
      $("#NamePlaceholder h2").text(arr[i].description);
      var str = $util.getScheduleValues(arr[i]);
       
         $( "#scheduleDesc" ).qtip( {
             content     : {
              title: "Description",
              text: str
             },
             position    : {
                 target  : 'mouse'
             },
             style: { classes: 'qtip-blue',
              'font-size':12},
              show: { event: 'click'}, 
        
     hide: {event: 'unfocus' } 
          });
   $grpZone.isVirtual=="false";
         $grpZone.getVirtualHtml($data.scheduleName,"#GroupNames","#GroupButton","#editGroup",'Sub Schedules <span class="caret"></span>');
   $grpZone.selectedGroupName="";
   $grpZone.selectedZoneName="";
   $grpZone.selectedSubZoneName="";
   //$grpZone.checkIsSelected("false"); 
   //$grpZone.getScheduleData();
      }
    }
   });
      
    }
  });
 
 
 $('#calendar').fullCalendar({
  //height:$(document).height(),
    height:500,
    
          // put your options and callbacks here
   header: {
    left: 'prev,next',
    center: 'title',
    right: 'month,agendaWeek,agendaDay'
   },
   selectable: false,
   selectHelper: false,
   
   editable: true,
   loading: function(bool){
    if(bool)
     $('#loading').show();
    else
     $('#loading').hide();
   },
    events: function(start,end,callback){
    },
    dayClick: function(date, allDay, jsEvent, view) {
   },
   
   eventClick: function(calEvent, jsEvent, view) {
    $('.qtip').each(function(){
     $(this).qtip('hide');
  });
    
    var v = $data.virSchPath;
    var jsonStr={
      "title" : calEvent.name,
      "startH" : ""+calEvent.start.getHours(),
      "startM" : ""+calEvent.start.getMinutes(),
      "startDay" : ""+calEvent.start.getDate(),
      "startMon" : ""+calEvent.start.getMonth(),
      "startYear" : ""+calEvent.start.getFullYear(),
      "endH" : ""+calEvent.end.getHours(),
      "endM" : ""+calEvent.end.getMinutes(),
      "isException" : ""+ calEvent.isException,
      "isVirtual" : ""+ calEvent.isVirtual,
      "actualExceptionName" : ""+ calEvent.actualExceptionName,
      "output" : calEvent.output,
      "virSchPath" : v,
      "selectedGroupName" : $grpZone.selectedGroupName,
      "selectedZoneName" : $grpZone.selectedZoneName,
      "selectedSubZoneName" : $grpZone.selectedSubZoneName
    };
    var jsonF = JSON.stringify(jsonStr);
    var obj = jQuery.parseJSON(jsonF);
    window.location.href = "editEvent.html?ord="+$data.scheduleName+'&json='+jsonF;

  },
  eventMouseover: function(event,jsEvent)
  {
   jQuery(this).qtip();
  },
  eventMouseout: function(event)
  {
    $(event).qtip('hide'); 
       $('.qtip').each(function(){
    $(this).qtip('hide');
     });
  //$(this).qtip().hide();
  },

  eventRender: function(event, element) {
    var title = "";
    if(event.isException == "false")
    {
     title = "<p><b>Event Name : "+event.title+"</b>  ("+event.type+")</p>";
    }
    else
    {
     title = "<p><b>Event Name : "+event.title+"</b>  ("+event.type+"  Exception)</p>";
    }
    
    var priority = "<p><b>Event Priority : "+event.priority+"</b></p>";
    var sMin = '',eMin='';
    var startTime="";
    if(event.start!=null)
    {    
     if(event.start.getMinutes() < 10)
      sMin = '0'+ event.start.getMinutes();
     else
      sMin = event.start.getMinutes();
    
     if(event.start.getHours() > 12)
     {
      var k = event.start.getHours()-12;
      startTime = "<p><b>Start Time</b> : "+k+":"+sMin+" PM</p>";   
     }
     else if(event.start.getHours() == 12)
     {
      startTime = "<p><b>Start Time</b> : "+12+":"+sMin+" PM</p>";
     }   
     else
     {
       if(event.start.getHours() == 0)
        startTime = "<p><b>Start Time</b> : "+12+":"+sMin+" AM</p>";
       else
        startTime = "<p><b>Start Time</b> : "+event.start.getHours()+":"+sMin+" AM</p>";
     }
    }
    var endTime="";
    if(event.end!=null)
    {
     if(event.end.getMinutes() < 10)
       eMin = '0'+ event.end.getMinutes();
      else
       eMin = event.end.getMinutes();
    
    // var endTime="<p><b>End Time</b> : "+event.end.getHours()+":"+event.end.getMinutes()+"</p>";
      if(event.end.getHours() > 12)
      {
       var k = event.end.getHours()-12;
       endTime = "<p><b>End Time</b> : "+k+":"+eMin+" PM</p>";   
      }
      else if(event.end.getHours() == 12)
      {
       endTime = "<p><b>End Time</b> : "+12+":"+eMin+" PM</p>";
      }   
      else
      {
        if(event.end.getHours() == 0)
         endTime = "<p><b>End Time</b> : "+12+":"+eMin+" AM</p>";
        else
         endTime = "<p><b>End Time</b> : "+event.end.getHours()+":"+eMin+" AM</p>";
      }
    
    }     
    var outputs = "<p><b>Outputs:</b></p>";
    for(var i=0;i<(event.output.length);i=i+3)
    {
     outputs = outputs + "<p>"+event.output[i]+":";
     outputs = outputs + event.output[i+1]+"</p>";
    }
    element.qtip({
      content: {
       text:"<div>"+title+priority+startTime+endTime+outputs+"</div>"
      },
      position: {
          my: 'top center',
          at: 'bottom center'
          },
             style: { classes: 'qtip-light'}
      });
  },
  eventAfterRender: function(calEvent,element) 
 {
   if(calEvent.active == "ACTIVE")
   { 
    
    element.marquee({
    duration: 3000,
    duplicate: false
    }).css({"border":"1px solid black","overflow":"hidden","border-radius":"10px"});
   }
   if(calEvent.active == "next event")
   { 
    element.marquee({
    duration: 3000,
    duplicate: false
    }).css({"border":"1px solid black","overflow":"hidden","border-radius":"10px"});
   }
   
},
  viewDisplay: function(view)
  {
      var date = $util.normalizeDate();
      
      $grpZone.getScheduleData(date);
      //$util.getMonthlySchedule(date,$data.scheduleName);
  }

 });
 $util.loadAddEvents();
 $("#addEventPage").click(function()
   {
  var alink = "addEvent.html?ord="+$data.scheduleName; 
  $("#addEventPage").attr('href',alink);
   });

 $("#sunOffsetPage").click(function()
   {
  var alink = "sunOffset.html?ord="+$data.scheduleName; 
  $("#sunOffsetPage").attr('href',alink);
   });

 $("#reorderEventsPage").click(function()
   {
  var alink = "reorderEvents.html?ord="+$data.scheduleName; 
  $("#reorderEventsPage").attr('href',alink);
   });

 $("#eventClassesPage").click(function()
   {
  var alink = "eventClasses.html?ord="+$data.scheduleName; 
  $("#eventClassesPage").attr('href',alink);
   });
 
 $("#overridePage").click(function()
   {
  var alink = "override.html?ord="+$data.scheduleName; 
  $("#overridePage").attr('href',alink);
   });
 $("#outputPage").click(function()
   {
  var alink = "output.html?ord="+$data.scheduleName; 
  $("#outputPage").attr('href',alink);
   });
 $("#miscPage").click(function()
   {
  var alink = "misc.html?ord="+$data.scheduleName; 
  $("#miscPage").attr('href',alink);
   });

 
 $("#backButton").click(function()
   {
   var arr = params[0].split("/");
   var sched = arr[arr.length-1];
   params[0]="";
   for(var i=0;i<arr.length-1;i++)
   { 
    if(i<arr.length-2)
     params[0] = params[0]+arr[i]+"/";
    else
     params[0] = params[0]+arr[i];
   }
   var alink = "indexRelative.html?ord="+params[0]+"&sched="+sched;
   $("#backButton").attr('href',alink);
});

 $("#hvacSelect").click(function()
 {
  createScheduleList(hvacList);
 });
 $("#lightingSelect").click(function()
 {
  createScheduleList(lightingList);
 });
 $("#generalSelect").click(function()
 {
  createScheduleList(generalList);
 });
 
 
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     
    $('#mask').click(function () {
        $(this).hide();
        $('.window').hide();
    });         

 /* Get the metering present datapoint and store its result */
  

 
 //$.niagara.BatchPoll.printPollList();
});
