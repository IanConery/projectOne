// JavaScript Document
/*****************************************************************
  Controlco Inc
  Author: Deepti Phadnis
 *****************************************************************/ 

;(function($) {
	
		(function() {
				  
		})();
		
		var $jsonObj;
		$util = {
				getMonthlySchedule : function(date,path){
					var monthEvents = [];
					setTimeout(function(){
						$.niagara.getMonthlySchedule(path,date, function(obj){
						for(var i=0;i<obj.value.length;i++)
						{
							/*if(obj.currEventStartYear == obj.value[i].eventStartYear && 
									obj.currEventStartMonth == obj.value[i].eventStartMonth &&
									obj.currEventStartDay == obj.value[i].eventStartDay && 
									obj.currentActiveEvent == obj.value[i].eventName)
								{
									alert("aaa");	
									monthEvents = monthEvents.concat(getDayEvents(obj.value[i],));
								}		
								else if (obj.nextEventStartYear == obj.value[i].eventStartYear && 
									obj.nextEventStartMonth == obj.value[i].eventStartMonth &&
									obj.nextEventStartDay == obj.value[i].eventStartDay && 
									obj.nextActiveEvent == obj.value[i].eventName)
								monthEvents = monthEvents.concat(getDayEvents(obj.value[i],"NEXT ACTIVE"));
							else*/
								monthEvents = monthEvents.concat(getDayEvents(obj.value[i],obj.currEvent,obj.nextEvent));
						}
						addNewWeeklySched(monthEvents);
					});
					},1000);
				},
				getVirtualMonthlySchedule : function(date,path,virSchPath){
					var monthEvents = [];
					setTimeout(function(){
						$.niagara.getVirtualMonthlySchedule(path,virSchPath,date, function(obj){
						for(var i=0;i<obj.value.length;i++)
						{
							monthEvents = monthEvents.concat(getDayEvents(obj.value[i],obj.currEvent,obj.nextEvent));
						}
						addNewWeeklySched(monthEvents);
					});
					},1000);
				},				
				getWeeklySchedule: function(date)
				{
					var weekEvents = [];
					$.niagara.getWeeklySchedule($data.scheduleName,date, function(obj){
						for(var i=0;i<obj.value.length;i++)
						{
							weekEvents = weekEvents.concat(getDayEvents(obj.value[i]));
						}
						addNewWeeklySched(weekEvents);
					});
				},
				loadAddEvents: function()
				{
					   $("#weekAndDay").hide();/* One time*/
					   $("#oneTime").show();
					   $("#addSkipDays").hide();
					   $("#addDateRange").hide();
					   $("#addTradHours").hide();
					   $("#addWeeklyEvent").hide();
					   $("#addMonthlyEvent").hide();
					   $("#addYearlyEvent").hide();
				},
				setValueEditBox: function()
				{
					$("#weekAndDay").hide();
					$("#addSkipDays").hide();
					$("#addTradHours").hide();
					var k=0;
					for(k=1;k<13;k++)
					{	
			 			$("#startHour").append($('<option>',{value : k}).text(k));
			 			$("#endHour").append($('<option>',{value : k}).text(k));
			 			$("#addEventEditStartHour").append($('<option>',{value : k}).text(k));
			 			$("#addEventEditEndHour").append($('<option>',{value : k}).text(k));
					}
					for(k=0;k<60;k++)
					{
			 			$("#startMin").append($('<option>',{value : k}).text(k));
			 			$("#endMin").append($('<option>',{value : k}).text(k));
			 			$("#addEventEditStartMin").append($('<option>',{value : k}).text(k));
			 			$("#addEventEditEndMin").append($('<option>',{value : k}).text(k));
					}
					for(k=1;k<32;k++)
					{
			 			$("#addEventEditDay").append($('<option>',{value : k}).text(k));
			 			$("#editEventEditDay").append($('<option>',{value : k}).text(k));
			 			$("#editStartDay").append($('<option>',{value : k}).text(k));
			 			$("#editEndDay").append($('<option>',{value : k}).text(k));
			 			$("#addDrStartDate").append($('<option>',{value : k}).text(k));
			 			$("#addDrEndDate").append($('<option>',{value : k}).text(k));
			 			$("#addMonthlyEditDay").append($('<option>',{value : k}).text(k));
			 			$("#monthlyEditDay").append($('<option>',{value : k}).text(k));
			 			$("#addYearlyEditDay").append($('<option>',{value : k}).text(k));
			 			$("#yearlyEditDay").append($('<option>',{value : k}).text(k));

					}
					for(k=2010;k<2025;k++)
					{
			 			$("#addEventEditYear").append($('<option>',{value : k}).text(k));
			 			$("#editEventEditYear").append($('<option>',{value : k}).text(k));
			 			$("#editStartYear").append($('<option>',{value : k}).text(k));
			 			$("#editEndYear").append($('<option>',{value : k}).text(k));
			 			$("#addDrStartYear").append($('<option>',{value : k}).text(k));
			 			$("#addDrEndYear").append($('<option>',{value : k}).text(k));
					}
					
					$("#startAmPm").append($('<option>',{value : 0}).text("AM"));
					$("#startAmPm").append($('<option>',{value : 1}).text("PM"));
					$("#endAmPm").append($('<option>',{value : 0}).text("AM"));
					$("#endAmPm").append($('<option>',{value : 1}).text("PM"));
					$("#addEventEditStartAMPM").append($('<option>',{value : 0}).text("AM"));
					$("#addEventEditStartAMPM").append($('<option>',{value : 1}).text("PM"));
					$("#addEventEditENdAMPM").append($('<option>',{value : 0}).text("AM"));
					$("#addEventEditENdAMPM").append($('<option>',{value : 1}).text("PM"));
					
					$("#addEventEditStartMode").append($('<option>',{value : 0}).text("Use This Time"));
					$("#addEventEditStartMode").append($('<option>',{value : 1}).text("Use Sunrise"));
					$("#addEventEditStartMode").append($('<option>',{value : 2}).text("Use Sunset"));
					
					$("#addEventEditEndMode").append($('<option>',{value : 0}).text("Use This Time"));
					$("#addEventEditEndMode").append($('<option>',{value : 1}).text("Use Sunrise"));
					$("#addEventEditEndMode").append($('<option>',{value : 2}).text("Use Sunset"));

					$("#editEventEditStartMode").append($('<option>',{value : 0}).text("Use This Time"));
					$("#editEventEditStartMode").append($('<option>',{value : 1}).text("Use Sunrise"));
					$("#editEventEditStartMode").append($('<option>',{value : 2}).text("Use Sunset"));
					
					$("#editEventEditEndMode").append($('<option>',{value : 0}).text("Use This Time"));
					$("#editEventEditEndMode").append($('<option>',{value : 1}).text("Use Sunrise"));
					$("#editEventEditEndMode").append($('<option>',{value : 2}).text("Use Sunset"));
				},
				normalizeDate : function ()
				{
					var d = $('#calendar').fullCalendar('getDate');
					//var d = new Date();
					var day = 1;
					if(d.getDate()<1)
						day = 1;
					else
						day = d.getDate();
				    var date = d.getFullYear()+":"+d.getMonth()+":"+day;
				    return date;
				},
				getSkipDays: function (obj)
				{
			         if(obj.Sunday == "true")
			             $('input[name=skipDays]#Sunday').attr('checked',true);
			            else
			             $('input[name=skipDays]#Sunday').attr('checked',false);
			              
			            if(obj.Monday == "true")
			             $('input[name=skipDays]#Monday').attr('checked',true); 
			            else
			             $('input[name=skipDays]#Monday').attr('checked',false);
			            
			            if(obj.Tuesday == "true")
			             $('input[name=skipDays]#Tuesday').attr('checked',true); 
			            else
			             $('input[name=skipDays]#Tuesday').attr('checked',false);
			            
			            if(obj.Wednesday == "true")
			             $('input[name=skipDays]#Wednesday').attr('checked',true); 
			            else
			             $('input[name=skipDays]#Wednesday').attr('checked',false);
			             
			            if(obj.Thursday == "true")
			             $('input[name=skipDays]#Thursday').attr('checked',true);
			            else
			             $('input[name=skipDays]#Thursday').attr('checked',false);
			              
			            if(obj.Friday == "true")
			             $('input[name=skipDays]#Friday').attr('checked',true);
			            else
			             $('input[name=skipDays]#Friday').attr('checked',false);
			              
			            if(obj.Saturday == "true")
			             $('input[name=skipDays]#Saturday').attr('checked',true);
			            else
			             $('input[name=skipDays]#Saturday').attr('checked',false);
			    

			            if(obj.Holidays == "true")
			             $('input[name=skipDays]#Holidays').attr('checked',true);
			            else
			             $('input[name=skipDays]#Holidays').attr('checked',false);
					
				},
				resetSkipDays: function (obj)
				{
			             $('input[name=addskipDays]#Sunday').attr('checked',false);
			             $('input[name=addskipDays]#Monday').attr('checked',false);
			             $('input[name=addskipDays]#Tuesday').attr('checked',false);
			             $('input[name=addskipDays]#Wednesday').attr('checked',false);
			             $('input[name=addskipDays]#Thursday').attr('checked',false);
			             $('input[name=addskipDays]#Friday').attr('checked',false);
			             $('input[name=addskipDays]#Saturday').attr('checked',false);
			             $('input[name=addskipDays]#Holidays').attr('checked',false);
				},
				resetTradEventOffset: function (obj)
				{
			             $('#addStartOffset').val(0);
			             $('#addEndOffset').val(0);
				},
				resetWeekly: function (obj)
				{
			             $('#addWeeklyEditWeekDay').val("0");
				},
				resetMonthly: function (obj)
				{
			             $('#addMonthlyEditDay').val("0");
				},
				resetYearly: function (obj)
				{
			             $('#addYearlyEditDay').val("0");
			             $('#addYearlyEditMonth').val("0");
				},
				loadAddPage: function (obj)
					{
					 var d = new Date();
					 var day = 1;
				  if(d.getDate()<1)
				   day = 1;
				  else
				   day = d.getDate();
				     $("#addEventName").val("");
				     $("#addEventType").val("0");
				     $("#weekAndDay").hide();
				     $("#addSkipDays").hide();
				     $("#addDateRange").hide();
				     $("#addTradHours").hide();
				     $("#addWeeklyEvent").hide();
				     $("#addMonthlyEvent").hide();
				     $("#addYearlyEvent").hide();
				     $("#oneTime").show();
				     
				     $("#addEventEditStartMode").val("0");
				     $("#addEventEditEndMode").val("0");

				     $("#addEventEditStartHour").val("1");
				     $("#addEventEditStartMin").val("0");
				     $("#addEventEditStartAMPM").val("0");
				     $("#addEventEditEndHour").val("1");
				     $("#addEventEditEndMin").val("0");
				     $("#addEventEditENdAMPM").val("0");
				     
				     $("#WNDaddEventEditWeekDay").val("0");
				     $("#WNDaddEventEditWeek").val("0");
				     $("#WNDaddEventEditMonth").val("0");
				     
				     
				     
				  $("#addEventEditDay").val(day);
				     $("#addEventEditMonth").val(d.getMonth());
				     $("#addEventEditYear").val(d.getFullYear());

				  $("#addDrStartDate").val(day);
				     $("#addDrStartMonth").val(d.getMonth());
				     $("#addDrStartYear").val(d.getFullYear());
				  $("#addDrEndDate").val(day);
				     $("#addDrEndMonth").val(d.getMonth());
				     $("#addDrEndYear").val(d.getFullYear());
					},
				loadEditPage: function (scheduleName,obj){
					
				    var jsonObj = obj;
				    $("#exceptionName").hide();
				    $("#removeExceptionButton").hide();
				     var today = new Date();
				     var scheduleName = scheduleName;
				     
				     if(jsonObj.isException=="true")
				     {
				    	 
				    	 $("#exceptionName").show();
				    	 $("#exceptionName").text("Exception");
				    	 $("#actualExceptionName").text(jsonObj.actualExceptionName);
				    	$("#removeExceptionButton").show();
				     }	 
				     $.niagara.getEventType(scheduleName,jsonObj.title,jsonObj.isVirtual,jsonObj.virSchPath,function(obj){
				     if(obj.value!= null)
				       {
				        $("#eventName").val(jsonObj.title);
				        oldEventName = jsonObj.title;
				        
				        $("#editEventClass").val(obj.value.eventClass);
				        var startMode = parseInt(obj.value.startTimeMode);
				        var endMode = parseInt(obj.value.endTimeMode);
				        
				        $("#editEventEditStartMode").val(startMode);
				        $("#editEventEditEndMode").val(endMode);
				        
				        jsonObj.startMode = startMode;
				        jsonObj.endMode = endMode;
				        
				        jsonObj.startM = parseInt(obj.value.startMin);
				        $("#startMin").val(jsonObj.startM);
				        
				        jsonObj.startH = parseInt(obj.value.startHour);
				        if(jsonObj.startH > 12)
				        {
				         var k = jsonObj.startH-12;
				         $("#startHour").val(k);
				         $("#startAmPm").val(1);
				        }
				        else if(jsonObj.startH == 12)
				        {
				            $("#startHour").val(12);
				            $("#startAmPm").val(1);
				        }
				        else
				        {
				          if(jsonObj.startH == 0)
				          {   
				           $("#startHour").val(12);
				          }
				          else
				           $("#startHour").val(jsonObj.startH);
				          $("#startAmPm").val(0);
				        }
				        
				        jsonObj.endM = parseInt(obj.value.endMin);
				        $("#endMin").val(jsonObj.endM);
				        
				        jsonObj.endH = parseInt(obj.value.endHour);
				        if(jsonObj.endH > 12)
				        {
				         var k = jsonObj.endH-12;
				         $("#endHour").val(k);
				         $("#endAmPm").val(1);
				        }
				        else if(jsonObj.endH == 12)
				        {
				            $("#endHour").val(12);
				            $("#endAmPm").val(1);
				        }
				        else
				        {
				        if(jsonObj.endH == 0)
				         $("#endHour").val(12);
				        else
				         $("#endHour").val(jsonObj.endH);
				          $("#endAmPm").val(0);
				        }
					      $("#editEventEditDay").val(jsonObj.startDay);
					      $("#editEventEditMonth").val(jsonObj.startMon);
					      $("#editEventEditYear").val(jsonObj.startYear);
				          $("#editDate").show();
				        

					        jsonObj.startH = $("#startHour").val();
					        jsonObj.startAP = $("#startAmPm").val();;
					        jsonObj.endH = $("#endHour").val();
					        jsonObj.endAP = $("#endAmPm").val();;
				          
				          
				         if (obj.value.name=="OneTimeEvent")
				        {
				          $("#eventType").text("OneTimeEvent");
				          $("#editSkipDays").hide();
				          $("#editWeekAndDay").hide();
				          $("#tradingHours").hide();
				          $("#editWeekly").hide();
				          $("#editDateRange").hide();
				          $("#editMonthly").hide();
				          $("#editYearly").hide();
				        }
				        else if(obj.value.name=="DailyEvent")
				        {
				          $util.getSkipDays(obj.value);
				          jsonObj.Sunday = obj.value.Sunday;
				          jsonObj.Monday = obj.value.Monday;
				          jsonObj.Tuesday = obj.value.Tuesday;
				          jsonObj.Wednesday = obj.value.Wednesday;
				          jsonObj.Thursday = obj.value.Thursday;
				          jsonObj.Friday = obj.value.Friday;
				          jsonObj.Saturday = obj.value.Saturday;
				          $("#eventType").text("DailyEvent");
				          $("#editSkipDays").show();
				          $("#editWeekAndDay").hide();
				          $("#tradingHours").hide();
				          $("#editWeekly").hide();
				          $("#editDateRange").hide();
				          $("#editMonthly").hide();
				          $("#editYearly").hide();
				        }
				        else if (obj.value.name=="DateRangeEvent")
				        {
				          $util.getSkipDays(obj.value);
				          jsonObj.Sunday = obj.value.Sunday;
				          jsonObj.Monday = obj.value.Monday;
				          jsonObj.Tuesday = obj.value.Tuesday;
				          jsonObj.Wednesday = obj.value.Wednesday;
				          jsonObj.Thursday = obj.value.Thursday;
				          jsonObj.Friday = obj.value.Friday;
				          jsonObj.Saturday = obj.value.Saturday;
				          jsonObj.drStartDay = obj.value.editStartDay;
				          jsonObj.drStartMonth = obj.value.editStartMonth;
				          jsonObj.drStartYear = obj.value.editStartYear;
				          jsonObj.drEndDay = obj.value.editEndDay;
				          jsonObj.drEndMonth = obj.value.editEndMonth;
				          jsonObj.drEndYear = obj.value.editEndYear;
					       
				           $("#editStartDay").val(obj.value.editStartDay);
					       $("#editStartMonth").val(obj.value.editStartMonth);
					       $("#editStartYear").val(obj.value.editStartYear);
					       $("#editEndDay").val(obj.value.editEndDay);
					       $("#editEndMonth").val(obj.value.editEndMonth);
					       $("#editEndYear").val(obj.value.editEndYear);
					       $("#eventType").text("DateRangeEvent");
					       
				          $("#editSkipDays").show();
				          $("#editWeekAndDay").hide();
				          $("#tradingHours").hide();
				          $("#editWeekly").hide();
				          $("#editDateRange").show();
				          $("#editMonthly").hide();
				          $("#editYearly").hide();
				        }
				        else if(obj.value.name=="MondayThroughFridayEvent")
				        {
				          $util.getSkipDays(obj.value);
				          $("#eventType").text("MondayThroughFridayEvent");
				          $("#editSkipDays").show();
				          $("#editWeekAndDay").hide();
				          $("#tradingHours").hide();
				          $("#editWeekly").hide();
				          $("#editDateRange").hide();
				          $("#editMonthly").hide();
				          $("#editYearly").hide();
				        }

				        else if (obj.value.name=="WeekAndDayEvent")
				        {
				          $util.getSkipDays(obj.value);
				          $('#WNDeditEventEditWeekDay').val(obj.value.editWeekDay);
				          $('#WNDeditEventEditWeek').val(obj.value.editWeek);
				          $('#WNDeditEventEditMonth').val(obj.value.editMonth);

				          jsonObj.wdDay = obj.value.editWeekDay;
				          jsonObj.wdWeek = obj.value.editWeek;
				          jsonObj.wdMonth = obj.value.editMonth;
				          
				          $("#eventType").text("WeekAndDayEvent");
				          $("#editSkipDays").show();
				          $("#editWeekAndDay").show();
				          $("#tradingHours").hide();
				          $("#editWeekly").hide();
				          $("#editDateRange").hide();
				          $("#editMonthly").hide();
				          $("#editYearly").hide();
				        }
				        else if (obj.value.name=="TradingHoursEvent")
				        {
				         $("#eventEdit").css("height",440);	
				         $('#startOffset').val(obj.value.editStartOffset);
				         $('#endOffset').val(obj.value.editEndOffset);
				          $util.getSkipDays(obj.value);
				          jsonObj.Sunday = obj.value.Sunday;
				          jsonObj.Monday = obj.value.Monday;
				          jsonObj.Tuesday = obj.value.Tuesday;
				          jsonObj.Wednesday = obj.value.Wednesday;
				          jsonObj.Thursday = obj.value.Thursday;
				          jsonObj.Friday = obj.value.Friday;
				          jsonObj.Saturday = obj.value.Saturday;

				          jsonObj.tradStartOffset = obj.value.editStartOffset;
				          jsonObj.tradEndOffset = obj.value.editEndOffset;

				         $("#eventType").text("TradingHoursEvent");
				         $("#editSkipDays").show();
				         $("#editWeekAndDay").hide();
				         $("#tradingHours").show();
				         $("#editWeekly").hide();
				         $("#editDateRange").hide();
				         $("#editMonthly").hide();
				         $("#editYearly").hide();
				        }
				        else if (obj.value.name=="WeeklyEvent")
				        {
				         $('#weeklyEditWeekDay').val(obj.value.editDay);
  			             jsonObj.wWeekday = obj.value.editDay;
				         $("#eventType").text("WeeklyEvent");
				         $("#editSkipDays").hide();
				         $("#editWeekAndDay").hide();
				         $("#tradingHours").hide();
				         $("#editWeekly").show();
				         $("#editDateRange").hide();
				         $("#editMonthly").hide();
				         $("#editYearly").hide();
				        }
				        
				        else if (obj.value.name=="MonthlyEvent")
				        {
				         $util.getSkipDays(obj.value);
				         $('#monthlyEditDay').val(obj.value.editDay);
  			             jsonObj.mWeekday = obj.value.editDay;
				         $("#eventType").text("MonthlyEvent");
				         $("#editSkipDays").show();
				         $("#editWeekAndDay").hide();
				         $("#tradingHours").hide();
				         $("#editWeekly").hide();
				         $("#editDateRange").hide();
				         $("#editMonthly").show();
				         $("#editYearly").hide();
				        }
				        else if (obj.value.name=="YearlyEvent")
				        {
				         $util.getSkipDays(obj.value);
				         $('#yearlyEditDay').val(obj.value.editDay);
				         $('#yearlyEditMonth').val(obj.value.editMonth);
  			             jsonObj.yWeekday = obj.value.editDay;
  			             jsonObj.yMonth = obj.value.editMonth;
				         $("#eventType").text("YearlyEvent");
				         $("#editSkipDays").show();
				         $("#editWeekAndDay").hide();
				         $("#tradingHours").hide();
				         $("#editWeekly").hide();
				         $("#editDateRange").hide();
				         $("#editMonthly").hide();
				         $("#editYearly").show();
				        }

				        output=[];
				        var op="<p><label><b>Edit Outputs :</b></label></p>";
				        
				        for(var i=0;i<(jsonObj.output.length);i=i+3)
				        {
				           if(jsonObj.output[i+2] == "StatusBoolean")
				           {
				            op = op + "<p><label><b>"+jsonObj.output[i]+" :</b></label>" +
				            "<select style='width:120px' id='"+jsonObj.output[i]+"'>" +
				              "<option value=false>false</option>" +
				              "<option value=true>true</option>" +
				            "</select></p>";
				           }
				           if(jsonObj.output[i+2] == "StatusNumeric")
				           {
				            op = op + "<p><label><b>"+jsonObj.output[i]+" :</b></label>" +
				            "<input type='text' style='width:120px' id="+jsonObj.output[i]+"></p>";
				           }
				        }
				        $("#editOutput").empty();
				        $("#editOutput").append(op);
				        for(var i=0;i<(jsonObj.output.length);i=i+3)
				        {
				           if(jsonObj.output[i+2] == "StatusBoolean")
				           {
				         var id1 = ""+"#"+jsonObj.output[i];
				       $(id1).val(jsonObj.output[i+1]);
				       var val = $(id1).val();
				           }
				           if(jsonObj.output[i+2] == "StatusNumeric")
				           {
				          var id = "#"+jsonObj.output[i];
				          $(id).val(jsonObj.output[i+1]);
				           }
				        output[i] = jsonObj.output[i];
				        output[i+1] = jsonObj.output[i+1];
				        output[i+2] = jsonObj.output[i+2];
				        }
				        
				        if(jsonObj.isVirtual=="true")
				        {
				        	$("#virtualOffset").show();
				        }	
				       }
				     //getExceptionOnDay(scheduleName,jsonO);
				     });
				     
				     return jsonObj;
				},
				getScheduleValues: function(list)
				{
					
					var str = "<p>"+list.description+"</p>";
					var i =0;
			        /*var str1 ="<p><b>Current Output : </b>";
			        
			        for(i = 0;i<list.currOp.length;i=i+2)
			        {
			        	if(i==0)			        	
			        		str1 = str1 + list.currOp[i]+"  : "+list.currOp[i+1]+"</p>";
			        	else			        	
			        		str1 = str1 + "<p>"+list.currOp[i]+"  : "+list.currOp[i+1]+"</p>";
			        	
			        }	
			        var str2 = "<p><b>Next Output : </b>";
			        for(i = 0;i<list.nextOp.length;i=i+2)
			        {
		        		if(i==0)
		        			str2 = str2 + list.nextOp[i]+"  : "+list.nextOp[i+1]+"</p>";
		        		else
		        			str2 = str2 + "<p>"+list.nextOp[i]+"  : "+list.nextOp[i+1]+"</p>";
			        }*/
			        
			        
			        var str3 = "<p><b>Default Output : </b>";
			        for(i = 0;i<list.defaultOp.length;i=i+2)
			        {
		        		if(i==0)
		        			str3 = str3 + list.defaultOp[i]+"  : "+list.defaultOp[i+1]+"</p>";
		        		else
		        			str3 = str3 + "<p>"+list.defaultOp[i]+"  : "+list.defaultOp[i+1]+"</p>";
			        }
			       
			        
			        var str4 = "<p><b>Input Values : </b>";
			        
			        for(i = 0;i<list.input.length;i=i+2)
			        {
		        		if(i==0)
		        			str4 = str4 + list.input[i]+"  : "+list.input[i+1]+"</p>";
		        		else
		        			str4 = str4 + "<p>"+list.input[i]+"  : "+list.input[i+1]+"</p>";
			        }
			        str = str +str3+str4;
			        return str;
				}
				
				
		};
		
		function getExceptionOnDay (scheduleName,obj){
			$jsonObj = obj;
			$.niagara.getExceptionOnDay(scheduleName,$jsonObj.title,$jsonObj.startDay,$jsonObj.startMon,$jsonObj.startYear,function(obj){
				if(obj!=null)
				{
					if(obj.exception == "false")
						return $jsonObj;
					else
					{
						$jsonObj.eventType = "Exception";
						$jsonObj.startH = obj.exception.editStartHour;
						$jsonObj.startM = obj.exception.editStartMinute;
						$jsonObj.startAP = obj.exception.editStartAmPm;
						$jsonObj.endH = obj.exception.editEndHour;
						$jsonObj.endM = obj.exception.editEndMinute;
						$jsonObj.endAP = obj.exception.editEndAmPm; 
						$jsonObj.startMode = obj.exception.startTimeMode; 
						$jsonObj.endMode = obj.exception.editEndTimeMode; 
						
						$("#eventType").text("Exception");
						$("#exceptionName").text(obj.exception.name);
						
				        $("#editEventEditStartMode").val($jsonObj.startMode);
				        $("#editEventEditEndMode").val($jsonObj.endMode);
				        $("#startMin").val($jsonObj.startM);
				        
				        if($jsonObj.startH > 12)
				        {
				         var k = $jsonObj.startH-12;
				         $("#startHour").val(k);
				         $("#startAmPm").val(1);
				        }
				        else if($jsonObj.startH == 12)
				        {
				            $("#startHour").val(12);
				            $("#startAmPm").val(1);
				        }
				        else
				        {
				          if($jsonObj.startH == 0)
				          {   
				           $("#startHour").val(12);
				          }
				          else
				           $("#startHour").val($jsonObj.startH);
				          $("#startAmPm").val(0);
				        }
				        
				        $("#endMin").val($jsonObj.endM);
				        
				        if($jsonObj.endH > 12)
				        {
				         var k = $jsonObj.endH-12;
				         $("#endHour").val(k);
				         $("#endAmPm").val(1);
				        }
				        else if($jsonObj.endH == 12)
				        {
				            $("#endHour").val(12);
				            $("#endAmPm").val(1);
				        }
				        else
				        {
				        if($jsonObj.endH == 0)
				         $("#endHour").val(12);
				        else
				         $("#endHour").val($jsonObj.endH);
				          $("#endAmPm").val(0);
				        }
				        $("#removeExceptionButton").show();
					}	
				}	
			});
		}	

		
		function addNewWeeklySched(events)
		{
			
			$('#calendar').fullCalendar('removeEvents').fullCalendar('removeEventSources').fullCalendar('addEventSource', events);
	        $('#calendar').fullCalendar('refetchEvents');
	        $('#calendar').fullCalendar('renderView');
		}
		
		 function getDayEvents(day,currEvent,nextEvent)
		 {
			 var eventData = [];
			 for(var i = 0; i<day.length;i++)
			 {
				 var event ={
						 title:"event",
						 start:0,
						 end:0,
						 allDay:false,
						 priority:0,
						 type : "Daily",
						 color : "#000000",
						 output:{}
				 };
				 if(day[i].eventName != "")
				{	
					event.title = day[i].eventName;
					event.name = day[i].eventName;
					event.start = day[i].eventStartYear+"-"+day[i].eventStartMonth+"-"+day[i].eventStartDay+" ";
					event.start = event.start+day[i].eventStartHour+":"+day[i].eventStartMin+":"+"00";
					event.end = day[i].eventEndYear+"-"+day[i].eventEndMonth+"-"+day[i].eventEndDay+" ";
					event.end = event.end+day[i].eventEndHour+":"+day[i].eventEndMin+":"+"00";
					//console.log(event.end);
	                event.allDay = false;
	                event.output = day[i].output;
	                event.priority = day[i].eventPriority[0];
	                event.type = day[i].eventType;
	                event.color = day[i].eventColor;
	                event.isException = day[i].isException;
	                event.isVirtual = day[i].isVirtual;
	                event.actualExceptionName = day[i].actualExceptionName;
	                
	                if(currEvent.currEventStartYear == day[i].eventStartYear && 
	                		currEvent.currEventStartMonth == day[i].eventStartMonth &&
	                		currEvent.currEventStartDay == day[i].eventStartDay && 
	                		currEvent.currentActiveEvent == day[i].eventName)
						{
							event.active = "ACTIVE";
							event.title = event.title+ " ACTIVE!!";
						}		
						else if (nextEvent.nextEventStartYear == day[i].eventStartYear && 
								nextEvent.nextEventStartMonth == day[i].eventStartMonth &&
								nextEvent.nextEventStartDay == day[i].eventStartDay && 
								nextEvent.nextActiveEvent == day[i].eventName)
						{	
									event.active = "next event";
									event.title = event.title+ " Next Event !!";
						}			
	                else
	                	{
	                	event.active = "";
	                	}
	                
					eventData.push(event);
				}
			 }
			 
			 return eventData;
		 }
		
		
})(jQuery);