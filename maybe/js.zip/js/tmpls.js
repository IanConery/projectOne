this["TMPLS"] = this["TMPLS"] || {};

this["TMPLS"]["EquipTable"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return " \r\n    <thead>\r\n        <tr>\r\n            <th class=\"one\">Status</th>\r\n            <th class=\"one\">Name</th>\r\n            <th class=\"two\">Description</th>\r\n            <th class=\"three\">Active Control Setpt</th>\r\n            <th class=\"four\">Active Temp</th>\r\n            <th class=\"one\">Occupancy</th>\r\n            <th class=\"four\">Supply Air Temp</th>\r\n            <th class=\"four\">Return Air Temp</th>\r\n             <th class=\"one\">Fan Status</th>\r\n              <th class=\"one\">Mode</th>\r\n        </tr>    \r\n    </thead>\r\n    <tbody>\r\n    \r\n    </tbody>\r\n\r\n";
  });

this["TMPLS"]["OverridePopup"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, stack2, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n\r\n  <p class=\"radioP\" id=\""
    + escapeExpression(((stack1 = (depth0 && depth0.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">\r\n   <input type=\"radio\" class=\""
    + escapeExpression(((stack1 = (depth0 && depth0.parameterType)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" name=\"overrideVal\" value=\""
    + escapeExpression(((stack1 = (depth0 && depth0.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" />\r\n   <label for=\"r1\">\r\n   <span class=\"radioButtonGraph\"></span>\r\n   "
    + escapeExpression(((stack1 = (depth0 && depth0.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n   </label>\r\n  </p>\r\n ";
  return buffer;
  }

  buffer += "<div class=\"actionModal\">\r\n <div class=\"checkboxingNow\"></div>\r\n <div class=\"closeIcon\"></div>\r\n <h3>";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</h3>\r\n   ";
  stack2 = helpers.each.call(depth0, ((stack1 = (depth0 && depth0.action)),stack1 == null || stack1 === false ? stack1 : stack1.action), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n</div>";
  return buffer;
  });

this["TMPLS"]["RowItemView"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, stack2, options, self=this, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                  ";
  stack1 = self.invokePartial(partials.progressLoader, 'progressLoader', (depth0 && depth0.loaderClass), helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n                   ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, stack2, options;
  buffer += "\r\n               \r\n                    ";
  options = {hash:{},inverse:self.program(6, program6, data),fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.status)),stack1 == null || stack1 === false ? stack1 : stack1.value), "ok", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.status)),stack1 == null || stack1 === false ? stack1 : stack1.value), "ok", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                    <td class=\"one\" id=";
  if (stack2 = helpers.nodeId) { stack2 = stack2.call(depth0, {hash:{},data:data}); }
  else { stack2 = (depth0 && depth0.nodeId); stack2 = typeof stack2 === functionType ? stack2.call(depth0, {hash:{},data:data}) : stack2; }
  buffer += escapeExpression(stack2)
    + ">";
  if (stack2 = helpers.name) { stack2 = stack2.call(depth0, {hash:{},data:data}); }
  else { stack2 = (depth0 && depth0.name); stack2 = typeof stack2 === functionType ? stack2.call(depth0, {hash:{},data:data}) : stack2; }
  buffer += escapeExpression(stack2)
    + "</td>\r\n                    <td class=\"two\" title=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.description)),stack1 == null || stack1 === false ? stack1 : stack1.full)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.description)),stack1 == null || stack1 === false ? stack1 : stack1.half)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</td>\r\n                    ";
  options = {hash:{},inverse:self.program(13, program13, data),fn:self.program(11, program11, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.zoneTemp)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.zoneTemp)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                    ";
  options = {hash:{},inverse:self.program(17, program17, data),fn:self.program(15, program15, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.zoneSp)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.zoneSp)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                    ";
  options = {hash:{},inverse:self.program(21, program21, data),fn:self.program(19, program19, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.OCCU_COMMAND)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.OCCU_COMMAND)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                    ";
  options = {hash:{},inverse:self.program(28, program28, data),fn:self.program(26, program26, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.dischargeAirTempNum)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.dischargeAirTempNum)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                     ";
  options = {hash:{},inverse:self.program(32, program32, data),fn:self.program(30, program30, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.returnAirtemp)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.returnAirtemp)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                     \r\n                     ";
  options = {hash:{},inverse:self.program(36, program36, data),fn:self.program(34, program34, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.dischargeFanStatusBool)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.dischargeFanStatusBool)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                     ";
  options = {hash:{},inverse:self.program(43, program43, data),fn:self.program(41, program41, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.coolingModeBool)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.coolingModeBool)),stack1 == null || stack1 === false ? stack1 : stack1.error), "true", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n           ";
  return buffer;
  }
function program4(depth0,data) {
  
  
  return "\r\n                    <td></td>\r\n                    ";
  }

function program6(depth0,data) {
  
  var buffer = "", stack1, stack2, options;
  buffer += "\r\n                         ";
  options = {hash:{},inverse:self.program(9, program9, data),fn:self.program(7, program7, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.status)),stack1 == null || stack1 === false ? stack1 : stack1.value), "Data not available: /data/GGP/Equipment/string/StatusString", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.status)),stack1 == null || stack1 === false ? stack1 : stack1.value), "Data not available: /data/GGP/Equipment/string/StatusString", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                    \r\n                    ";
  return buffer;
  }
function program7(depth0,data) {
  
  
  return "\r\n                              <td></td>\r\n                          ";
  }

function program9(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                             <td><i id=\"equipData-MRTU01-1StatusString\" class=\"icon icon-dot status-"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.status)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" title="
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.status)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "></i></td>\r\n                        ";
  return buffer;
  }

function program11(depth0,data) {
  
  
  return "\r\n                    <td class=\"three\"><i title=\" Data not available: /data/Haystack/hvac/temp/air/numeric/activeZoneControlSpNum \" class=\"icon icon-warning\"></i></td>\r\n                    ";
  }

function program13(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                    <td class=\"three\" id=\"equipData-";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "-1slot--DataTree-data-Haystack-hvac-temp-air-numeric-activeZoneControlSpNum\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.zoneTemp)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.zoneTemp)),stack1 == null || stack1 === false ? stack1 : stack1.units)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</td>\r\n                    ";
  return buffer;
  }

function program15(depth0,data) {
  
  
  return "\r\n                    <td class=\"four\"><i title=\" Data not available: /data/Haystack/hvac/temp/air/numeric/activeZoneControlSpNum \" class=\"icon icon-warning\"></i></td>\r\n                    ";
  }

function program17(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                    <td class=\"four\" id=\"equipData-";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "-1slot--DataTree-data-Haystack-hvac-temp-air-numeric-activeZoneControlTempNum\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.zoneSp)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.zoneSp)),stack1 == null || stack1 === false ? stack1 : stack1.units)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</td>\r\n                    ";
  return buffer;
  }

function program19(depth0,data) {
  
  
  return "\r\n                    <td class=\"four\"><i title=\" Data not available: /data/Haystack/occupancy/boolean/occupancyCommandBool \" class=\"icon icon-warning\"></i></td>\r\n                    ";
  }

function program21(depth0,data) {
  
  var buffer = "", stack1, stack2, options;
  buffer += "\r\n                    <td class=\"four\" id=\"equipData-";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "-1slot--DataTree-data-Haystack-occupancyCommandBool\">";
  options = {hash:{},inverse:self.program(24, program24, data),fn:self.program(22, program22, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.OCCU_COMMAND)),stack1 == null || stack1 === false ? stack1 : stack1.value), "true", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.OCCU_COMMAND)),stack1 == null || stack1 === false ? stack1 : stack1.value), "true", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "</td>\r\n                    ";
  return buffer;
  }
function program22(depth0,data) {
  
  var stack1;
  return escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.OCCU_COMMAND)),stack1 == null || stack1 === false ? stack1 : stack1.dataDefinition)),stack1 == null || stack1 === false ? stack1 : stack1.trueText)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1));
  }

function program24(depth0,data) {
  
  var stack1;
  return escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.OCCU_COMMAND)),stack1 == null || stack1 === false ? stack1 : stack1.dataDefinition)),stack1 == null || stack1 === false ? stack1 : stack1.falseText)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1));
  }

function program26(depth0,data) {
  
  
  return "\r\n                    <td class=\"four\"><i title=\" Data not available: data/Haystack/hvac/temp/air/numeric/dischargeAirTempNum \" class=\"icon icon-warning\"></i></td>\r\n                    ";
  }

function program28(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                    <td class=\"four\" id=\"equipData-";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "-1slot--DataTree-data-Haystack-hvac-temp-air-numeric-dischargeAirTempNum\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.dischargeAirTempNum)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</td>\r\n                    ";
  return buffer;
  }

function program30(depth0,data) {
  
  
  return "\r\n                         <td class=\"four\"><i title=\" Data not available: slot:/DataTree/data/Haystack/hvac/temp/air/numeric/returnAirTempNum \" class=\"icon icon-warning\"></i></td>\r\n                     ";
  }

function program32(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                         <td class=\"four\" id=\"equipData-";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "-1slot--DataTree--data-Haystack-hvac-temp-air-numeric-returnAirTempNum\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.returnAirtemp)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</td>\r\n                      ";
  return buffer;
  }

function program34(depth0,data) {
  
  
  return "\r\n                    <td class=\"four\"><i title=\" Data not available:data/Haystack/hvac/fan/boolean/dischargeFanStatusBool \" class=\"icon icon-warning\"></i></td>\r\n                    ";
  }

function program36(depth0,data) {
  
  var buffer = "", stack1, stack2, options;
  buffer += "\r\n                    <td class=\"four\" id=\"equipData-";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "-1slot--DataTree-data-Haystack-hvac-fan-air-boolean-dischargeFanStatusBool\"> ";
  options = {hash:{},inverse:self.program(39, program39, data),fn:self.program(37, program37, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = (depth0 && depth0.dischargeFanStatusBool)),stack1 == null || stack1 === false ? stack1 : stack1.value), "true", options) : helperMissing.call(depth0, "equal", ((stack1 = (depth0 && depth0.dischargeFanStatusBool)),stack1 == null || stack1 === false ? stack1 : stack1.value), "true", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "</td>\r\n                    ";
  return buffer;
  }
function program37(depth0,data) {
  
  var stack1;
  return escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.dischargeFanStatusBool)),stack1 == null || stack1 === false ? stack1 : stack1.dataDefinition)),stack1 == null || stack1 === false ? stack1 : stack1.trueText)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1));
  }

function program39(depth0,data) {
  
  var stack1;
  return escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.dischargeFanStatusBool)),stack1 == null || stack1 === false ? stack1 : stack1.dataDefinition)),stack1 == null || stack1 === false ? stack1 : stack1.falseText)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1));
  }

function program41(depth0,data) {
  
  
  return "\r\n                    <td class=\"four\"><i title=\" Data not available:data/Haystack/hvac/hvacMode/boolean/coolingModeBool \" class=\"icon icon-warning\"></i></td>\r\n                    ";
  }

function program43(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                    <td class=\"four\" id=\"equipData-";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "-1slot--DataTree-data-Haystack-hvac-hvacMode-boolean-coolingModeBool\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.coolingModeBool)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</td>\r\n                    ";
  return buffer;
  }

  buffer += "           ";
  options = {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, (depth0 && depth0.init), "yes", options) : helperMissing.call(depth0, "equal", (depth0 && depth0.init), "yes", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n         \r\n\r\n\r\n\r\n\r\n\r\n";
  return buffer;
  });

this["TMPLS"]["progressLoader"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div id=\"loader\" class="
    + escapeExpression(((stack1 = (depth0 && depth0.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + ">\r\n<div id=\"floatingCirclesG\">\r\n<div class=\"f_circleG\" id=\"frotateG_01\">\r\n</div>\r\n<div class=\"f_circleG\" id=\"frotateG_02\">\r\n</div>\r\n<div class=\"f_circleG\" id=\"frotateG_03\">\r\n</div>\r\n<div class=\"f_circleG\" id=\"frotateG_04\">\r\n</div>\r\n<div class=\"f_circleG\" id=\"frotateG_05\">\r\n</div>\r\n<div class=\"f_circleG\" id=\"frotateG_06\">\r\n</div>\r\n<div class=\"f_circleG\" id=\"frotateG_07\">\r\n</div>\r\n<div class=\"f_circleG\" id=\"frotateG_08\">\r\n</div>\r\n</div> \r\n</div>";
  return buffer;
  });

this["TMPLS"]["tabList"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<a data-bypass data-tab=\"";
  if (stack1 = helpers.tabName) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.tabName); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" class=\"";
  if (stack1 = helpers.tabClass) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.tabClass); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" id=\"";
  if (stack1 = helpers.route) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.route); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "-tab\">";
  if (stack1 = helpers.sectionName) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.sectionName); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</a>";
  return buffer;
  });

this["TMPLS"]["tabTemplate"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"column span5 frameheight\">\r\n       <div id=\"tabs\" class=\"clearfix subMenu3\" ></div>\r\n     \r\n       <table id=\"MallUnits\" class=\"WsubMenu3 active hvac-equip\">\r\n       </table>\r\n       <table id=\"TenantUnits\" class=\"WsubMenu3  hvac-equip\">\r\n       </table>\r\n       <table id=\"MisUnits\" class=\"WsubMenu3  hvac-equip\">\r\n       </table>\r\n  \r\n   \r\n</div>    \r\n\r\n";
  });

this["TMPLS"]["unitDescription"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, stack2, options, self=this, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                  ";
  stack1 = self.invokePartial(partials.progressLoader, 'progressLoader', (depth0 && depth0.loaderClass), helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n                   ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, stack2, options;
  buffer += "\r\n                        \r\n                        <div class=\"topData\">\r\n                            <p id=\"circuitNameData\">";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</p>\r\n                             <div class=\"leftLabels editable\" id=\"hvacEditableDescription\">\r\n                                <label>Description: </label>\r\n                                <div class=\"block relative\" id=\"relMobile\">\r\n                                  <p id=\"displayNameData\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.description)),stack1 == null || stack1 === false ? stack1 : stack1.full)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</p>\r\n                                  <span class=\"edit startEdit\"></span>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"HVACEqupButtons\">\r\n                                <a data-bypass  target=\"_blank\" href=\"http://eoa.ggp.com/dglux5/viewer.html?proj=GGP&path=MainEquipmentGraphic.dg5#";
  if (stack2 = helpers.nodeId) { stack2 = stack2.call(depth0, {hash:{},data:data}); }
  else { stack2 = (depth0 && depth0.nodeId); stack2 = typeof stack2 === functionType ? stack2.call(depth0, {hash:{},data:data}) : stack2; }
  buffer += escapeExpression(stack2)
    + "\"  class=\"btn-primary fr smallMarginLeft graphicHVACView\">Graphic</a>\r\n                            </div>\r\n                        </div>\r\n                        \r\n                        <div class=\"share2 first\">\r\n                            <div class=\"leftLabels editable\">\r\n                            </div>\r\n                            <div class=\"leftLabels\">\r\n                                <label>Schedule:</label>\r\n                                <select class=\"schedulingHvacData\" id=\"schedulingHvacData\">\r\n                                    <option value=\"MallHours\" id=\"schedulingOpt\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "MallHours", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "MallHours", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">MallHours</option>\r\n                                    <option value=\"SunsetToSunrise\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "SunsetToSunrise", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "SunsetToSunrise", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">SunsetToSunrise</option>\r\n                                    <option value=\"HourToSunrise\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "HourToSunrise", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "HourToSunrise", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">HourToSunrise</option>\r\n                                    <option value=\"SunsetToHour\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "SunsetToHour", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "SunsetToHour", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">SunsetToHour</option>\r\n                                    <option value=\"TheaterHours\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "TheaterHours", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "TheaterHours", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">TheaterHours</option>\r\n                                    <option value=\"TwentyFourHours\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "TwentyFourHours", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "TwentyFourHours", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">TwentyFourHours</option>\r\n                                    <option value=\"ExtendedHours\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "ExtendedHours", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "ExtendedHours", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">ExtendedHours</option>\r\n                                    <option value=\"ManagementHours\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "ManagementHours", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "ManagementHours", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">ManagementHours</option>\r\n                                    <option value=\"Unscheduled\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "Unscheduled", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.schedule)),stack1 == null || stack1 === false ? stack1 : stack1.value), "Unscheduled", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">Unscheduled</option>\r\n                                </select>\r\n                            </div>\r\n                            <div class=\"leftLabels\">\r\n                              <label>Special Event:</label>\r\n                              <select id=\"HVACspecialEventData\">\r\n                                <option value=\"SpecialEventHours1\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.specialEvent)),stack1 == null || stack1 === false ? stack1 : stack1.value), "SpecialEventHours1", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.specialEvent)),stack1 == null || stack1 === false ? stack1 : stack1.value), "SpecialEventHours1", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">SpecialEventHours1</option>\r\n                                <option value=\"SpecialEventHours2\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.specialEvent)),stack1 == null || stack1 === false ? stack1 : stack1.value), "SpecialEventHours2", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.specialEvent)),stack1 == null || stack1 === false ? stack1 : stack1.value), "SpecialEventHours2", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">SpecialEventHours2</option>\r\n                                <option value=\"None\" ";
  options = {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.specialEvent)),stack1 == null || stack1 === false ? stack1 : stack1.value), "None", options) : helperMissing.call(depth0, "equal", ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.specialEvent)),stack1 == null || stack1 === false ? stack1 : stack1.value), "None", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += ">None</option>\r\n                              </select>\r\n                            </div>\r\n                            <div class=\"leftLabels\">\r\n                              <label>Effective Start:</label>\r\n                              <p class=\"HVACEffectiveData\" id=\"effectiveStartData\">"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.effectiveStartHvac)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</p>\r\n                            </div>\r\n\r\n                        </div>\r\n                        <div class=\"share2 second\">\r\n                            <div class=\"leftLabels\">\r\n                                <label>Priority Stage:</label>\r\n                                <select id=\"StageHvacData\">\r\n                                    <option value=\"Stage1\" selected>Stage1</option>\r\n                                    <option value=\"Stage2\" >Stage2</option>\r\n                                    <option value=\"Stage3\" >Stage3</option>\r\n                                </select>\r\n                            </div>\r\n                            <div class=\"leftLabels\">\r\n                                <label>Demand Management:</label>\r\n                                <select id=\"DemandHvacData\">\r\n                                    <option value=\"None\" selected>None</option>\r\n                                    <option value=\"Set Point\">Set Point</option>\r\n                                    <option value=\"Disable Cooling\" >Disable Cooling</option>\r\n                                    <option value=\"Turn Off\">Turn Off</option>\r\n                                    <option value=\"All\" >All</option>\r\n                                </select>\r\n                            </div>\r\n                            <div class=\"leftLabels\">\r\n                              <label>Effective End:</label>\r\n                              <p  class=\"HVACEffectiveData\" id=\"effectiveEndData\">"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.top)),stack1 == null || stack1 === false ? stack1 : stack1.effectiveEndHvac)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</p>\r\n                            </div>\r\n                        </div> \r\n                        \r\n\r\n                       <div id=\"colleft\" style=\"clear:both;\">\r\n                       <ul id=\"HvacCtlPts\">\r\n                        ";
  stack2 = helpers.each.call(depth0, (depth0 && depth0.left), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "  \r\n                            </ul>\r\n                        </div>\r\n\r\n                         <div id=\"colright\" >\r\n                       <ul id=\"HvacCtlPts\">\r\n                        ";
  stack2 = helpers.each.call(depth0, (depth0 && depth0.right), {hash:{},inverse:self.noop,fn:self.program(16, program16, data),data:data});
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "  \r\n                            </ul>\r\n                        </div>\r\n\r\n\r\n                       ";
  return buffer;
  }
function program4(depth0,data) {
  
  
  return "selected";
  }

function program6(depth0,data) {
  
  var buffer = "", stack1, stack2, options;
  buffer += "\r\n                            <li>\r\n                            <div class=\"leftLabels\">\r\n\r\n                             <label>"
    + escapeExpression(((stack1 = (depth0 && depth0.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</label>\r\n                                <p>";
  options = {hash:{},inverse:self.program(9, program9, data),fn:self.program(7, program7, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, (depth0 && depth0.status), "none", options) : helperMissing.call(depth0, "equal", (depth0 && depth0.status), "none", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += escapeExpression(((stack1 = (depth0 && depth0.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</p>\r\n                                ";
  options = {hash:{},inverse:self.program(14, program14, data),fn:self.program(12, program12, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, (depth0 && depth0.action), "false", options) : helperMissing.call(depth0, "equal", (depth0 && depth0.action), "false", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                             </div>  \r\n                             </li> \r\n                            ";
  return buffer;
  }
function program7(depth0,data) {
  
  var buffer = "";
  return buffer;
  }

function program9(depth0,data) {
  
  var stack1, stack2, options;
  options = {hash:{},inverse:self.program(10, program10, data),fn:self.program(7, program7, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, (depth0 && depth0.status), "null", options) : helperMissing.call(depth0, "equal", (depth0 && depth0.status), "null", options));
  if(stack2 || stack2 === 0) { return stack2; }
  else { return ''; }
  }
function program10(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<i style=\"padding-right: 10px;\" class=\"icon icon-dot status-"
    + escapeExpression(((stack1 = (depth0 && depth0.status)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" title=\""
    + escapeExpression(((stack1 = (depth0 && depth0.status)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"></i>";
  return buffer;
  }

function program12(depth0,data) {
  
  
  return "\r\n                                <span class=\"overrideFalse\"></span>\r\n                                    ";
  }

function program14(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                                    <span class=\"overrideIcon\" id=\""
    + escapeExpression(((stack1 = (depth0 && depth0.nodeId)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" name=\""
    + escapeExpression(((stack1 = (depth0 && depth0.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" data-type=\"left\"></span>\r\n                                ";
  return buffer;
  }

function program16(depth0,data) {
  
  var buffer = "", stack1, stack2, options;
  buffer += "\r\n                            <li>\r\n                            <div class=\"leftLabels\">\r\n\r\n                             <label>"
    + escapeExpression(((stack1 = (depth0 && depth0.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</label>\r\n                                <p>";
  options = {hash:{},inverse:self.program(9, program9, data),fn:self.program(7, program7, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, (depth0 && depth0.status), "none", options) : helperMissing.call(depth0, "equal", (depth0 && depth0.status), "none", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += escapeExpression(((stack1 = (depth0 && depth0.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</p>\r\n                                ";
  options = {hash:{},inverse:self.program(17, program17, data),fn:self.program(12, program12, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, (depth0 && depth0.action), "false", options) : helperMissing.call(depth0, "equal", (depth0 && depth0.action), "false", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                             </div>  \r\n                             </li> \r\n                            ";
  return buffer;
  }
function program17(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                                    <span class=\"overrideIcon\" id=\""
    + escapeExpression(((stack1 = (depth0 && depth0.nodeId)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" name=\""
    + escapeExpression(((stack1 = (depth0 && depth0.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" data-type=\"right\"></span>\r\n                                ";
  return buffer;
  }

  buffer += "<td colspan=\"10\" style=\"border-right: 5px solid #e88552; border-left: 5px solid #e88552;border-bottom: 2px solid #c0c0c0;\">\r\n<div id=\"bodyHVAC\">\r\n<div class=\"clearfix keepSeen\" id=\"lightingData\">\r\n";
  options = {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data};
  stack2 = ((stack1 = helpers.equal || (depth0 && depth0.equal)),stack1 ? stack1.call(depth0, (depth0 && depth0.init), "yes", options) : helperMissing.call(depth0, "equal", (depth0 && depth0.init), "yes", options));
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n                    </div>\r\n             </div>       \r\n</td>                    ";
  return buffer;
  });

this["TMPLS"]["dateChooser"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class='date-pick-container'>\r\n    <label>Select Date </label>\r\n    <input type='date' id='";
  if (stack1 = helpers.id) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.id); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "' />\r\n    <button class='btn' type='submit' name='go'>Go!</button>\r\n    <button class='btn' type='submit' name='reset'>Reset</button>\r\n</div>\r\n";
  return buffer;
  });

this["TMPLS"]["equipmentDetails"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <div class=\"leftLabels\">\r\n        <label>";
  if (stack1 = helpers.displayName) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.displayName); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</label>\r\n        <p id=\"";
  if (stack1 = helpers.id) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.id); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"><img src=\"img/loading-16.gif\" /></p>\r\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.actions), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </div>\r\n";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n            <span class=\"overrideIcon\" id=\"";
  if (stack1 = helpers.equipNodeId) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.equipNodeId); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" value=\"";
  if (stack1 = helpers.displayName) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.displayName); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "?";
  if (stack1 = helpers.data) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.data); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"></span>\r\n        ";
  return buffer;
  }

  stack1 = helpers.each.call(depth0, (depth0 && depth0.items), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n";
  return buffer;
  });

this["TMPLS"]["equipmentListRows"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <tr data-node-id=\"";
  if (stack1 = helpers.SlotPath) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.SlotPath); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"\r\n        data-name=\"";
  if (stack1 = helpers.Name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n        <td><i id=\"";
  if (stack1 = helpers.statusUid) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.statusUid); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" /></td>\r\n        <td class='one' id='";
  if (stack1 = helpers.SlotPath) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.SlotPath); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'>";
  if (stack1 = helpers.Name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n        <td class='two'>";
  if (stack1 = helpers.Description) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Description); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n        <td class='three' id=\"";
  if (stack1 = helpers.spUid) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.spUid); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"><img src='img/loading-16.gif' /></td>\r\n        <td class='four' id=\"";
  if (stack1 = helpers.tempUid) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.tempUid); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"><img src='img/loading-16.gif' /></td>\r\n    </tr>\r\n";
  return buffer;
  }

  buffer += "<tbody>\r\n";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n</tbody>";
  return buffer;
  });

this["TMPLS"]["genericProphetReq"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, stack2;
  buffer += "\r\n    <Method name='"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attrs)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "' uid='"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.attrs)),stack1 == null || stack1 === false ? stack1 : stack1.uid)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "'>\r\n      ";
  stack2 = helpers.each.call(depth0, (depth0 && depth0.children), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n    </Method>\r\n  ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n     \r\n        ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        \r\n      ";
  return buffer;
  }
function program3(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n          ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.attrs), {hash:{},inverse:self.program(7, program7, data),fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        ";
  return buffer;
  }
function program4(depth0,data) {
  
  var buffer = "", stack1, stack2;
  buffer += "\r\n            <"
    + escapeExpression(((stack1 = ((stack1 = data),stack1 == null || stack1 === false ? stack1 : stack1.key)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n              ";
  stack2 = helpers.each.call(depth0, (depth0 && depth0.attrs), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\r\n            >\r\n            ";
  if (stack2 = helpers.content) { stack2 = stack2.call(depth0, {hash:{},data:data}); }
  else { stack2 = (depth0 && depth0.content); stack2 = typeof stack2 === functionType ? stack2.call(depth0, {hash:{},data:data}) : stack2; }
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += " \r\n            </"
    + escapeExpression(((stack1 = ((stack1 = data),stack1 == null || stack1 === false ? stack1 : stack1.key)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + ">\r\n          ";
  return buffer;
  }
function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                "
    + escapeExpression(((stack1 = ((stack1 = data),stack1 == null || stack1 === false ? stack1 : stack1.key)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "=\""
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "\"\r\n              ";
  return buffer;
  }

function program7(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n            <"
    + escapeExpression(((stack1 = ((stack1 = data),stack1 == null || stack1 === false ? stack1 : stack1.key)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + ">"
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "</"
    + escapeExpression(((stack1 = ((stack1 = data),stack1 == null || stack1 === false ? stack1 : stack1.key)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + ">\r\n          ";
  return buffer;
  }

  buffer += "<ProphetRequest version='1'>\r\n\r\n  ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  \r\n</ProphetRequest>\r\n\r\n\r\n";
  return buffer;
  });

this["TMPLS"]["genericProphetReq2"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, self=this, functionType="function", escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <Method name='";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "' uid='";
  if (stack1 = helpers.uid) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.uid); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'>\r\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.criteria), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </Method>\r\n  ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n            ";
  stack1 = self.invokePartial(partials.prophetMethodCriteria, 'prophetMethodCriteria', (depth0 && depth0.criteria), helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        ";
  return buffer;
  }

  buffer += "<ProphetRequest version='1' compress=\"";
  if (stack1 = helpers['x']) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0['x']); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" async=\"";
  if (stack1 = helpers['x']) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0['x']); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" showAsyncProgress=\"";
  if (stack1 = helpers['x']) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0['x']); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" timeZone=\"";
  if (stack1 = helpers['x']) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0['x']); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n  ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n</ProphetRequest>\r\n";
  return buffer;
  });

this["TMPLS"]["getChildValues"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "";
  buffer += "\r\n      <getValue data=\""
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "\" />\r\n    ";
  return buffer;
  }

  buffer += "<Method name='getChildValues' uid='";
  if (stack1 = helpers.uid) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.uid); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'>\r\n  <nodes parent=\"";
  if (stack1 = helpers.parent) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.parent); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"></nodes>\r\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.data), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n</Method>";
  return buffer;
  });

this["TMPLS"]["getDataDefinition"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n        <Method name='getDataDefinition' uid='";
  if (stack1 = helpers.uid) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.uid); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'>\r\n            <nodeId>";
  if (stack1 = helpers.nodeId) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.nodeId); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</nodeId>\r\n            <data>";
  if (stack1 = helpers.data) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.data); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</data>\r\n        </Method>\r\n    ";
  return buffer;
  }

  buffer += "<ProphetRequest version='1'>\r\n    ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n</ProphetRequest>\r\n";
  return buffer;
  });

this["TMPLS"]["getTrend"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <Method name=\"getTrend\" uid=\"";
  if (stack1 = helpers.uid) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.uid); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n        <nodeId>";
  if (stack1 = helpers.nodeId) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.nodeId); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</nodeId>\r\n        <data>";
  if (stack1 = helpers.data) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.data); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</data>\r\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.tags), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.timeRange), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.timeFilter), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.aggregation), {hash:{},inverse:self.noop,fn:self.program(8, program8, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.interval), {hash:{},inverse:self.noop,fn:self.program(10, program10, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.rollup), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.autoDelta), {hash:{},inverse:self.noop,fn:self.program(14, program14, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </Method>\r\n    ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<tags>";
  if (stack1 = helpers.tags) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.tags); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</tags>";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<timeRange>";
  if (stack1 = helpers.timeRange) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.timeRange); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</timeRange>";
  return buffer;
  }

function program6(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<timeFilter>";
  if (stack1 = helpers.timeFilter) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.timeFilter); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</timeFilter>";
  return buffer;
  }

function program8(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<aggregation>";
  if (stack1 = helpers.aggregation) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.aggregation); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</aggregation>";
  return buffer;
  }

function program10(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<interval>";
  if (stack1 = helpers.interval) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.interval); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</interval>";
  return buffer;
  }

function program12(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<rollup>";
  if (stack1 = helpers.rollup) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.rollup); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</rollup>";
  return buffer;
  }

function program14(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<autoDelta>";
  if (stack1 = helpers.autoDelta) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.autoDelta); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</autoDelta>";
  return buffer;
  }

  buffer += "<ProphetRequest version=\"1\">\r\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.trendRequests), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n</ProphetRequest>";
  return buffer;
  });

this["TMPLS"]["groups"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n  <div class=\"column ";
  if (stack1 = helpers.classes) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.classes); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.groups), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  </div>\r\n";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      <div class=\"group ";
  if (stack1 = helpers.classes) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.classes); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n        <h2>";
  if (stack1 = helpers.title) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.title); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</h2>\r\n        <ul>\r\n          ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.dataPairs), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        </ul>\r\n      </div>\r\n    ";
  return buffer;
  }
function program3(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n            <li><p class=\"parameter\">";
  if (stack1 = helpers.param) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.param); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</p><p class=\"data\" id=\"";
  if (stack1 = helpers.id) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.id); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"></p></li>\r\n          ";
  return buffer;
  }

  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { return stack1; }
  else { return ''; }
  });

this["TMPLS"]["header"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n        <li class=\"";
  if (stack1 = helpers.klass) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.klass); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"><a id=\"";
  if (stack1 = helpers.id) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.id); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" class=\"";
  if (stack1 = helpers.aKlass) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.aKlass); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" href=\"";
  if (stack1 = helpers.link) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.link); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"></a></li>\r\n      ";
  return buffer;
  }

  buffer += "<header class=\"clearfix\">\r\n  <img id=\"logo\" src=\"img/logo.png\" alt=\"GGP Logo\">\r\n  <p class=\"divider\">//</p>\r\n    <div id=\"mallChoice\" class=\"mall-chooser\">\r\n        <select>\r\n            <option>Loading malls...</option>\r\n        </select>\r\n    </div>\r\n  <a id=\"menuButton\">\r\n      <hr><hr><hr>\r\n  </a>\r\n</header>\r\n<section id=\"menu\" class=\"clearfix\">\r\n    <ul class=\"clearfix\">\r\n      ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </ul>\r\n</section>\r\n";
  return buffer;
  });

this["TMPLS"]["mallSelectChosen"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, self=this, functionType="function", escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <option\r\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.selected), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        value=\"";
  if (stack1 = helpers.nodeId) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.nodeId); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"\r\n        data-node-id=\"";
  if (stack1 = helpers.nodeId) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.nodeId); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"\r\n        data-site=\"";
  if (stack1 = helpers.site) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.site); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"\r\n        data-name=\"";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n        ";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\r\n    </option>\r\n";
  return buffer;
  }
function program2(depth0,data) {
  
  
  return "selected";
  }

function program4(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <optgroup label=\"";
  if (stack1 = helpers.group) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.group); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.options), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </optgroup>\r\n";
  return buffer;
  }
function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n        <option\r\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.selected), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n            value=\"";
  if (stack1 = helpers.nodeId) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.nodeId); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"\r\n            data-node-id=\"";
  if (stack1 = helpers.nodeId) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.nodeId); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"\r\n            data-site=\"";
  if (stack1 = helpers.site) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.site); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"\r\n            data-name=\"";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n            ";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\r\n        </option>\r\n    ";
  return buffer;
  }

  buffer += "<select class=\"mall-select\">\r\n\r\n";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.teamOptionList), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n\r\n";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.mallOptionList), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n</select>";
  return buffer;
  });

this["TMPLS"]["navBar"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n\r\n    <li><a href=\"";
  if (stack1 = helpers.href) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.href); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + ".html\" class=\"icon-";
  if (stack1 = helpers.icon) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.icon); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + " ";
  if (stack1 = helpers.klass) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.klass); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" title=\"";
  if (stack1 = helpers.title) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.title); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (stack1 = helpers.title) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.title); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</a></li>\r\n\r\n  ";
  return buffer;
  }

  buffer += "<ul class=\"clearfix\">\r\n\r\n  ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n\r\n</ul>";
  return buffer;
  });

this["TMPLS"]["pollSubscription"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<ProphetRequest version=\"1\">\r\n  <Method name=\"pollSubscription\" uid=\"";
  if (stack1 = helpers.uid) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.uid); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" />\r\n</ProphetRequest>";
  return buffer;
  });

this["TMPLS"]["tmpls/property-menu.hbs"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "\r\n<ul>\r\n</ul>";
  });

this["TMPLS"]["prophetMethodCriteria"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); partials = this.merge(partials, Handlebars.partials); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\r\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.attrs), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    >\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.criteria), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.value), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + ">\r\n";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n            ";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "=\"";
  if (stack1 = helpers.value) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.value); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"\r\n        ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n        ";
  stack1 = self.invokePartial(partials.prophetMethodCriteria, 'prophetMethodCriteria', (depth0 && depth0.criteria), helpers, partials, data);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    ";
  return buffer;
  }

function program6(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n        ";
  if (stack1 = helpers.value) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.value); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\r\n    ";
  return buffer;
  }

  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n";
  return buffer;
  });

this["TMPLS"]["scheduleSummary"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <tr>\r\n      <td>";
  if (stack1 = helpers.Name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td>";
  if (stack1 = helpers.Description) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Description); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td>\r\n        <select>\r\n            <option>";
  if (stack1 = helpers.Zone) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Zone); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</option>\r\n            ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.options), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        </select>\r\n      </td>\r\n      <td>";
  if (stack1 = helpers.Group) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Group); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td>";
  if (stack1 = helpers.Schedule) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Schedule); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td>";
  if (stack1 = helpers.DischargeTemp) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.DischargeTemp); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td>";
  if (stack1 = helpers.AirTemp) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.AirTemp); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td>";
  if (stack1 = helpers.Output) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Output); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n    </tr>\r\n  ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "";
  buffer += "\r\n              <option>"
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "</option>\r\n            ";
  return buffer;
  }

  buffer += "<thead>\r\n  <tr>\r\n      <th>Name</th>\r\n      <th>Description</th>\r\n      <th>Zone</th>\r\n      <th>Group</th>\r\n      <th>Schedule</th>\r\n      <th>Discharge Temp.</th>\r\n      <th>Air Temp.</th>\r\n      <th>Output</th>\r\n  </tr>\r\n</thead>\r\n  ";
  stack1 = helpers.each.call(depth0, depth0, {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n";
  return buffer;
  });

this["TMPLS"]["scheduleSummaryHVAC"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      <th class=\"";
  if (stack1 = helpers.klass) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.klass); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</th>\r\n    ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <tr data-nodeId=\"";
  if (stack1 = helpers.SlotPath) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.SlotPath); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" data-name=\"";
  if (stack1 = helpers.Name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n      <td ";
  if (stack1 = helpers.Status) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Status); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "></td>\r\n      <td>";
  if (stack1 = helpers.Name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td>";
  if (stack1 = helpers.Description) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Description); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</td>\r\n      <td>\r\n        <select data-select=\"schZone\" data-type=\"zone\">\r\n          ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.Zone), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        </select>\r\n      </td>\r\n      <td>\r\n        <select data-select=\"schGroup\" data-type=\"group\">\r\n          ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.Group), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        </select>\r\n      </td>\r\n      <td>\r\n        <select data-select=\"schSchedule\" data-type=\"schedule\">\r\n          ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.Schedule), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        </select>\r\n      </td>\r\n      <td class=\"";
  if (stack1 = helpers.tempClass) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.tempClass); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (stack1 = helpers.Temperature) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Temperature); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td class=\"";
  if (stack1 = helpers.spClass) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.spClass); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (stack1 = helpers.Setpoint) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Setpoint); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td>";
  if (stack1 = helpers.Output) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Output); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n    </tr>\r\n  ";
  return buffer;
  }
function program4(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.selected), {hash:{},inverse:self.program(7, program7, data),fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n          ";
  return buffer;
  }
function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n              <option selected>";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</option>\r\n            ";
  return buffer;
  }

function program7(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n              <option>";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</option>\r\n            ";
  return buffer;
  }

  buffer += "<thead>\r\n  <tr>\r\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.tableHead), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  </tr>\r\n  \r\n</thead>\r\n<tbody>\r\n  ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.tableRows), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n</tbody>";
  return buffer;
  });

this["TMPLS"]["scheduleSummaryLighting"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      <th class=\"";
  if (stack1 = helpers.klass) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.klass); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</th>\r\n    ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <tr data-nodeId=\"";
  if (stack1 = helpers.SlotPath) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.SlotPath); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" data-name=\"";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\" id=\"";
  if (stack1 = helpers.Id) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Id); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n      <td ";
  if (stack1 = helpers.Status) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Status); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "></td>\r\n      <td class=\"Panel\">";
  if (stack1 = helpers.Panel) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Panel); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td class=\"Circuit\">";
  if (stack1 = helpers.Circuit) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Circuit); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td class=\"Description\">";
  if (stack1 = helpers.Description) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Description); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td class=\"Zone\">\r\n        <select data-select=\"schZone\" data-type=\"zone\">\r\n          ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.Zone), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        </select>\r\n      </td>\r\n      <td class=\"Group\">\r\n        <select data-select=\"schGroup\" data-type=\"group\">\r\n          ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.Group), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        </select>\r\n      </td>\r\n      <td class=\"Schedule\"> \r\n        <select data-select=\"schSchedule\" data-type=\"schedule\">\r\n          ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.Schedule), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        </select></td>\r\n      <td class=\"Start\">";
  if (stack1 = helpers.Start) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Start); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td class=\"End\">";
  if (stack1 = helpers.End) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.End); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td class=\"Photocell\">";
  if (stack1 = helpers.Photocell) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Photocell); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td class=\"PhotocellEn\">";
  if (stack1 = helpers.PhotocellEn) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.PhotocellEn); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td class=\"ScheduleOut\">";
  if (stack1 = helpers.ScheduleOut) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.ScheduleOut); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td class=\"Command\">";
  if (stack1 = helpers.Command) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.Command); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n      <td class=\"CmdFb\">";
  if (stack1 = helpers.CmdFB) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.CmdFB); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n    </tr>\r\n  ";
  return buffer;
  }
function program4(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.selected), {hash:{},inverse:self.program(7, program7, data),fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n          ";
  return buffer;
  }
function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n              <option selected>";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</option>\r\n            ";
  return buffer;
  }

function program7(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n              <option>";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</option>\r\n            ";
  return buffer;
  }

  buffer += "<thead>\r\n  <tr>\r\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.tableHead), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  </tr>\r\n  \r\n</thead>\r\n<tbody>\r\n  ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.tableRows), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n</tbody>";
  return buffer;
  });

this["TMPLS"]["subscribe"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n            <getValue uid='";
  if (stack1 = helpers.uid) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.uid); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'\r\n                nodeId='";
  if (stack1 = helpers.nodeId) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.nodeId); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'\r\n                data='";
  if (stack1 = helpers.data) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.data); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'\r\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.tags), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.aggregation), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.timeRange), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.timeFilter), {hash:{},inverse:self.noop,fn:self.program(8, program8, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.rollup), {hash:{},inverse:self.noop,fn:self.program(10, program10, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.autoDelta), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n                \r\n            />\r\n        ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                    tags='";
  if (stack1 = helpers.tags) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.tags); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'\r\n                ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                    aggregation='";
  if (stack1 = helpers.aggregation) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.aggregation); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'\r\n                ";
  return buffer;
  }

function program6(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                    timeRange='";
  if (stack1 = helpers.timeRange) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.timeRange); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'\r\n                ";
  return buffer;
  }

function program8(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                    timeFilter='";
  if (stack1 = helpers.timeFilter) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.timeFilter); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'\r\n                ";
  return buffer;
  }

function program10(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                    rollup='";
  if (stack1 = helpers.rollup) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.rollup); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'\r\n                ";
  return buffer;
  }

function program12(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n                    autoDelta='";
  if (stack1 = helpers.autoDelta) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.autoDelta); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'\r\n                ";
  return buffer;
  }

  buffer += "<ProphetRequest version='1'>\r\n    <Method name='subscribe' uid='";
  if (stack1 = helpers.uid) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.uid); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "'>\r\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.values), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </Method>\r\n</ProphetRequest>";
  return buffer;
  });

this["TMPLS"]["zoneMapsLegend"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, options, functionType="function", escapeExpression=this.escapeExpression, self=this, blockHelperMissing=helpers.blockHelperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      <p class=\"colur clearfix\" style=\"background: "
    + escapeExpression(((stack1 = (depth0 && depth0.color)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"></p>\r\n      <p class=\"range\">"
    + escapeExpression(((stack1 = (depth0 && depth0.range)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</p>\r\n";
  return buffer;
  }

  options = {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data};
  if (stack1 = helpers.legend) { stack1 = stack1.call(depth0, options); }
  else { stack1 = (depth0 && depth0.legend); stack1 = typeof stack1 === functionType ? stack1.call(depth0, options) : stack1; }
  if (!helpers.legend) { stack1 = blockHelperMissing.call(depth0, stack1, options); }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n\r\n";
  return buffer;
  });

this["TMPLS"]["zoneMapsNavFloor"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, options, functionType="function", escapeExpression=this.escapeExpression, self=this, blockHelperMissing=helpers.blockHelperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n        <div class=\"floorCont clearfix\" data-floor=\"";
  if (stack1 = helpers.floorId) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.floorId); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\">\r\n          <p><b>";
  if (stack1 = helpers.floor) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.floor); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</b></p>\r\n          <span data-floor=\"";
  if (stack1 = helpers.floorId) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.floorId); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"></span>\r\n        </div>\r\n      ";
  return buffer;
  }

  buffer += "<div class=\"column span2 clearfix\">\r\n  <div id=\"zMapsNav\" class=\"group clearfix\">\r\n    <h2>Select the floor view</h2>\r\n\r\n    <div id=\"floors\" class=\"clearfix\">\r\n\r\n      ";
  options = {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data};
  if (stack1 = helpers.floors) { stack1 = stack1.call(depth0, options); }
  else { stack1 = (depth0 && depth0.floors); stack1 = typeof stack1 === functionType ? stack1.call(depth0, options) : stack1; }
  if (!helpers.floors) { stack1 = blockHelperMissing.call(depth0, stack1, options); }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </div>\r\n\r\n    <h3>Select the equipment view</h3>\r\n\r\n    <div class=\"clearfix\" id=\"types\">\r\n\r\n    </div>\r\n\r\n    <h3>Temperature Setpoint Range</h3>\r\n\r\n    <div id=\"zMapsLegend\">\r\n\r\n    </div>\r\n\r\n  </div>\r\n</div>\r\n\r\n";
  return buffer;
  });

this["TMPLS"]["zoneMapsNavType"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, options, functionType="function", escapeExpression=this.escapeExpression, self=this, blockHelperMissing=helpers.blockHelperMissing;

function program1(depth0,data) {
  
  var buffer = "";
  buffer += "\r\n      <div class=\"floorCont clearfix\" data-type=\""
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "\">\r\n        <p><b>"
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "</b></p>\r\n        <span data-type=\""
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "\"></span>\r\n      </div>\r\n";
  return buffer;
  }

  options = {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data};
  if (stack1 = helpers.types) { stack1 = stack1.call(depth0, options); }
  else { stack1 = (depth0 && depth0.types); stack1 = typeof stack1 === functionType ? stack1.call(depth0, options) : stack1; }
  if (!helpers.types) { stack1 = blockHelperMissing.call(depth0, stack1, options); }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n";
  return buffer;
  });

this["TMPLS"]["zoneMapsRoofMarker"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, options, functionType="function", escapeExpression=this.escapeExpression, self=this, blockHelperMissing=helpers.blockHelperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n  <a class=\"roofUnitMarker\" \r\n  href=\"";
  if (stack1 = helpers.link) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.link); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"\r\n  target=\"_blank\"\r\n  style=\"\r\n      margin-left: ";
  if (stack1 = helpers._x) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0._x); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + ";\r\n      margin-top: ";
  if (stack1 = helpers._y) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0._y); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + ";\r\n    \">\r\n    <p>";
  if (stack1 = helpers.name) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.name); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</p>\r\n  </a>\r\n";
  return buffer;
  }

  options = {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data};
  if (stack1 = helpers.marker) { stack1 = stack1.call(depth0, options); }
  else { stack1 = (depth0 && depth0.marker); stack1 = typeof stack1 === functionType ? stack1.call(depth0, options) : stack1; }
  if (!helpers.marker) { stack1 = blockHelperMissing.call(depth0, stack1, options); }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n";
  return buffer;
  });