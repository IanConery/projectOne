
/******************************************************************
 * groupsAndZones.js
	Controlco Inc
 * Author: Deepti Phadnis
 ******************************************************************/



;(function($) {
	
		(function() {
				  
		})();


$intr=null;		
$grpZone = {
	schedName:"",
	isVirtual:"false",
	virSchPath:"",
	selectedGroupName:"",
	selectedZoneName:"",
	selectedSubZoneName:"",
	
	getVirtualHtml : function(path,id,buttonId,editbutton,appendStr,selVal,selectedName)
	{
	 if(path==null || path=="")
	 {
		 $(id).html("");
		  	$(buttonId).css("display","none");
		  	return;
	 }
	 $(id).html("");
	 $(buttonId).html("");
	 $(buttonId).append(appendStr);  
	 $(editbutton).css("display","none");	
	 $.niagara.getVirtualScheduleList(path,function(obj){
			 var list='';
			  if(obj!=null && obj.value!="false" && obj.value.length > 0)
			    {
				  for(var i=0;i<obj.value.length;i++)
				  {
					var grp=obj.value[i];
					list=list+'<li><a href"#" value="'+grp.path+'" idn="'+i+'">'+grp.name+'</a></li>';
				  }
				  $(buttonId).show();
				  $(id).append(list);
				  if(selectedName && selectedName!=undefined && selectedName!=null && selectedName!="")
				  {
					  var n = selectedName.split("*");
					  $(buttonId).html("");
					  n[0] = n[0].replace ("%20"," ","gi");
					  $(buttonId).append(n[0]+'<span class="caret"></span>');
					  $(buttonId).attr("value",n[1]);
				  }	  
				  else if(selVal && selVal!=undefined && selVal!=null && selVal!="")
				  {
					  $(buttonId).html("");
					  $(buttonId).append(selVal);
				  }

			    }
			  else
				  {
				  	$(id).html("");
				  	$(buttonId).css("display","none");
				  }
			 
			  });
	 
	 

 },
 checkIsSelected: function (checked)
 {
	if(checked=="true")
	{
		$("#isSelected").attr("checked",true);
		$("#modlink").hide();
		$("#dropdownMenu1").hide();
		$("#Zones").show();
		$("#Group").show();
		$("#SubZones").show();
		$grpZone.isVirtual="true";
		$grpZone.getVirtualHtml($data.scheduleName,"#GroupNames","#GroupButton","#editGroup",'','Groups <span class="caret"></span>');

	}
	else
	{
		$("#isSelected").attr("checked",false);
		$grpZone.selectedGroupName="";
		$grpZone.selectedZoneName="";
		$grpZone.selectedSubZoneName="";
		$("#modlink").show();
		$("#dropdownMenu1").show();
		$("#Group").hide();
		$("#editGroup").hide();
		$("#GroupNames").html("");
		
		$("#Zones").hide();
		$("#editZone").css("display","none");
		$("#ZoneNames").html("");
		$("#ZoneButton").hide();
		$("#closeZone").hide();
		
		$("#SubZones").hide();
		$("#editSubZone").css("display","none");
		$("#SubZoneNames").html("");
		$("#SubZoneButton").hide();
		$("#closeSubZone").hide();
		
		$grpZone.isVirtual="false";
		var a = $("#HVACButton").text();
		$("#path").text(a);
		
		$grpZone.getScheduleData();
		 
		$grpZone.selectedGroupName = "";
		 $grpZone.selectedZoneName = "";
		 $grpZone.selectedSubZoneName = "";

	}
 },
 getScheduleData: function()
 {
			var date = $util.normalizeDate();
			if($grpZone.isVirtual=="true")
					  {
						$util.getVirtualMonthlySchedule(date,$data.scheduleName,$data.virSchPath);
					  }
				  else
					  $util.getMonthlySchedule(date,$data.scheduleName);
		if($intr != null)
			clearInterval($intr);
			  $(window).unload(function() {
				  clearInterval($intr);
				 });
			  $intr = setInterval(function(){
				  var date = $util.normalizeDate();
				  if($grpZone.isVirtual=="true" && $data.virSchPath!="")
					  {
						$util.getVirtualMonthlySchedule(date,$data.scheduleName,$data.virSchPath);
					  }
				  else
					  $util.getMonthlySchedule(date,$data.scheduleName);
				 },
				 20000); 
 }
 
 };
 

 
 

 
 var $currWeeklySchedule = [];
 var $newWeeklySchedule = [];
    
    var hvacList = [];
    var lightingList = [];
    var generalList = [];
    
var oldEventName="";
var newEventName="";
var grpZone={};
var intr;



$("#isSelected").click(function (){
	
	var date = $util.normalizeDate();
	if($("#isSelected").attr("checked"))
	{
		$grpZone.checkIsSelected("true");
	}
	else
	{
		$grpZone.checkIsSelected("false");
	}	
	});


  

  
 
 
 
 

 function showSelected(group,obj,buttonId)
 {
	 isVirtual="true";
	 $(group).show();
	 var v = $(obj).attr("value");
	 $data.virSchPath = v;
	 var txt = $(obj).text();
	 $(buttonId).html("");
	 $(buttonId).append(txt+' <span class="caret"></span>');
	 var date = $util.normalizeDate();
	 $util.getVirtualMonthlySchedule(date,$data.scheduleName,v);
	 selectedGroupName = txt;
	 
	 $(group).click(function()
			 {
		 	
		    var jsonStr={
		    		"isVirtual" : ""+ $grpZone.isVirtual,
		    		"virSchPath" : $data.virSchPath,
		    		"selectedGroupName" : $grpZone.selectedGroupName,
		    		"selectedZoneName" : $grpZone.selectedZoneName,
		    		"selectedSubZoneName" : $grpZone.selectedSubZoneName
		    };
		    
		    var jsonF = JSON.stringify(jsonStr);
		   
		    var alink = "groupEdit.html?ord="+$data.scheduleName+"&virSchPath="+v+"&name="+txt+"&json="+jsonF; 
		    $(group).attr('href',alink);
		    //window.location.href = "groupEdit.html?ord="+$data.scheduleName+"&virSchPath="+v+"&name="+txt+'&json='+jsonF; 
		 });
	 return v;
 }
 $("ul#GroupNames li a").live("click",function(){
	 var v = showSelected("#editGroup",this,"#GroupButton");
	 $grpZone.getVirtualHtml(v,"#ZoneNames","#ZoneButton","#editZone","#closeZone",'Zones <span class="caret"></span>');
	 v = $(this).attr("value");
	 $grpZone.selectedGroupName = $("#GroupButton").text()+"*"+v;
	 $data.virSchPath = v;
	 $grpZone.getScheduleData();
	 $("#GroupButton").attr("value",v);
	 var b= $("#GroupButton").text();
	 var a = $("#HVACButton").text();
	 $("#path").text(a+" / "+b);
	 $("#closeZone").css("display","none");
 });
 
 $("ul#ZoneNames li a").live("click",function(){

	 var v = showSelected("#editZone",this,"#ZoneButton");
	 $grpZone.getVirtualHtml(v,"#SubZoneNames","#SubZoneButton","#editSubZone","#closeSubZone",'Sub Zones <span class="caret"></span>');
	 v = $(this).attr("value");
	 $grpZone.selectedZoneName = $("#ZoneButton").text()+"*"+v;
	 
	 $data.virSchPath = v;
	 $grpZone.getScheduleData();
	 
	 var a= $("#HVACButton").text();
	 var b = $("#GroupButton").text();
	 var c= $("#ZoneButton").text();
	 $("#ZoneButton").attr("value",v);
	 
	 $("#path").text(a+" / "+b+" / "+c);
	$("#closeZone").css("display","block");
	$("#closeSubZone").css("display","none");
 });
 
 $("ul#SubZoneNames li a").live("click",function(){
	 var v = showSelected("#editSubZone",this,"#SubZoneButton","#closeSubZone");
	 v = $(this).attr("value");
	 $data.virSchPath = v;
	 $grpZone.getScheduleData();
	 $grpZone.selectedSubZoneName = $("#SubZoneButton").text()+"*"+v;
	 var a= $("#GroupButton").text();
	 var b = $("#HVACButton").text();
	 var c= $("#ZoneButton").text();
	 var d= $("#SubZoneButton").text();
	 $("#SubZoneButton").attr("value",v);
	 
	$("#path").text(a+"/ "+b+" / "+c+" / "+d);
	$("#closeSubZone").css("display","block");
	$("#closeZone").css("display","none");
 });
 
 
/* $("select#groupList").change(function(){
	 
	 selectVirtualSchedule();
 });*/	  

 $("#closeZone").click(function (){ 
	 $("#Zones").hide();
	 var a= $("#HVACButton").text();
	 var b = $("#GroupButton").text();
	 $("#path").text(a+" / "+b);

	 v = $("#GroupButton").attr("value");
	 $data.virSchPath = v;
	 $grpZone.getScheduleData();
	 
	 $grpZone.selectedZoneName = "";
	 $grpZone.selectedSubZoneName = "";
 });

	 $("#closeSubZone").click(function (){ 
	 $("#SubZones").hide();
	 $("#closeZone").css("display","block");

	 var a= $("#HVACButton").text();
	 var b = $("#GroupButton").text();
	 var c= $("#ZoneButton").text();
     $("#path").text(a+"/ "+b+" / "+c);
	 v = $("#ZoneButton").attr("value");
	 console.log(v);
	 $data.virSchPath = v;
	 $grpZone.getScheduleData();
	 $grpZone.selectedSubZoneName = "";
	 });

 
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     
    $('#mask').click(function () {
        $(this).hide();
        $('.window').hide();
    });         

 /* Get the metering present datapoint and store its result */
  

 
 //$.niagara.BatchPoll.printPollList();
})(jQuery);
