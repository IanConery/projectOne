$(document).ready(function(){
   $('#schedule, #HVAClighting, #NamePlaceholder, .fc-button-effect, .fc-header-space').hide();
   $('.fc-button-content').html("");
   $('.fc-button-today .fc-button-content').text('Today');
   $('.fc-button-month .fc-button-content').text('Month');
   $('.fc-button-agendaWeek .fc-button-content').text('Week');
   $('.fc-button-agendaDay .fc-button-content').text('Day');
   $('#modlink a').text('Add Event');
   $('#modlink').click(function(){
      $('#mask').css({'background' : 'black','height' : '100% ','width' : '100%','position' : 'fixed','top' : '0','left' : '0'});
   });
   $('.fc-button-inner').mousedown(function(){
      $(this).children('.fc-button-content').css('margin-top', '10px');
   }).mouseup(function(){
      $(this).children('.fc-button-content').css('margin-top', '9px');
   });
   $('.fc-button-agendaDay').click(function(){
      $('.fc-widget-content').removeClass('weekView dayView').addClass('dayView');
      $('.fc-widget-header').not('.fc-agenda-axis').removeClass('weekHeader');
   });
   $('.fc-button-agendaWeek').click(function(){
      $('.fc-widget-content').removeClass('weekView dayView').addClass('weekView');
      $('.fc-widget-header').not('.fc-agenda-axis').removeClass('weekHeader').addClass('weekHeader');
   });
   $('.fc-button-month').click(function(){
      $('.fc-widget-content').removeClass('weekView dayView');
      $('.fc-widget-header').not('.fc-agenda-axis').removeClass('weekHeader');
   });
   var what = ($('.fc-button-month').attr('class'));
   var isActive = new RegExp('.*active');
   var isToday = new RegExp('.*today');
   var isOtherMonth = new RegExp('fc-other-month');
   $('.fc-widget-content').click(function(){
      if ($(this).attr('class').match(isOtherMonth)){
         console.log('Please change the month.');
      } else {
         if (what.match(isActive)) {
            if ($(this).attr('class').match(isToday)){
               $('.fc-widget-content').removeClass('dayBorder todayBorder');
               $(this).addClass('todayBorder');
            } else{
               $('.fc-widget-content').removeClass('dayBorder todayBorder');
               $(this).addClass('dayBorder');  
            }
         };
      };
   });
   $('.fc-button-next .fc-button-inner, .fc-button-prev .fc-button-inner, .fc-button-today span').click(function(){
      $('.fc-widget-content').removeClass('dayBorder todayBorder');
   });
});