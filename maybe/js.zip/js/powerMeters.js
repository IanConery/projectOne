define(['highcharts', 'chart-loader'], function(Highcharts, chartLoader) {

  window.powerMeters = function(newData1,name) {

    

    var MeterModel = Backbone.Model.extend({

    });

    var MeterCollection = Backbone.Collection.extend({
      model: MeterModel
    });

    var meterCollection = new MeterCollection();

    meterCollection.add(
      _.map(newData1, function(e){
        return {
          name: e[0],
          slotpath: e[1]
        }
      })
    ); 

    /*$('#powerTable').on('click', '.tPower', function(){ */

      //var name = $(this).find('td:first').text();
      $('#meterTitle').text(name);
      var clickedModel = meterCollection.findWhere({ name: name });
      var slotpath = clickedModel.get('slotpath');
      $('#loadProfileChart, #dailKwhChart, #monthlyKwhChart').find('div:first-child').addClass('loading');
      doPeakEnergyChart(slotpath);
      doDailyKwhChart(slotpath);
      doMonthlyKwhChart(slotpath);
  

    //$(this).addClass('highlight');
    /*$('#meterTitle').text(meterCollection.at(0).get('name'));
    var firstSlotpath = meterCollection.at(0).get('slotpath');
    doPeakEnergyChart(firstSlotpath);
    doDailyKwhChart(firstSlotpath);
    doMonthlyKwhChart(firstSlotpath); */

    function doPeakEnergyChart(nodeId) {
      var siteInfo = $util.siteInfoFromNodeId(nodeId);
      chartLoader.renderChart({
          renderTo: 'loadProfileChart',
          chartType: 'peakEnergy',
          nodeId: nodeId,
          oatNode: getSelectedNodeId(),
          timeRange: 'current7days',
          chartTitle: {
            text: 'Load Profile - Past 7 Days',
            align: 'left',
            margin: 25,
            x: 10 ,
            y: 20,
            style: {
              color: 'gray',
              fontSize: '14px'
            }
          }
      });
    }

    function doDailyKwhChart(nodeId) {
      chartLoader.renderChart({
        chartType: 'kwh',
        nodeId: nodeId,
        renderTo: 'dailKwhChart',
        dataDefs: [{
          data: 'prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum',
          uid: 'elecMeterRealEnergyNum'
        }],
        timeRange: 'current1Month',
        interval: 'oneDay',
        highChartCfg: {
          title: {
            text: 'Daily KWH',
            align: 'left',
            margin: 25,
            x: 10 ,
            y: 20,
            style: {
              color: 'gray',
              fontSize: '14px'
            }
          }
        }
      });
    }

    function doMonthlyKwhChart(nodeId) {
      chartLoader.renderChart({
        chartType: 'kwh',
        nodeId: nodeId,
        renderTo: 'monthlyKwhChart',
        dataDefs: [{
          data: 'prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum',
          uid: 'elecMeterRealEnergyNum'
        }],
        timeRange: 'current12Months',
        interval: 'oneMonth',
        highChartCfg: {
          title: {
            text: 'Monthly KWH',
            align: 'left',
            margin: 25,
            x: 10 ,
            y: 20,
            style: {
              color: 'gray',
              fontSize: '14px'
            }
          },
          xAxis: {
              type: 'datetime',
              tickInterval: 24 * 3600 * 1000 * 30,
              labels: {
                  formatter: function() {
                      return Highcharts.dateFormat('%b', this.value)
                  }
              }
          }
        }
      });
    }



  };

});

