// ggp.js
// Robert Sadler
// ChamberlinBurnsBlodgett

// Global Variables
var globalPaths = globalPaths || {};
var $util = $util || {};

$util.loaderHTML = '<div id="floatingCirclesG"><div class="f_circleG" id="frotateG_01"></div><div class="f_circleG" id="frotateG_02"></div><div class="f_circleG" id="frotateG_03"></div><div class="f_circleG" id="frotateG_04"></div><div class="f_circleG" id="frotateG_05"></div><div class="f_circleG" id="frotateG_06"></div><div class="f_circleG" id="frotateG_07"></div><div class="f_circleG" id="frotateG_08"></div></div>';

(function() {

    var $ = this.jQuery;
    var root = this;
    root.util = $util;

    var countingComfortAndRoofData = 0;

    _.extend($util, {

        // starts intervaled polling
        // options: {
        //     fxn: function to call,
        //     args: array of arguments to fxn
        //     interval: amount of milliseconds btwn polling
        //     isEquip: if for equipment tables (manages cleanup)
        //     secondRequestInterval: after the initial poll returns data
        //        first off a one-time tighter interval to get the initial
        //        data back quicker.  afterwhich, the true interval value
        //        is set up for the polling
        // }
        kickoffPolling: function(options) {

            options.interval = options.interval || 10000;
            options.secondRequestInterval = options.secondRequestInterval || 2000;

            // 1. call once now,
            options.fxn.apply(this, options.args);

            // 2. once more quickly to get available data for fast load
            setTimeout(function() {
                options.fxn.apply(this, options.args);
            }, options.secondRequestInterval);

            // 3+ then queue it repeated pollilng
            var interval = setInterval(function() {
                options.fxn.apply(this, options.args);
            }, options.interval);


            // adds interval to pollQueue arr if defined so that intervals can be cleared when necessary
            if (options.pollQueue) {
                window[options.pollQueue] = window[options.pollQueue] || [];
                window[options.pollQueue].push(interval);
            }

            // tidy yourself when you go
            $(window).unload(function() {
                clearInterval(interval);
            });
        },

        createMallChoiceSelector: function(propertySelectOptions) {

            $('#mallChoice').html(TMPLS.mallSelectChosen(propertySelectOptions));
            $('.mall-select').chosen({search_contains: true, inherit_select_classes: true});
            $('.mall-select').on('change',function(jQEvent) {
                var nodeId = jQEvent.currentTarget.value;
                setSelectedNodeId(nodeId);
                var siteInfo = $util.siteInfoFromNodeId(nodeId);
                if (siteInfo.isTeamSite) {
                    window.location = 'team.html';
                } else {
                    location.reload();
                }

            });
        },

        pollReq: function(uid) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='pollSubscription' uid='" + uid + "'/>" +
                "</ProphetRequest>";
            return req;

        },

        //Function to create xml string to get node Info
        getNodeInfo: function(nodeId) {
            var req = "<ProphetRequest version='1'>" +
                "<Method name='getNode' uid='3F2504E0-4F89-11D3'>" +
                "<nodeId>" + nodeId + "</nodeId>" +
                "</Method></ProphetRequest>";

            return req;
        },

        setUpUser: function(xmlDoc) {
            var userData = $util.parseUserData(xmlDoc);
            setCookie('sessionUser', userData.name, 7);
            $('.admin .user-name').html(userData.fullName);
            var selectedNodeId = getSelectedNodeId();
            var siteInfo;
            if (selectedNodeId) {
                siteInfo = $util.siteInfoFromNodeId(selectedNodeId);
                if (/team\.html/.test(window.location.pathname)) {
                    if (!siteInfo.isTeamSite) {
                        location = 'index.html';
                    }
                }
                else {
                    if (siteInfo.isTeamSite) {
                        location = 'team.html';
                    }
                }
            } else {
                selectedNodeId = userData.userRoots[0].nodeId;
                setSelectedNodeId(selectedNodeId);
                siteInfo = $util.siteInfoFromNodeId(selectedNodeId);
                if (siteInfo.isTeamSite) {
                    if (!/team\.html/.test(window.location.pathname)) {
                        window.location = "team.html";
                    }
                }
            }

            // prepare the select options by setting 'selected' on the appropriate option
            foundNodeInMall:
            for (var g=0; g< userData.propertySelectOptions.mallOptionList.length; g++) {
                var group = userData.propertySelectOptions.mallOptionList[g];
                for (var m=0; m<group.options.length; m++) {
                    if (group.options[m].nodeId === selectedNodeId) {
                        group.options[m].selected = true;
                        break foundNodeInMall;
                    }
                }
            }

            // prepare the select options by setting 'selected' on the appropriate option
            for (var t=0; t< userData.propertySelectOptions.teamOptionList.length; t++) {
                if (userData.propertySelectOptions.teamOptionList[t].nodeId === selectedNodeId) {
                    userData.propertySelectOptions.teamOptionList[t].selected = true;
                    break;
                }
            }

            $('iframe').each(function() {
                oldSrc = $(this).attr('src');
                if (oldSrc && oldSrc.indexOf('{slot}') > 0) {
                    newSrc = oldSrc.replace('{slot}', siteInfo.nodeId).replace('{site}', siteInfo.site);
                    if ($('#bodySchedule').length > 0) {
                        newSrc = newSrc.replace('DataTree', 'Schedules');
                    }
                    $(this).attr('src', newSrc);
                }
            });

            if (!userData.userRoots[0]) {
                window.location.replace("unauthorized.html");
            } else {
                $util.createMallChoiceSelector(userData.propertySelectOptions);
            }

            daPath = selectedNodeId;
            globalPaths.daPath = daPath;
            return selectedNodeId;
        },

        rwiAccess: function(rwiAcess) {
            var rwiAcessArr = rwiAcess.split("");

            for (var q = 0; q < rwiAcessArr.length; q++) {

                switch (rwiAcessArr[q]) {
                    case 'r':
                        r = true;
                        break
                    case 'w':
                        w = true;
                        break
                    case 'i':
                        i = true;
                        break
                }
            }

            if (!r)
                readNotPermissed();
            if (!w)
                writeNotPermissed();
            if (!i)
                invokeNotPermissed();
        },
        objectSize: function(obj) {
            var size = 0,
                key;
            for (key in obj) {
                if (obj.hasOwnProperty(key)) size++;
            }
            return size;
        },

        parseUserData: function(xmlDoc) {
            xmlDoc = _.isObject(xmlDoc) ? xmlDoc : $.parseXML(xmlDoc);
            var d = xml2json(xmlDoc, '');
            var userData = JSON.parse(d).userData;
            var userRoots;
            if (userData.userRoots.root) {
                userRoots = _.isArray(userData.userRoots.root) ? userData.userRoots.root : [userData.userRoots.root];
            } else {
                userRoots = [];
            }
            userRoots = _.map(userRoots, function(root) {
                return {
                    nodeId: root['#text'],
                    permissions: root['@p']
                }
            })
            userData.userRoots = userRoots;

            // encapsulates creation of json obj to be consumed by template
            // to create select list w/ options
            function makeSelectOptionList() {
                var siteInfos = _.map(userRoots, function(root) {
                    var siteInfo = $util.siteInfoFromNodeId(root.nodeId);
                    // drop slot:/DataTree
                    var nodeItems = root.nodeId.split('/').slice(2);
                    nodeItems = _.map(nodeItems, function(n) {
                        return propName(n);
                    });
                    // group is 'Region / Team'
                    siteInfo.group = _.first(nodeItems, 2).join(' / ');
                    // set team for sorting
                    siteInfo.team = root.nodeId.split('/')[3];
                    return siteInfo;
                });

                // create one flat option list for team sites
                var teamOptionList = _.where(siteInfos, {isTeamSite: true});
                teamOptionList =_.sortBy(teamOptionList, function(opt) {
                    var teamNoMatch = /([0-9]+)/.exec(opt.name);
                    if (teamNoMatch) {
                        return parseInt(teamNoMatch[1], 10);
                    } else {
                        return opt.name;
                    }
                });

                // create another option list for malls, grouped by team
                var mallList = _.where(siteInfos, {isTeamSite: false});
                var mallsByGroupMap = _.groupBy(mallList, 'group');
                var mallsByGroupArray = _.toArray(mallsByGroupMap);
                var mallOptionList = _.map(mallsByGroupArray, function(grpList) {
                    return {
                        group: _.first(grpList).group,
                        team: _.first(grpList).team,
                        options: grpList
                    };
                });
                mallOptionList = _.sortBy(mallOptionList, 'team');

                return {
                    teamOptionList: teamOptionList,
                    mallOptionList: mallOptionList
                }
            }


            // ------------------- SAVE --------------------------------------
            // makeHierarchicalNavTree function encapsulates creation of a
            // hierarchical json obj to be consumed by template to create nested
            // ul/li structre.
            // THIS IS COMMENTED TO SAVE THE DEVELOPMENT OF THIS COMPLEX LOGIC --
            // IF WE EVER GO TO A STRICT HIERARCHICAL NAVIGATION OF USERROOTS,
            // THIS FUNCTION PRODUCES THAT.

            // function makeHierarchicalNavTree() {

            //     function addToTree(tree, array) {
            //         var str = 'slot:/DataTree';
            //         for (var i = 0; i < array.length; i++) {
            //             str += '/' + array[i];
            //             tree = tree[array[i]] = tree[array[i]] ||
            //                 {nodeId: str,
            //                  site: array[i],
            //                  name: propName(array[i])
            //                 };
            //          }
            //     }

            //     function makeMenuTree(list, obj) {
            //         for (var p in obj) {
            //             if (typeof obj[p] === 'object') {
            //                 if (obj[p].nodeId) {
            //                     var menuItem = {
            //                         nodeId: obj[p].nodeId,
            //                         name: obj[p].name,
            //                         site: obj[p].site,
            //                         children: []
            //                     };
            //                     list.push(menuItem);
            //                     makeMenuTree(menuItem.children, obj[p]);
            //                 }
            //             }
            //         }
            //     }

            //     var menuMap = {};
            //     var menus = [];

            //     userRoots.forEach(function(root) {
            //         var nodeItems = root.nodeId.split('/').slice(2);
            //         addToTree(menuMap, nodeItems);
            //     });

            //     makeMenuTree(menus, menuMap);

            //     return menus;

            // }
            //userData.propertyMenu = makeHierarchicalNavTree();
            // ------------------- SAVE --------------------------------------

            var opts = makeSelectOptionList();
            userData.propertySelectOptions = {
                mallOptionList: opts.mallOptionList,
                teamOptionList: opts.teamOptionList
            };
            return userData;
        },

        // parse xml response from getTable, returning object with uid and array of rows
        parseTableXml: function(xml) {
            var d = xml2json($.parseXML(xml), '');
            var da = JSON.parse(d).ProphetResponse;
            var methodResponses = _.isArray(da.MethodResponse) ? da.MethodResponse : [da.MethodResponse];
            var uid, props, respRows, rows = [];
            _.each(methodResponses, function(resp) {
                uid = resp['@uid'];
                // the table 'h' header row columns name the properties
                // for the values in the table 'r' row columns
                props = resp.t.h.c;
                if ( !! resp.t.r) {
                    respRows = _.isArray(resp.t.r) ? resp.t.r : [resp.t.r];
                }
                else {
                    respRows = [];
                }

                _.each(respRows, function(row) {
                    var obj = {};
                    _.each(row.c, function(col, i) {
                        obj[props[i]] = col || '';
                    });
                    obj.uid = uid;
                    rows.push(obj);
                })

            });
            return {
                uid: uid,
                rows: rows
            };
        },

        // parse xml response from getNode
        parseNodeXml: function(xml) {
            var d = xml2json($.parseXML(xml), '');
            var da = JSON.parse(d).ProphetResponse;
            var methodResponse = da.MethodResponse;
            var nodes, singleNode = true;
            if (_.isArray(methodResponse.node) ) {
              nodes = methodResponse.node;
              singleNode = false;
            } else {
              nodes = methodResponse.node ? [methodResponse.node] : [];
            }

            _.each(nodes, function(node){

              node.uid = methodResponse['@uid'];
              node.tags = !! node.tags ? node.tags.split(',') : [];
              // attributes is just a container. the real data is
              // in attributes.attr (which could be an obj or an array)
              // on options.attr, then we need to get at @attris (xml dom)
              // to fill out all the data, then we simply set options.attributes
              // to a regular array of JS objects
              var attrs = [];
              if ( !! node.attributes) {
                  if (_.isArray(node.attributes.attr)) {
                      attrs = node.attributes.attr;
                  }
                  else {
                      attrs = [node.attributes.attr];
                  }
                  delete node.attributes;
              }
              _.forEach(attrs, function(a) {
                  a.name = a['@n']; delete a['@n'];
                  a.definedOnThisNode = a['@d'] === "true"; delete a['@d'];
                  a.value = a['#cdata']; delete a['#cdata'];
              });
              node.attributes = attrs;

              node.type = node['@type']; delete node['@type'];

              node.navFileFor = function(navType) {
                  return _.findWhere(this.attributes, {
                      name: navType
                  });
              };
              // notice, this is the same as 'navFileFor' above... this is just a more generic name;
              // should probably kill navFileFor in favor of attrVal cuz that's what we're really getting
              node.attrVal = function(attrName) {
                  return _.findWhere(this.attributes, {
                      name: attrName
                  });
              };

            });

            return singleNode ? nodes[0] : nodes;
        },

        // returns a node which may have array of nodes, recursed
        parseNavFileXml: function(xml) {
            var d = xml2json($.parseXML(xml), '');
            var nav = JSON.parse(d).nav;

            function getNode(n) {
                if (_.isArray(n)) {
                    var nodes = [];
                    _.each(n, function(no) {
                        nodes.push(getNode(no));
                    });
                    return nodes;
                }
                else {
                    var node = n;
                    node.name = node['@name'];
                    delete node['@name'];
                    node.icon = node['@icon'];
                    delete node['@icon'];
                    node.ord = node['@ord'];
                    delete node['@ord'];

                    // if a node as a node, it may be one or more;
                    // regardless we will return it as an array
                    // of subnodes
                    if (node.node) {
                        node.nodes = getNode(node.node);
                        delete node.node;
                    }
                    return node;
                }
            }

            var node = getNode(nav.node);

            return node;
        },

        // transform value or array of values returned from subscribe or pollSubscription
        // to meaningful objects.  returns array of value objects.  each value object
        // has a property  called 'value' which is derived from the value metadata,
        // and is aware of type... e.g. for any value w/ a unit, the unit is returned
        // as a suffix.  any boolean type will show the trueText or falseText based on the
        // value.  numeric values will be returned as integers or floats, respecting the
        // configured precision
        _transformResponseValues: function(values) {

            values = _.isArray(values) ? values : [values];

            var defineValueProp = function(obj) {
                Object.defineProperty(obj, "value", {
                    get: function() {
                        var val = obj.v;
                        switch (obj.type) {
                            case 'numeric':
                                if (/\./.test(val)) {
                                    val = parseFloat(Number(val).toFixed(parseInt(obj.precision, 10)));
                                } else {
                                    val = parseInt(val, 10);
                                }
                                val = $util.addCommas(val);
                                if ( !! obj.units) {
                                    val += ' ' + obj.units;
                                }
                                break;
                            case 'boolean':
                                val = (val === "true") ? obj.trueText : obj.falseText;
                                break;
                            case 'enum':
                                // TODO: do something with mapped enum vals
                            case 'string':
                                // TODO:  mabye nothing to do, but need a test case

                        }
                        return val;
                    }
                });
            };

            var atRE = /^@/;

            _.each(values, function(val) {
                // transform '@' properties to normal prop names (strip '@')
                for (var p in val) {
                    if (atRE.test(p)) {
                        val[p.replace(atRE, '')] = val[p];
                        delete val[p];
                    }
                }
                defineValueProp(val);
            });

            return values;
        },

        // parse xml response from subscribe; returns object with original uid
        // and an array of values
        parseSubscribeXml: function(xml) {
            var d = xml2json($.parseXML(xml), '');
            var da = JSON.parse(d).ProphetResponse;
            var data = da.MethodResponse;

            data.uid = data['@uid'];
            delete data['@uid'];
            delete data['@name'];

            if (data.value) {
                data.values = this._transformResponseValues(data.value);
                delete data.value;
            }

            return data;
        },

        // parse xml response from pollSubcription; returns object with original uid
        // and an array of values
        parsePollSubcriptionXml: function(xml) {
            // pollSubscription returns the same data as subscribe
            return $util.parseSubscribeXml(xml);
        },

        // parse xml response from getData; return array of dataDefinition objects
        parseDataXml: function(xml) {
        },

        // like parseDataDefinitionXml, this parses server response, but ulike parseDataDefinitionXml,
        // this one recieves methodResponses array of objects, not xml
        parseDataDefinition: function(methodResponses) {
            var data = [];
            _.each(methodResponses, function(methodResp) {

            });
            return data;
        },

        // parse xml response from getDataDefinitions; return array of dataDefinition objects
        parseDataDefinitionXml: function(xml) {
            var d = xml2json($.parseXML(xml), '');
            var methodResponse = JSON.parse(d).ProphetResponse.MethodResponse;

            var dataDefs;
            if (_.isArray(methodResponse)) {
                dataDefs = _.map(methodResponse, function(resp) {
                    var dd;
                    if (resp.error) {
                        dd = {};
                        var err = ["parseDataDefinitionXml: getDataDefinition UID", resp['@uid'], resp.error].join(' ');
                        console.error(err);
                        throw err;
                    }
                    else {
                        dd = resp.dataDefinition;
                    }
                    dd.uid = resp['@uid'];
                    return dd;
                });
            }
            else {
                dataDefs = methodResponse.dataDefinition;
            }

            dataDefs = _.isArray(dataDefs) ? dataDefs : [dataDefs];

            var data = _.map(dataDefs, function(dd) {

                var o = _.extend({}, dd);

                // replace @type with type
                o.type = o['@type'];
                delete o['@type'];
                // transform trended to true boolean type
                o.trended = o.trended === 'true';

                if (!_.isUndefined(o.units)) {
                    o.units = {
                        text: o.units['#text'],
                        name: o.units['@name']
                    };
                }

                // dd.actions is a container; it has an array of 'action' inside;
                // just promote up to o.actions array
                if (!_.isUndefined(o.actions)) {
                    o.actions = _.map(o.actions.action, function(a) {
                        return a;
                    });
                }

                return o;
            });

            return data;

        },

        // given a methodResponse object from a getData/getDataDefinition request
        // return a dataDefinition model
        dataDefModelFromResponse: function(methodResponse) {
            var uid = methodResponse['@uid'];


        },

        subscribe: function(subscribeReq, subscribeUid, callback) {
            $.niagara.postReq("testPath", subscribeReq, function(xml) {
                var subscribeData = $util.parseSubscribeXml(xml);
                callback(subscribeData.values);
            });
        },

        roundDecimals: function(num, dec) {
            return Math.round(num * Math.pow(10, dec)) / Math.pow(10, dec);
        },

        addCommas: function(nStr) {
            nStr += '';
            x = nStr.split('.');
            x1 = x[0];
            x2 = x.length > 1 ? '.' + x[1] : '';
            var rgx = /(\d+)(\d{3})/;
            while (rgx.test(x1)) {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            }
            return x1 + x2;
        },

        siteInfoFromNodeId: function(nodeId) {
            var site = nodeId.slice(nodeId.lastIndexOf('/') + 1);
            return {
                name: propName(site),
                nodeId: nodeId,
                site: site,
                isTeamSite: /^Team|^EastRegion|^WestRegion/.test(site)
            }
        }


    });

    // Start $(document).ready()
    $(document).ready(function() {
        // define daPath

        // daPath = getSelectedNodeId();
        // globalPaths.daPath = daPath;

        Handlebars.registerPartial('prophetMethodCriteria', TMPLS.prophetMethodCriteria)
        // subMenu Tabs
        $('.subMenu a').on('click', function() {
            var tab = "#" + $(this).text().replace(/\s/g, '');
            $('.subMenu a').removeClass('active');
            $(this).addClass('active');
            $('.innerContent').css('display', 'none');
            $(tab).css('display', 'block');
            veilSize();
        });
        // subMenu2 Tabs
        $('body').on('click', '.subMenu2 a', function() {
            var tab = "#" + $(this).text().replace(/\s/g, '');
            $('.subMenu2 a').removeClass('active');
            $(this).addClass('active');
            $('.WsubMenu2').css('display', 'none');
            $(tab).css('display', 'block');
        });
        // subMenu3 Tabs
        $('.subMenu3 a').on('click', function() {
            var tab = "#" + $(this).text().replace(/\s/g, '');
            $(this).closest('section').find('.subMenu3 a').removeClass('active');
            $(this).addClass('active');
            $(this).closest('section').find('.WsubMenu3').css('display', 'none');
            $(this).closest('section').find(tab).css({
                'display': 'table',
                'position': 'relative',
                'top': '-1px'
            });
        });

        // .admin config

        $('.admin .icon-cog').on('click', function(){
            $(this).find('.logout').add($(this).closest('.icon-cog')).toggleClass('active');
        });

        // this block encapsulates generic tab widget behavior.  should be moved to
        // its own file and $util-ized
        (function(){

            // Tucson-only for summary tab for now
            (function() {
                  var nodeID = getSelectedNodeId();
                  //if ( !/Tucson/.test(nodeID) ) {
                    //$('#bodyPower #summaryTab').remove();
                  //}
            }())



            // find the selected tab (li) and set 'active' on its tab content
            function setActiveTabContent(tabGroup) {
                var $tabGroup = $(tabGroup);
                var tabs = $tabGroup.find('li [data-tab]');
                if (tabs.length) {
                    var activeTabEl = _.find(tabs, function(t) {return $(t).hasClass('active');} );
                    activeTabEl = activeTabEl || _.first(tabs);
                    $activeTab = $(activeTabEl);
                    // setting active is effective here only in the case where this is no active tab defined
                    $activeTab.addClass('active');

                    var $tabContentsAll = $tabGroup.find(' > .tab-content');
                    $tabContentsAll.removeClass('active');
                    var $targetTabContainer = $('#' + $activeTab.data('tab'));
                    $targetTabContainer.addClass('active');
                    setHighchartWidth($targetTabContainer);
                    setActiveTabColors($tabGroup);

                }

            }
            function setActiveTabColors(tabGroup) {
                var tabBgColor = $(tabGroup).data('tabBg');
                var tabBgActiveColor = $(tabGroup).data('tabBgActive');
                if (tabBgColor) {
                    $(tabGroup).find('> ul a, > .tab-content').css({backgroundColor: tabBgColor});
                }
                if (tabBgActiveColor) {
                    $(tabGroup).find('> ul a.active, > ul.a:hover, > .tab-content.active').css({backgroundColor: tabBgActiveColor});
                }

            }

            // *if* a tab container contains Highcharts, it will be resized
            // according to $tabContainer's width; this is needed because of the
            // hiding method used for the tab widget. when the inactive tabs
            // are hidden ("off screen" by absolute, negatve top & left) the chart's
            // container width is not accurate.
            //
            // this function should be called *after* setting the $tabContainer
            // as active.
            function setHighchartWidth($tabContainer) {
                $.each($tabContainer.find('[data-highcharts-chart]'), function(i, chartContainer) {
                    // we may have charts withing tabs within tabs, within tabs... so
                    // find each chart's containing tab and only operate if
                    // its containing tab is active.
                    var $theChartsTabBox = $(chartContainer).parents('.tab-content');
                    var $chartParent = $(chartContainer).parent();
                    if ( $theChartsTabBox.hasClass('active') ) {
                        var chartIdx = parseInt($(chartContainer).data('highchartsChart'),10);
                        var chart = Highcharts.charts[chartIdx];
                        chart.setSize($chartParent.width(), chart.height);

                    }
                })
            }
            _.each($('.tab-group'), setActiveTabContent);
            _.each($('.tab-group'), setActiveTabColors);

            $('.tab-group li a').on('click', function(jQEvent) {
                var $thisTab = $(this);
                var $tabGroup = $thisTab.closest('.tab-group');
                var $tabContentsAll = $tabGroup.find(' > .tab-content');
                var $tabsAll = $(this).closest('ul').find('li a');
                if ( $thisTab.hasClass('active') ) {
                    jQEvent.stopPropagation();
                    return;
                } else {
                    $tabsAll.removeClass('active');
                    $tabContentsAll.removeClass('active');
                    $thisTab.addClass('active');
                    var $targetTabContainer = $('#' + $thisTab.data('tab'));
                    $targetTabContainer.addClass('active');
                    setHighchartWidth($targetTabContainer);
                    setActiveTabColors($tabGroup);
                }

            });

        }())

        $('#menuButton').on('mousedown', function() {
            $('#menu').toggleClass('block')
        });

        // tr highlight
        $('tr').not(':first, .accordionInner tr, #Photocell tr').on('click', function() {
            $('tr').removeClass('highlight');
            $(this).addClass('highlight');
        });
        // Accordion
        $('#content').on('click', '.accordionHeading', function() {
            $(this).toggleClass('highlight');
            $('.accordionHeading').not(this).removeClass('block');
            $(this).next('.accordionInner').toggleClass('block');
        });
        // Keep In View ('.keepSeen')
        var lDWidth;
        var lDMarginTop;
        if ($('.keepSeen').length > 0) {
            $(window).scroll(function() {
                var oTop = $('#content').offset().top;
                var scrollTop = $(window).scrollTop();
                var location = oTop - scrollTop + lDMarginTop;
                $('.keepSeen').each(function() {
                    if ($(this).hasClass('span2')) {
                        lDWidth = $('#content').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "") * .3777;
                        lDMarginTop = $('#content').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "") * .0155;
                        $(window).resize(function() {
                            lDWidth = $('#content').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "") * .3777;
                            lDMarginTop = $('#content').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "") * .0155;
                        });
                    }
                    else {
                        lDWidth = $('#content').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "") * .5753;
                        lDMarginTop = $('#content').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "") * .0155;
                        $(window).resize(function() {
                            lDWidth = $('#content').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "") * .5753;
                            lDMarginTop = $('#content').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "") * .0155;
                        });
                    }
                    if (location < 0) {
                        $(this).css({
                            'position': 'fixed',
                            'top': lDMarginTop,
                            'width': lDWidth
                        });
                        $(window).resize(function() {
                            $(this).css('width', lDWidth);
                        });
                    }
                    else {
                        $(this).css({
                            'position': 'relative',
                            'top': 'auto',
                            'width': '100%'
                        })
                    }
                });
            });
        }

        // ulLiMenu for #CentralPlant
        $('#CentralPlant .ulLiMenu').on('click', '.ulLiMenu > ul > li', function() {
            $('.ulLiMenu > ul > li').not(this).removeClass('active');
            $(this).toggleClass('active');
        });
        // HVAC Graphic Button
        $('#EquipmentTables').on('click', '.graphicHVACView', function() {
            if ($('tr.highlight').length > 0) {
                // var highlight = $('tr.highlight');
                // var highPath = highlight.children('td:first').attr('id');
                // modalWindow('/ord?station:%7C' + highPath + '%7Cview:pxViewEquip');
            }
            else {
                ///alert('Please choose a unit.');
            }
        });
        // Column responsive
        var startHTML;
        responsive();
        $(window).resize(function() {
            responsive();
            highchartsResize();
        });
        // Power Gage update max
        if ($('body').attr('id') == 'bodyPower') {
            var powerDataMax, energyDataMax;
            // var updateGageMax = setInterval(function() {
            //     if ($('h2').hasClass('highlight')) {
                    // var powerData = parseFloat($('#powerData').text().replace(/(?:[.](?=.*[.])|[^\d.])+/g, ""));
                    // powerDataMax = roundUpCool(powerData);
                    // //gauges.powerData.refresh(powerData, powerDataMax);
                    // gauges.powerData.setMaxValue(powerDataMax).setValue(powerData);
                    // var energyData = parseFloat($('#energyData').text().replace(/(?:[.](?=.*[.])|[^\d.])+/g, ""));
                    // energyDataMax = roundUpCool(energyData);
                    // //gauges.energyData.refresh(energyData, energyDataMax);
                    // gauges.energyData.setMaxValue(energyDataMax).setValue(energyData);
            //     }
            // }, 1000);
            // $('#powerTable').on('click', "#powerTable tr:not('first')", function() {
            //     var energyArray = [];
            //     $('#powerTable tr td:nth-child(4)').each(function() {
            //         energyArray.push($(this).text().replace(/(?:[.](?=.*[.])|[^\d.])+/g, ""));
            //     });
            //     var energyLargest = Math.max.apply(Math, energyArray);

            //     if (energyLargest < 11) {
            //         energyLargest = 10;
            //     }
            //     var powerArray = [];
            //     $('#powerTable tr td:nth-child(3)').each(function() {
            //         powerArray.push($(this).text().replace(/(?:[.](?=.*[.])|[^\d.])+/g, ""));
            //     });
            //     var powerLargest = Math.max.apply(Math, powerArray);

            //     if (powerLargest < 11) {
            //         powerLargest = 10;
            //     }
            //     var sem = $(this).find('td:first-child').text();
            //     var power = $(this).find('td:nth-child(3)').text().replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
            //     var energy = $(this).find('td:nth-child(4)').text().replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
            //     $('#powerGauges h2').text(sem);
            //     if (gauges.powerData.getMaxValue() !== powerLargest) {
            //       gauges.powerData.setMaxValue(powerLargest, true)
            //     }
            //     gauges.powerData.setValue(power);
            //     if (gauges.energyData.getMaxValue() !== energyLargest) {
            //       gauges.energyData.setMaxValue(energyLargest, true)
            //     }
            //     gauges.energyData.setValue(energy);
            // });

            // Site Data (Power Page) to gage
            $('#bodyPower #siteData').click(function() {
                $('#powerGauges h2').text('Site Data');
                var power = $('#bodyPower #siteData #powerData').text().replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
                var energy = $('#bodyPower #siteData #energyData').text().replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
                //gauges.powerData.refresh(parseFloat(power), powerDataMax);
                gauges.powerData.setMaxValue(power, true).setValue(parseFloat(power));
                //gauges.energyData.refresh(parseFloat(energy), energyDataMax);
                gauges.energyData.setMaxValue(energy, true).setValue(parseFloat(energy));
                $('#powerTable .highlight').removeClass('highlight');
            });
        }
        // HVAC Action Modal
        $('#bodyHVAC').on('click', '.overrideIcon', function() {
            var ord = $(this).attr('id');
            var nameValue = $(this).attr('value');
            var nameValue = nameValue.split('?');
            namePointClicked = nameValue[0];
            var dataDefnStr = nameValue[1];
            var hvacDataDefReqStr = $hvacUtil.prophetDataDefnReq($(this).attr('id'), dataDefnStr);

            $.niagara.postReq("testPath", hvacDataDefReqStr, function(obj) {
                var xml = obj;
                var hvac1Nodes = $hvacUtil.hvacgetDataDefnReq(xml);
                $('.actionModal').remove();

                $('body').append('<div class="actionMwrap"><div class="actionModal"><div class="checkboxingNow"></div><div class="closeIcon"></div><h3>' + namePointClicked + '</h3><select id="primary"></select></div></div>');
                for (var k = 0; k < hvac1Nodes[0].action.length; k++) {
                    var actionType = hvac1Nodes[0].parameterType[k];
                    actionType = actionType.replace(':', '');
                    $('.actionModal select').append('<option class="' + actionType + '" id="' + hvac1Nodes[0].data + '?' + ord + '">' + hvac1Nodes[0].action[k] + '</option>');
                }
                var timeSelector = '<div class="outering">' +
                    '<div class="rowing">' +
                    '<p>Hrs.</p>' +
                    '<select id="hourOptions">' +
                    '<option>0</option>' +
                    '<option>1</option>' +
                    '<option>2</option>' +
                    '<option>3</option>' +
                    '<option>4</option>' +
                    '<option>5</option>' +
                    '<option>6</option>' +
                    '<option>7</option>' +
                    '<option>8</option>' +
                    '<option>9</option>' +
                    '<option>10</option>' +
                    '<option>11</option>' +
                    '<option>12</option>' +
                    '</select>' +
                    '</div>' +
                    '<div class="rowing">' +
                    '<p>Mins.</p>' +
                    '<select id="minOptions">' +
                    '<option>0</option>' +
                    '<option>15</option>' +
                    '<option>30</option>' +
                    '<option>45</option>' +
                    '</select>' +
                    '</div>' +
                    '</div>';
                $('.actionModal select[id=primary]').focus(function() {
                    var selected = $(this).find('option:selected');
                    $('.actionModal input').remove();
                    $('.actionModal #boolean').remove();
                    if (selected.hasClass('numeric')) {
                        $('.actionModal').append('<input type="text" id="inputVal">');
                    }
                    else if (selected.hasClass('boolean')) {
                        $('.actionModal').append('<select id="boolean"><option>true</option><option>false</option></select>');
                    }
                    else if (selected.hasClass('controlNumericOverride')) {
                        $('.actionModal').append('<input type="text">');
                    }
                    else if (selected.hasClass('controlOverride')) {
                        $('.actionModal').append(timeSelector);
                    }
                    else if (selected.is('.controlEnumOverride', '.controlEnumOveride')) {
                        $('.actionModal').append('<select id="enumOptions"></select>' + timeSelector);
                    }

                });

                $('.actionModal select[id=primary]').change(function() {
                    var selected = $(this).find('option:selected');
                    $('.actionModal select').not('#primary').remove();
                    $('div.outering').remove();
                    $('.actionModal input').remove();
                    $('.actionModal #boolean').remove();
                    if (selected.hasClass('numeric')) {
                        $('.actionModal').append('<input type="text" id="inputVal">');
                    }
                    else if (selected.hasClass('boolean')) {
                        $('.actionModal').append('<select id="boolean"><option>true</option><option>false</option></select>');
                    }
                    else if (selected.hasClass('controlNumericOverride')) {
                        $('.actionModal').append('<input type="text">' + timeSelector);
                    }
                    else if (selected.is('.controlOverride')) {
                        $('.actionModal').append(timeSelector);
                    }
                    else if (selected.is('.controlEnumOverride', '.controlEnumOveride')) {

                        $('.actionModal').append('<select id="enumOptions"></select>' + timeSelector);
                        for (var i = 0; i < hvac1Nodes[0].rangeVal.length; i++) {
                            $('.actionModal select[id=enumOptions]').append('<option>' + hvac1Nodes[0].rangeVal[i] + '</option>');
                        }
                    }
                });

                $('.actionModal .closeIcon, .actionModal .checkboxingNow').click(function() {
                    setTimeout(function() {
                        $('.actionMwrap').remove();
                    }, 200);
                });

            });
        });
        // HCVAC settings column divider
        $('#bodyHVAC #EquipmentTables').on('click', 'table tr', function() {
            setTimeout(function() {
                var leftHeight = $('#colleft').height();
                var rightHeight = $('#colright').height();
                $('#colleft, #colright').removeClass('bordered');
                if (leftHeight >= rightHeight) {
                    $('#colleft').addClass('bordered');
                }
                else {
                    $('#colright').addClass('bordered');
                }
            }, 3000);
        });
        // veil functionality
        $('#EquipMentTablesTab').one('click', function() {
            $('.veil').each(function() {
                var veilWidth = $('#lightingData').css('width');
                var veilHeight = $('#lightingData').css('height');
                $(this).css({
                    'width': veilWidth,
                    'height': veilHeight,
                    'display': 'table'
                });
            });
        });
        //veil to equipment Table
        $('#mallUnits').on('click', function() {
            $('.veil').each(function() {
                var veilWidth = $('#lightingData').css('width');
                var veilHeight = $('#lightingData').css('height');
                $(this).css({
                    'width': veilWidth,
                    'height': veilHeight,
                    'display': 'table'
                });
            });
        });

         $('#tenantUnits').on('click', function() {
            $('.veil').each(function() {
                var veilWidth = $('#lightingData').css('width');
                var veilHeight = $('#lightingData').css('height');
                $(this).css({
                    'width': veilWidth,
                    'height': veilHeight,
                    'display': 'table'
                });
            });
        });

         $('#miscUnits').on('click', function() {
            $('.veil').each(function() {
                var veilWidth = $('#lightingData').css('width');
                var veilHeight = $('#lightingData').css('height');
                $(this).css({
                    'width': veilWidth,
                    'height': veilHeight,
                    'display': 'table'
                });
            });
        });

        $('tr, td, table').not('tr:first').click(function() {
            $(this).parents('section:first').find('.veil:first').css('display', 'none');
        });
        // $('#bodyHVAC #ScheduleOffsets button').click(function() {
        //     daPath = daPath.replace('DataTree', 'Schedules');
        //     var zone = $(this).text();
        //     modalWindow('/ord?station:%7C' + daPath + '/Offsets/HVAC/Zones/' + zone);
        // });
        // Lighting Panel Display Name edit
        $('body').on('click', '#lightingAcc > li > div', function() {
            $('#lightingAcc span.edit').remove();
            if ($(this).closest('section').attr('id') === 'Panel') {
            $(this).append('<span class="edit"></span>');
            }
            $('#lightingAcc').on('click', 'input', function(e) {
                e.stopPropagation();
            });
            $('#lightingAcc').on('click', '#lightingAcc > li > div', function() {
                if ($('#lightingAcc input').length > 0) {
                    $('#lightingAcc input').parent().empty().text(editingText);
                    $('span.checkboxingNow').removeClass('checkboxingNow').addClass('startEdit');
                    $('.XBox').remove();
                }
            });
            var editingText;
            $('#Panel #lightingAcc > li > div > span.edit').click(function() {
                var elem = $(this).prev(); // elem = $('p');
                editingText = elem.html();
                elem.empty();
                elem.html('<input type="text" value="' + editingText + '" id="panelTextBox">');
                $(this).parent().append('<span class="edit checkboxingNow" id="panelCheckingboxingnow"></span><span class="edit XBox"></span>');
                $(this).remove();
            });
            $('#lightingAcc').on('click', '#lightingAcc > li > div > span.XBox', function() {
                $('span.checkboxingNow').removeClass('checkboxingNow').addClass('startEdit');
                $('.XBox').remove();
            });
        });
        // HVAC DESCRIPTION EDIT
        (function() {
            var editingText;
          /*  $('#bodyHVAC').on('click', 'span.startEdit', function() {
                var elem = $(this).prev(); // elem = $('p');
                editingText = elem.html();
                elem.empty();
                elem.html('<input type="text" value="' + editingText + '" id="panelTextBox">');
                $(this).parent().append('<span class="edit checkboxingNow" id="panelCheckingboxingnow"></span><span class="edit XBox"></span>');
                $(this).remove();
            });
            $('#bodyHVAC').on('click', 'span.XBox', function() {
                $(this).parent().find('p').empty().text(editingText);
                $('span.checkboxingNow').removeClass('checkboxingNow').addClass('startEdit');
                $('.XBox').remove();
            });
            $('#bodyHVAC').on('click', 'span.checkboxingNow', function() {
                var newText = $(this).parent().find('#panelTextBox').val();
                $(this).parent().find('p').empty().text(newText);
                $('span.checkboxingNow').removeClass('checkboxingNow').addClass('startEdit');
                $('.XBox').remove();
                var currentUnit = $('tr.highlight td.one').attr('id');
                var setAttrRes = $util.setAttributesXML(currentUnit, "disName", newText)
                $util.setAttributes(setAttrRes, currentUnit);
                setTimeout(function() {
                    equpTablez.mall(function() {
                        addHighlight($('#MallUnits tr'), currentUnit)
                    });
                    equpTablez.tenant(function() {
                        addHighlight($('#TenantUnits tr'), currentUnit)
                    });
                    equpTablez.misc(function() {
                        addHighlight($('#MiscellaneousUnits tr'), currentUnit)
                    });
                }, 1000)
            });*/

            function addHighlight(arr, id) {
                $(arr).each(function(i, e) {
                    var hereId = $(e).find('td.one').attr('id');
                    if (hereId === id) {
                        $(e).addClass('highlight');
                    }
                });
            }
        })();

        $('#cPlants').click(function() { // get node for central plant pxView on click

            var selectedNodeId = getSelectedNodeId()

            var req = {
                callback: cPlantPxView,
                method1: {
                    method: 'getNode',
                    nodeId: selectedNodeId + "/HVAC"
                }
            }

            var xml = dataEye.getData(req, true);

            function cPlantPxView(res) {
                var attrArr = res.MethodResponse.node.attributes.attr,
                    pxPath;
                $.each(attrArr, function(i, e) {
                    if (e['@n'] === 'disCpView') {
                        pxPath = "/ord?station:%7C" + e['#cdata'] + "%7Cview:pxViewEquip";
                        return false;
                    }
                });
                if (pxPath) {
                    $('#CentralPlant #plantAcc .graphicHVACView').parent('li').remove();
                    $('#CentralPlant #plantAcc').prepend('<li><a style="width: 99.9%; padding: 14px 0px; border-radius: 0; margin: 0; display: block;text-align: center;cursor: pointer;" class="btn-primary graphicHVACView" target="_blank" href="' + pxPath + '">Graphic</a></li>');
                }
            }
        });

        veilSize();

        // End $(document).ready()
    });



    function roundUpCool(x) {
        x = parseInt(x);
        var y = Math.pow(10, x.toString().length - 1);
        x = (x / y);
        x = Math.ceil(x);
        x = x * y;
        return x;
    }

    function veilSize(){
        $('.veil').each(function(){
            $(this).css({
                height: $(this).parent().height(),
                width: $(this).parent().width()
            });
        });
    }

    function responsive() {
        contentWidth = $('#content').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
        veilSize();
        if (contentWidth <= 1300) { // Home page revert, see else of next if...
            $('.perfect').each(function() {
                startHTML = $(this).html();
                var groupedHTML = startHTML.split('<div class="group');
                var finalHTML = '';
                for (var i = 0; i < groupedHTML.length; i++) {
                    finalHTML = finalHTML + '<div class="group' + groupedHTML[i] + '</div><div class="column">';
                }
                finalHTML = finalHTML.replace('<div class="group', '').replace('</div>', '').replace(/column/g, 'column responsified');
                var L = finalHTML.lastIndexOf('<');
                finalHTML = finalHTML.slice(0, L);
                $(this).replaceWith(finalHTML);
            });
            $('#unitSettings1').css({
                'position': 'absolute',
                'left': '9999px',
                'top': '0'
            }).removeClass('keepSeen');
            $('#unitSettings1').parent().hide();
            $('#lightingData, .detailPanel').css({
                'position': 'absolute',
                'left': '9999px',
                'top': '0'
            }).removeClass('keepSeen');

            $('#lightingData, .detailPanel').parent().hide();
        }
        if (contentWidth <= 1300 && contentWidth > 780) { // 4 columns
            $('.gauge2.share2, .infoSection, .circleGroup.share2').css({
                'float': '',
                'margin': '',
                'width': ''
            });
        }
        // else if (contentWidth <= 1100 && contentWidth > 780) { // 3 columns
        //     $('.gauge2.share2, .infoSection, .circleGroup.share2').css({
        //         'float': '',
        //         'margin': '',
        //         'width': ''
        //     });
        // }
        else if (contentWidth <= 780 && contentWidth > 500) { // 2 columns
            $('.gauge2.share2, .infoSection, .circleGroup.share2').css({
                'float': '',
                'margin': '',
                'width': ''
            });
            headerWidth = $('header:first').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
        }
        else if (contentWidth <= 500 && contentWidth > 390) { // 1 column
            $('.gauge2.share2, .infoSection, .circleGroup.share2').css({
                'float': 'none',
                'margin': '0 auto',
                'width': ''
            });
            headerWidth = $('header:first').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
            bodyWidth = $('body').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
            if (bodyWidth > headerWidth) {
                $('header:first').css('width', bodyWidth + 'px');
            }
            $('iframe').each(function() {
                $(this).parent().prev('.subMenu2').show();
            });
        }
        else if (contentWidth <= 390) {
            $('iframe').each(function() {
                $(this).parent().prev('.subMenu2').hide();
            });
            // $('.gauge2.share2, .infoSection, .circleGroup.share2').css({
            //     'float': 'none',
            //     'margin': '0 auto',
            //     'width': '65%'
            // });
            headerWidth = $('header:first').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
            bodyWidth = $('body').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
            if (bodyWidth > headerWidth) {
                $('header:first').css('width', bodyWidth + 'px');
            }
        }
        else { // contentWidth > 1300
            $('.column').css({
                'width': '',
                clear: ''
            });
            $('.gauge2.share2, .infoSection, .circleGroup.share2').css({
                'float': '',
                'margin': '',
                'width': ''
            });
            if ($('.responsified').length > 0) {
                $('.responsified:first').replaceWith('<div class="column perfect mb">' + startHTML + '</div>');
                $('.responsified').remove();
            }
            $('#unitSettings1').addClass('keepSeen').css({
                'position': '',
                'left': '',
                'top': ''
            });
            $('#unitSettings1').parent().show();
            $('#lightingData, .detailPanel').addClass('keepSeen').css({
                'position': '',
                'left': '',
                'top': ''
            });
            $('#lightingData, .detailPanel').parent().show();
            $('#lightingDataLiNow').remove();
            $('iframe').css('max-width', '');
            $('#settingsRow').remove();
        }
    }
    function highchartsResize() {
        if ( typeof Highcharts !== 'undefined' ) {
            var chartsOnPage = Highcharts.charts;
            _.each(chartsOnPage, function(chart) {
                chart.setSize(
                    $(chart.container).parent().width()
                );
            });
        }
    }
}).call(this);

// Global functions:

function setCookie(c_name, value, exdays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + exdays);
    var c_value = escape(value) + ((exdays == null) ? "" : "; expires=" + exdate.toUTCString());
    document.cookie = c_name + "=" + c_value;
}

function getCookie(c_name) {
    var i, x, y, ARRcookies = document.cookie.split(";");
    for (i = 0; i < ARRcookies.length; i++) {
        x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
        y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
        x = x.replace(/^\s+|\s+$/g, "");
        if (x == c_name) {
            return unescape(y);
        }
    }
}

function readNotPermissed() {
    $('body *').not('#RWIContainer, #RWIContainer *').addClass('hiddenByNoRead');
}

function writeNotPermissed() {
    $('.share2 select').not('#overrideData, #photocellInfoData, #photocellInnerData, #specialEventData').attr({
        'disabled': 'disabled',
        'style': 'style="pointer-events: none; cursor: default;'
    });
    $('#bodySchedule').find('#content').prepend('<div style="height: 100%; width: 100%; position: absolute; z-index: 99999;"><p style="font-size: 13px;">At this time, you do not have write priviledges.</p></div>');
}

function invokeNotPermissed() {
    $('.share2 select').attr({
        'disabled': 'disabled',
        'style': 'style="pointer-events: none; cursor: default;'
    });
    $('head').append('<style id="invokeStyles" type="text/css">.overrideIcon {display: none !important; visibility: hidden !important;} .edit {display: none !important; visibility: hidden !important;}</style>');
    $('#bodySchedule').find('#content').prepend('<div style="height: 100%; width: 100%; position: absolute; z-index: 99999;"><p style="font-size: 13px; float: right;">At this time, you do not have invoke priviledges.</p></div>');
}

function propName(prop) {return prop.replace(/([a-z])([A-Z0-9])/g, '$1 $2');}

function setSelectedNodeId(nodeId) {
    setCookie('selectedNodeId+'+getCookie('sessionUser'), nodeId, 7);
}
function getSelectedNodeId() {


    return window.location.href.split("url=")[1];
}

function modalWindow(url) {
    $('#modalContainer').remove();
    $('body').append('<div style="z-index: 9999" id="modalContainer"><iframe id="HVACGraphiciframe" name="HVACGraphiciframe" src="' + url + '"></iframe><div class="closeIcon"></div></div>');
    var contentWidthHere = $('#content').css('width').replace(/(?:[.](?=.*[.])|[^\d.])+/g, "");
    if (contentWidthHere < 750) {
        $('#HVACGraphiciframe').css({
            //'width': window.innerWidth + "px",
            'margin-left': -((window.innerWidth + 240) / 2) + "px",
            'margin-top': 0,
            'overflow': 'scroll'
        })
        $('#modalContainer .closeIcon').css({
            'margin-left': ((window.innerWidth / 2) - 26) + "px"
        });
    }
    $('#modalContainer .closeIcon').click(function() {
        $('#modalContainer').remove();
    });
}
