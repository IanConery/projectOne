
/******************************************************************
  JS for Sun Position	
  Controlco Inc
  Author: Deepti Phadnis
 ******************************************************************/
 jQuery(document).ready(function($) {

 var loc = location.search.substring(1, location.search.length);
 
    var param_value = false;
 var params = loc.split("&");
 
 param_name = params[0].substring(0,params[0].indexOf('='));
 param_value = params[0].substring(params[0].indexOf('=')+1);
 
 var output = [];
  var $data = {
   regionPath : param_value,
   scheduleType : "HVAC",
   scheduleName : param_value
 };
 var $currWeeklySchedule = [];
 var $newWeeklySchedule = [];
    var maskHeight = 600;
    var maskWidth = $(document).width();
    var winH = 500;
    var winW = $(document).width();
    
    var hvacList = [];
    var lightingList = [];
    var generalList = [];
    
var oldEventName="";
var newEventName="";

var windLoc = window.location+"";
var schedName="";

if((windLoc.indexOf("addEvent"))>0)
{	
	$util.loadAddPage();
	schedName = ""+params[0].substring(params[0].indexOf('=')+1);
	$data.scheduleName = schedName;
}
else if(windLoc.indexOf("editEvent")>0)
{	
    var json = ""+params[1].substring(params[1].indexOf('=')+1);
    json = json.replace(new RegExp("%22", 'g'), "\"");
    var obj = jQuery.parseJSON(json);
    $util.loadEditPage(param_value,obj);
	schedName = ""+params[0].substring(params[0].indexOf('=')+1);
	$data.scheduleName = schedName;

}
else if(windLoc.indexOf("indexRelative")>0 && params[1])
{	
	schedName = ""+params[1].substring(params[1].indexOf('=')+1);
	$("#hvac_list").val(schedName);
}	


 /*$("#sunPositionSave").click(function()
{
 alert($("#enable").val() +"," +$("#longitude").val()+"," +$("#latitude").val() +"," +$("#sunrise").val() +"," +$("#sunset").val());
});*/



 $.niagara.getSunPosition($data.scheduleName,function(obj){
	$("#enable").val(obj.enable);
	$("#latitude").val(obj.latitude);
	$("#longitude").val(obj.longitude);
	$("#sunriseOffset").val(obj.sunriseOffset);
	$("#sunsetOffset").val(obj.sunsetOffset);
	$("#sunrise").text(obj.sunrise);
	$("#sunset").text(obj.sunset);
	
 });
 
 $("#addEventPage").click(function()
		 {
	 var alink = "addEvent.html?ord="+$data.scheduleName; 
	 $("#addEventPage").attr('href',alink);
		 });
 
 
 
 $("#backButton").click(function()
		 {
	 sethref("#backButton");
	 	
});

 
 

 
 $("#sunPositionSave").click(function(){
	 
  var enable = $("#enable").val();
  var longitude = $("#longitude").val();
  var latitude = $("#latitude").val();
  var sunriseOffset = $("#sunriseOffset").val();
  var sunsetOffset = $("#sunsetOffset").val();
  
  if(isNumber(longitude) && isNumber(latitude) && isNumber(sunriseOffset) && isNumber(sunsetOffset))
	  {
	  	if (inRange(longitude) && inRange(latitude))
	  	{	
	    $.niagara.saveSunPosition($data.scheduleName,enable,longitude,latitude,sunriseOffset,sunsetOffset,function(obj){
	        if(obj.value!= null)
	          {
	         if(obj.value == "false")
	         {
	          alert("Please check inputs");
	         }
	         else{
	        		alert("Data Saved!");
	        	 	$("#enable").val(obj.enable);
	        		$("#latitude").val(obj.latitude);
	        		$("#longitude").val(obj.longitude);
	        		$("#sunriseOffset").val(obj.sunriseOffset);
	        		$("#sunsetOffset").val(obj.sunsetOffset);
	        		$("#sunrise").text(obj.sunrise);
	        		$("#sunset").text(obj.sunset);
	         }
	          }
	        //sethref("#sunPositionSave");
	        });
	  	}
	  	else
	  		{
	  		alert("Not in range. Please check imputs");
	  		}
	  }
  else
	  {
	  alert("Not a number. Please check imputs");
	  }
  
 
 }); 
 

 function isNumber(n) {
	  return !isNaN(parseFloat(n)) && isFinite(n);
	} 
 function inRange(n) {
	  if(n>-181 && n<181)
		  {
		  	return true;
		  }
	  else
		  return false;
	} 

 
function sethref(obj)
{
	
	 var arr = params[0].split("/");
		var sched = arr[arr.length-1];
		params[0]="";
		console.log(arr);
		for(var i=0;i<arr.length-1;i++)
		{	
			if(i<arr.length-2)
				params[0] = params[0]+arr[i]+"/";
			else
				params[0] = params[0]+arr[i];
		}
		var alink = "indexRelative.html?"+params[0]+"&sched="+sched;
		$(obj).attr('href',alink);	
		location.href = alink;

}
     
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     
    $('#mask').click(function () {
        $(this).hide();
        $('.window').hide();
    });         

 /* Get the metering present datapoint and store its result */
  
 $(window).unload(function() {
 // clearInterval(intr);
 });
 
 /*var intr = setInterval(function(){
  var date = $util.normalizeDate();
  $util.getMonthlySchedule(date,$data.scheduleName);
 },
 20000);*/
 
 //$.niagara.BatchPoll.printPollList();
});



 