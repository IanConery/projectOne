$(document).ready(function () {
    $('#HVAC').click(function () {
    $('ul.the_menu').slideToggle('fast');
    });
    
    $('#Lighting').click(function () {
    $('ul.light_menu').slideToggle('fast');
    });
    
});