/******************************************************************
 * control-panel.js
 *
 * This Javascript code does all the implementation of the generic
 * control panel code & methods that apply to the panel as a whole.
 * (such as the alerts slider pane which is used on all parts of the
 * panel and the stationPoints object which holds all the station's
 * datapoint paths for the entire panel.
 *
 * This code is jQuery 1.4.X dependent and also dependent on the
 * jquery.niagara-ajax.X.js jQuery plug-in (which must be loaded 
 * first)for Niagara/Ajax communication with the Niagara server.
 ******************************************************************/
;(function( $ ) {

	//$.ajaxSetup({cache: false});
	
	/* Set callbacks for the $.niagaraError object in the jquery.niagara-ajax plug-in... */
	(function() {
		try {
			
			$.niagara.Alert.setUpdateLog(function() {
				//console.log("Alerts main children = " + $('#alertsMain').children().length);
				if($('#alertsMain').children().length > $.niagara.stationData.LOG_BUFFER_SZ)
				{
					$('#alertsMain').children().remove();
				}
			});
			
			$.niagara.Alert.setAlertCallback(function(alrt, status, xhr, classes) {
				$.niagara.Alert.updateLog();
				$('#alertsMain').append('<div class="alert-entry alarm ' + classes + '"><p>' + alrt + '</p></div>');
				$('#alertBtnImg').attr('src', 'images/alertLed-animation-20.gif');
				//$.panel.modalBusy('Network Unavailable');
			});
			
			$.niagara.Alert.setInfoCallback(function(info, status, xhr, classes) {
				$.niagara.Alert.updateLog();
				$('#alertsMain').append('<div class="alert-entry info ' + classes + '"><p>' + info + '</p></div>');
				$('#alertBtnImg').attr('src', 'images/infoLED.gif');
			}); 
			
			$.niagara.Alert.setExceptionCallback(function(ex) {
				$.niagara.Alert.updateLog();
				$('#alertsMain').append('<div class="alert-entry alarm"><p>A System Error Occurred:' + ex + '</p></div>');
				$('#alertBtnImg').attr('src', 'images/alertLed-animation-20.gif');
			});	
		}
		catch(ex) {
			alert("A System Error Occurred: You must restart your console browser!");
		}
	})();
	

	$.panel = {
		
		/*************************************************************
		 * stationPoints
		 *
		 * When we actually get to the point where we are hooking up
		 * this code to Niagara/Webeye we may want to set all these
		 * with an initialization method, etc. For now, this is how
		 * we do it.
		 *
		 *************************************************************/
		stationPoints : {
			/**********************
			 * Paths to datapoints
			 **********************/
			/* Path prefixes */
			GS_PRE : 'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.',
			DO_PRE : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.',
			PS_PRE : 'station.Drivers.ModbusTcpNetwork.plc.points.PlantSetup.',
			COMM_PRE : 'station.Drivers.ModbusTcpNetwork.plc.points.CommSetup.',
			COMM_CRIT : 'station.Drivers.ModbusTcpNetwork.plc.points.CommSetupCritical.',
			FS_PRE : 'station.Drivers.ModbusTcpNetwork.plc.points.FactorySetup.',
			AS_PRE : 'station.Drivers.ModbusTcpNetwork.plc.points.AlarmStatus.',
			READ_APX : '.out.value',
			WRITE_APX : '.in16',
			
			
			
			MAIN_PATH : 'station.TouchHome.Main',
			PILOT_PATH : 'station.TouchHome.Pilot',
			POWER_PATH : 'station.TouchHome.Power',
			MODULATE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.ZIC_BLM_RAM',
			FLAME_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.BI_BMS_FLMS',
			SETPOINT_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.BQ_BLRH',
			SETPOINT_WRITE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.BQ_BLRH',
			DEADBAND_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.CommSetupCritical.BIC_BLRH_DB',
			DEADBAND_WRITE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.CommSetupCritical.BIC_BLRH_DB',
/*			FIRING_RATE_PATH : 'station.TouchHome.FiringRate.out.value', */
			FIRING_RATE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.ZIC_BLM_CO_FR',
			FIRING_RATE_WRITE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.ZIC_BLM_CO_FR',

			HIGH_FIRE_MODE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.ZSH_PRG_BMS',
			LOW_FIRE_MODE_PATH :'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.ZSL_IGN_BMS',

//			MANUAL_MODE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.ZIC_BLM_AUTO',
//			MANUAL_MODE_WRITE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.ZIC_BLM_AUTO',
//			AUTO_MODE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.ZIC_BLM_AUTO',
//			AUTO_MODE_WRITE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.ZIC_BLM_AUTO',

			PROCESS_VARIABLE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.BIC_BLRH_PV',
			//SP_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.SIC_CAF_CO',
			SP_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.BQ_BLRH',
			PV_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.BIC_BLRH_PV',

			//FUEL_VALVE       ZIC_GCV_CO or ZIC_OCV_CO - DailyOperation

			FIRE_RATE_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.ZIC_BLM_FRRL',
			AIR_DAMPER_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.ZIC_CAD_CO',
			VFD_SPEED_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.SIC_CAF_CO',
			FUEL_VALVE_GAS_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.ZIC_GCV_CO',
			FUEL_VALVE_OIL_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.DailyOperation.ZIC_OCV_CO',
			FUEL_VALVE_PATH : null,
			RUN_HOURS_PATH : 'station.Drivers.ModbusTcpNetwork.plc.points.GeneralStatus.BIC_BLRH_PV',
			
			/****************
			 * Trend Times
			 ****************/
			TREND_LAST_8_HOURS : 'current8hours',
			TREND_LAST_4_HOURS : 'current4hours',
			TREND_LAST_2_HOURS : 'current2hours',
			TREND_LAST_1_HOURS : 'current1hours',
			TREND_LAST_30_MIN : 'current30minutes',
			TREND_LAST_SEVEN_DAYS : 'current7days',			
			
			/****************
			 * Commissioning
			 ****************/
			 CADOUTPUT : 'station.path.CADOUTPUT',
			 CAFOUTPUT : 'station.path.CAFOUTPUT',
			 GCVOUTPUT : 'station.path.GCVOUTPUT',
			 FGDOUTPUT : 'station.path.FGDOUTPUT',
			 ODOUTPUT : 'station.path.ODOUTPUT',
			 DCOUTPUT : 'station.path.DCOUTPUT',

             /************
             *SAVE STATION
             ************/
             SAVESTATION : 'station.save'
		},	
		
		/************************************************************
		 * CUSTOM POLLING FUNCTIONS
		 *
		 * This section shows examples of how you can create your
		 * own custom methods for polling values and supplying your
		 * own callback function to implement your custom logic.
		 * In most cases the standard $.niagara.resultHandler() will
		 * be sufficient for processing results from the server but
		 * where you need more complex logic, this is how you should
		 * implement it.
		 *
		 * If you are creating your code in a separate .js file, then
		 * add your custom function to "$.panel", e.g.:
		 *
		 * $.panel.myCustomFunction = function() {
		 *   ...
		 * }
		 ***************************************************************/
		 
		/************************************************************
		 * pollMainBurnerAnimation
		 * 
		 * Toggle the Main burner flame graphic
		 ************************************************************/			 
		 pollMainBurner : function(interval) {
			
			$.niagara.Poll.startPoll($.panel.stationPoints.MAIN_PATH, interval, '.main-img', function (result, status, xhr) {
				if (result && $.niagara.checkSuccess(xhr)) {
					$.niagara.resultHandler('.main-img', $.panel.stationPoints.MAIN_PATH, result.value, result.status, null);					
					if (result.value == "on" || result.value == 1 || result.value == "true") {
						//console.log("Result true: Burner setting imgOn...");
						$('#burnerAnimatedPilot').css({ "visibility" : "hidden"});
						$('#burnerAnimatedFlame').css({ "visibility" : "visible"});
					}
					else {
						//console.log("Result false: Burner setting imgOff...");
						$('#burnerAnimatedFlame').css({ "visibility" : "hidden"});
					}
				}
			}, null);
		},
				
		/************************************************************
		 * pollPilotBurner
		 * 
		 * Toggle the Pilot flame graphic
		 ************************************************************/
		 pollPilotBurner : function(interval) {			
			$.niagara.Poll.startPoll($.panel.stationPoints.PILOT_PATH, interval, '.pilot-img', function (result, status, xhr) {
				if (result && $.niagara.checkSuccess(xhr)) {
					$.niagara.resultHandler('.pilot-img', $.panel.stationPoints.PILOT_PATH, result.value, result.status, null);					
					if (result.value == "on" || result.value == 1 || result.value == "true") {
						//console.log("Result true: Pilot setting imgOn...");
						$('#burnerAnimatedFlame').css({ "visibility" : "hidden"});
						$('#burnerAnimatedPilot').css({ "visibility" : "visible"});
					}
					else {
						//console.log("Result false: Pilot setting imgOff...");
						$('#burnerAnimatedPilot').css({ "visibility" : "hidden"});
					}
				}
			}, null);
		},
		
		modalDialog	: function(opts) {
		
			var html = '<div class="modal-dialog"><p>' + opts.msg + '</p><button class="modal-btn" id="modalOk">' + opts.okTxt + '</button>' +
					   '<button class="modal-btn" id="modalCancel">' + opts.cancelTxt + '</button></div>';				   
			jQuery.fancybox(
			html,
			{
				'autoDimensions': 	true,			
				'modal'			:	true,
				'transitionIn'	:	'fade',
				'transitionOut'	:	'fade',
				'speedIn'		:	300, 
				'speedOut'		:	100, 
				'overlayShow'	:	false,
				'title' 		:   opts.title,
				
				'onStart'		:   function() {
					$('#fancybox-outer').css({ 'backgroundColor' : 'red'});
				},
								
				'onComplete' : function() {
					var ok = this.okay;
					var cncl = this.cancel;					
					$('#modalOk').click(function() {
						//console.log(onOkay);
						if (ok)
							ok();
						$.fancybox.close();
					});
					
					$('#modalCancel').click(function() {
						//console.log(onCancel);
						if (cncl)
							cncl();
						$.fancybox.close();
					});
				},
				'onClosed' : function() {
					$('#fancybox-outer').css({ 'backgroundColor' : '#FFF'});
				},
				'okay'	 : opts.okFunc,
				'cancel'   : opts.cancelFunc
			});
		},
		
		/*********************************************************
		 * fancyboxBusy
		 *
		 * This will create a modal loading/saving window with the
		 * spinning wheel graphic and the user supplied text using
		 * a Fancybox.
		 **********************************************************/
		fancyboxBusy : function(text) {		
			var html = '<div style="position: relative; top: 10px; left: 0;" id="loading"><img style="margin-left: auto; margin-right: auto; display: block;" src="images/loading.gif" /><br/><h2 style="text-align: center; margin-top: 0; margin-left: auto; margin-right: auto; padding-left: 7px; color: #f2f2f2;">' + text + '...</h2></div>';
			
			jQuery.fancybox(
			html,
			{
				'autoDimensions': 	false,
				'height'		:   80,
				'width'			:	120,
				'modal'			:	true,
				'transitionIn'	:	'fade',
				'transitionOut'	:	'fade',
				'speedIn'		:	300, 
				'speedOut'		:	100, 
				'overlayShow'	:	false,
				'onStart'		:   function() {
					$('#fancybox-outer').css({ 'backgroundColor' : 'transparent'});					
					$('#fancybox-inner').css({ 'opacity' : '0.8'});
					setTimeout(function() {
						$.fancybox.close();
					},
					120000);
				},
				'onClosed' : function() {
					$('#fancybox-outer').css({ 'background' : '#FFF'});
					$('#fancybox-inner').css({ 'opacity' : '1.0'});					
				}				
			});
		},
		
		/**************************************************
		 * fancyboxDone
		 *
		 * Gets rid of the modal loading/saving window for
		 * the fancyboxBusy method, above.
		 **************************************************/
		fancyboxDone : function() {
			$.fancybox.close();
		},
		
 	   /************************************************************************* 
		* modalBusy
		*
		* Creates a busy loading/saving icon and text that will work for anything,
		* including over the top of a fancybox. Since a fancybox is already modal, 
		* we need to create a transparent mask that is the dimensions of the 
		* document window so that we cover it completley, to keep the fancybox 
		* (or anything else) modal - the user cannot change any of the controls or 
		* data while we're trying to write.
		***************************************************************************/
		modalBusy : function(text, interval) {
			if (!$.exists('#loadingMask')) {
				var html = '<div style="position: absolute; top: 0; left: 0; z-index:9995;" id="loadingMask"><div style="background-color: #333; opacity: 0.8; height: 90px; width: 120px; position: absolute; top: 36%; left: 43%; z-index:9997;" id="loading"><img style="margin-top: 7px; margin-left: auto; margin-right: auto; display: block; z-index:9999; opacity: 1;" src="images/loading.gif" /><br/><h2 style="text-align: center; margin-top: 0; margin-left: auto; margin-right: auto; padding-left: 7px; color: #FFF; opacity: 1; z-index:9999">' + text + '...</h2></div></div>';
				$('body').append(html);
				//Get the screen height and width  
				var maskHeight = $(document).height() + 'px';
				//console.log(maskHeight);
				var windowWidth = $(window).width();  
				var maskWidth = windowWidth + 'px';
				var windowHeight = $(window).height();  
				//console.log(maskWidth);
				
				/* We have to center the inner loading window now... */
				$('#loadingMask').css({ 'height' : maskHeight, 'width' : maskWidth });
				var loadHeight = windowHeight / 2 - $('#loading').height() / 2;
				loadHeight += 'px';
				//console.log(loadHeight);
				var loadWidth = windowWidth / 2 - $('#loading').width() / 2;
				loadWidth += 'px';
				//console.log(loadWidth);
				$('#loading').css({ 'top' : loadHeight, 'left' : loadWidth });
				// timeout and remove after two minutes...
				var intvl = 60000;
				if(interval)
					intvl = interval;
				setTimeout(function() {
					$.panel.modalDone();
				},
				intvl);
			}
		},
		
	   /*********************************************************************
		* modalDone
		*
		* This just removes the loading/saving icon and text window from a
		* fancybox when you're done, on fail, etc.
		*********************************************************************/
		modalDone : function() {
			$('#loadingMask').fadeOut(400, function() { 
				$(this).remove();				
			});
		},
		
		createLogOutBtn : function() {
			if (!$.exists('#logOut')) {
				var html = '<div style="position: absolute; top: 540px; left: 660px; z-index:20;" id="logOut"><button style="padding-top: 6px" id="btnLogOut" class="standard-button-large">Log Out</button></div>';
				$('#sliderBlock').append(html);
				$('#btnLogOut').click(function() {
					$.panel.modalBusy('Logging Out');
					//document.location.href=$.niagara.stationData.LOGOUT;
    				try {
							var url = '/csi3/logout';
							$.get(url);
                            setTimeout(function()
                            {location.reload();}
                            ,6000);
    //						$.niagara.n_ajax(url, null, null, null, $.niagara.stationData.DEFAULT_DT,null);
	    			}
		    		catch(ex) {
			    		$.niagara.Alert.exception(ex);
				    }
				});
			}
		}
	}
		
	/*****************************************************************************
	 * ALERTS PANE
	 * This is where we do the alerts pane creation. 
	 *****************************************************************************/
	$('#btnShowAlerts').click(function() {										  	
		$('#alertsPane').slideToggle();
	});
			
	$('#clear').click(function() {
		$('#alertsMain').empty();
		$('#alertBtnImg').attr('src', 'images/infoLed-1.png');
	});
			
	$('#close').click(function() {
		$('#alertsPane').slideToggle();
	});

	/**************************************************************************
	* ALARMS PANE
	*
	***************************************************************************/
	var $points = $.panel.stationPoints;	
	/* Alarms Status*/
	function checkAlarm(value,id,name)
	{
		if(value)
			$addAlarm(id,name);
		else
		{
			var divId = document.getElementById(id);
			if(divId!=null)
				$removeAlarm(id);
		}
	}
	
	function $addAlarm(id, name)
	{
	      var ni = document.getElementById('activeAlarms1');
		  var newdiv = document.createElement('div');
		  newdiv.setAttribute('id',id);
		  newdiv.setAttribute('class','alarms-entry');
		  var append = "<p class='alarms-label'>"+ name + ":</p><img class='alarms-img-val' src='images/red-LED-20.png'></img>";
		  newdiv.innerHTML = append;
		  ni.appendChild(newdiv);
	}
	$('#resetAlarm').click(function(){
          $.niagaraQuickWrite($points.DO_PRE+'XS_ALRM_RST',true,
          function(obj)
          {
            setTimeout(function(){
                $.niagaraQuickWrite($points.DO_PRE+'XS_ALRM_RST',false);
            },5000);
          });
    });
	function $removeAlarm(id)
	{
		var d = document.getElementById('activeAlarms1');
  		var olddiv = document.getElementById(id);
		if(olddiv != null)
  			d.removeChild(olddiv);
	}	
		function $createAlarmsFancybox(opts)
		{
			$('#activeAlarms').fancybox(
				{
					'autoDimensions': 	false,
					'width'			:   710,
					'height'		:   375,
					'transitionIn'	:	'fade',
					'transitionOut'	:	'fade',
					'hideOnContentClick' : 'true',
					'speedIn'		:	400, 
					'speedOut'		:	200, 
					'title' 		:   'Active Alarms',
					
					'onStart' : function() {
						$.niagara.BatchPoll.batchSubscribe({ 'subscribe' : opts.vals });
						$('#activeAlarms').css( { 'display' : 'block' } );
					},
		
					'onClosed' : function() {
						$.niagara.BatchPoll.batchUnsubscribe({ 'subscribe' : opts.vals});
						$('#activeAlarms').css( { 'display' : 'none' } );
						
						var arr = opts.vals;
						for(var i=0;i<arr.length;i++)
						{
							$removeAlarm(opts.vals[i].selector);
						}
					}
				}).trigger('click');			
		}
	$(window).unload(function() {
		if ($.panel)
			$.panel = null;
	});
	
})(jQuery);