
/******************************************************************
 JS used for adding Events
  Controlco Inc
  Author: Deepti Phadnis
 ******************************************************************/
 jQuery(document).ready(function($) {

 var loc = location.search.substring(1, location.search.length);
 
    var param_value = false;
 var params = loc.split("&");
 param_name = params[0].substring(0,params[0].indexOf('='));
 param_value = params[0].substring(params[0].indexOf('=')+1);
  
 var output = [];
  var $data = {
   regionPath : param_value,
   scheduleType : "HVAC",
   scheduleName : "HvacMall"
 };
 var $currWeeklySchedule = [];
 var $newWeeklySchedule = [];
    var maskHeight = 600;
    var maskWidth = $(document).width();
    var winH = 500;
    var winW = $(document).width();
    
    var hvacList = [];
    var lightingList = [];
    var generalList = [];
    
var oldEventName="";
var newEventName="";
$util.setValueEditBox();

var windLoc = window.location+"";
var schedName="";

if((windLoc.indexOf("addEvent"))>0)
{	
	$util.loadAddPage();
	schedName = ""+params[0].substring(params[0].indexOf('=')+1);
	$data.scheduleName = schedName;
}
else if(windLoc.indexOf("editEvent")>0)
{	
    var json = ""+params[1].substring(params[1].indexOf('=')+1);
    json = json.replace(new RegExp("%22", 'g'), "\"");
    var obj = jQuery.parseJSON(json);
    $util.loadEditPage(param_value,obj);
	schedName = ""+params[0].substring(params[0].indexOf('=')+1);
	$data.scheduleName = schedName;

}
else if(windLoc.indexOf("indexRelative")>0 && params[1])
{	
	schedName = ""+params[1].substring(params[1].indexOf('=')+1);
	$("#hvac_list").val(schedName);
}	

$.niagara.getEventClasses($data.scheduleName,function(obj)
		{
		if(obj != null)
		{
			var str = "";
			for(var i = 0;i<obj.value.length;i=i+2)
			{	
			str = str + '<option value="'+obj.value[i]+'">'+obj.value[i+1]+'</option>'; 
			}
			$("#addEventClass").append(str);
		}
		 $util.loadAddEvents();

		});

 $util.loadAddEvents();
 $("#addEventPage").click(function()
		 {
	 var alink = "addEvent.html?ord="+$data.scheduleName; 
	 $("#addEventPage").attr('href',alink);
		 });
 $("#backButton").click(function()
		 {
	 sethref("#backButton");
	 	
});

 
 
/******************Select event to add from dropdown*************************************************/ 
 $("select#addEventType").change(function(){
  $util.resetSkipDays();
  $util.resetTradEventOffset();
  $util.resetWeekly();
  $util.resetMonthly();
  
  $("#AddButtonDiv").hide();
  var i = $("#addEventType").val();
  if(i==0)
  {
   $("#weekAndDay").hide();/* One time*/
   $("#oneTime").show();
   $("#addSkipDays").hide();
   $("#addDateRange").hide();
   $("#addTradHours").hide();
   $("#addWeeklyEvent").hide();
   $("#addMonthlyEvent").hide();
   $("#addYearlyEvent").hide();
   
  }
  else if(i==1)
  {
   $("#weekAndDay").show();/* Week and Day*/
   $("#oneTime").hide();
   $("#addSkipDays").show();
   $("#addDateRange").hide();
   $("#addTradHours").hide();
   $("#addWeeklyEvent").hide();
   $("#addMonthlyEvent").hide();
   $("#addYearlyEvent").hide();
  }

  else if(i==2 || i==4) /* Daily || Monday to Friday*/
  {
   $("#weekAndDay").hide();
   $("#oneTime").hide();
   $("#addSkipDays").show();
   $("#addDateRange").hide();
   $("#addTradHours").hide();
   $("#addWeeklyEvent").hide();
   $("#addMonthlyEvent").hide();
   $("#addYearlyEvent").hide();
  }
  else if(i==3)/* Date Range*/
  {
   $("#weekAndDay").hide();
   $("#oneTime").hide();
   $("#addSkipDays").show();
   $("#addDateRange").show();
   $("#addTradHours").hide();
   $("#addWeeklyEvent").hide();
   $("#addMonthlyEvent").hide();
   $("#addYearlyEvent").hide();
  }
  else if(i==5)/*Trading*/
  {
   $("#weekAndDay").hide();
   $("#oneTime").hide();
   $("#addSkipDays").show();
   $("#addDateRange").hide();
   $("#addTradHours").show();
   $("#addWeeklyEvent").hide();
   $("#addMonthlyEvent").hide();
   $("#addYearlyEvent").hide();
  }
  else if(i==6)/* Weekly*/
  {
   $("#weekAndDay").hide();
   $("#oneTime").hide();
   $("#addSkipDays").hide();
   $("#addDateRange").hide();
   $("#addTradHours").hide();
   $("#addWeeklyEvent").show();
   $("#addMonthlyEvent").hide();
   $("#addYearlyEvent").hide();
  }
  else if(i==7)/* Monthly*/
  {
   $("#weekAndDay").hide();
   $("#oneTime").hide();
   $("#addSkipDays").show();
   $("#addDateRange").hide();
   $("#addTradHours").hide();
   $("#addWeeklyEvent").hide();
   $("#addMonthlyEvent").show();
   $("#addYearlyEvent").hide();
  }
  else if(i==8)/* Yearly*/
  {
   $("#weekAndDay").hide();
   $("#oneTime").hide();
   $("#addSkipDays").show();
   $("#addDateRange").hide();
   $("#addTradHours").hide();
   $("#addWeeklyEvent").hide();
   $("#addMonthlyEvent").hide();
   $("#addYearlyEvent").show();
  }
  $("#AddButtonDiv").show(); 
 });
 
/* $("select#hvac_list").change(function(){
  var str = $("#hvac_list").val();
  var arr=[];
  /*if($("#hvacSelect").is(':checked'))
   arr = hvacList;
  else if ($("#lightingSelect").is(':checked'))
   arr = lightingList;
  else if($("#generalSelect").is(':checked'))*/
/*   arr = generalList;
  
  for(var i=0;i<arr.length;i++)
  {
   if(arr[i].name == str)
    {
     $data.scheduleName = arr[i].path;
    var date = $util.normalizeDate();
    $util.getMonthlySchedule(date,$data.scheduleName);
    $("#NamePlaceholder h2").text(arr[i].description);
    }
  }
 });*/
 $("#addException").hide();
 
/********************** Add Event Submit ***********************************************************/
 $("#addEventButton").click(function(){

  var eventName = $("#addEventName").val();
  var addEventType = $("#addEventType").val();

  var startTimeMode = $("#addEventEditStartMode").val();
  var startHour = $("#addEventEditStartHour").val();
  var startMin = $("#addEventEditStartMin").val();
  var startAmPm = $("#addEventEditStartAMPM").val();

  var endTimeMode = $("#addEventEditEndMode").val();
  var endHour = $("#addEventEditEndHour").val();
  var endMin = $("#addEventEditEndMin").val();
  var endAmPm = $("#addEventEditENdAMPM").val();

  var  eventClass ="";
  if($("#addEventClass").val()!=null || $("#addEventClass").val()!="")
	  eventClass = $("#addEventClass").val();
  /**Add One Time Event****/
  if(addEventType == 0)
  {
    var addEventEditDay = $("#addEventEditDay").val();
    var addEventEditMonth = $("#addEventEditMonth").val();
    var addEventEditYear = $("#addEventEditYear").val();
    var hr = 0;
    if(startAmPm == 1 || startAmPm == '1')
     {
     hr = parseInt(startHour) + 12;
     }
     else
     hr = parseInt(startHour);
 
    var d = new Date(addEventEditYear,addEventEditMonth,addEventEditDay,hr,startMin);
    var today = new Date();
    if(today > d)
    {
      alert("Cannot add events to past days");
      return;
    }
    $.niagara.addOneTimeEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,startTimeMode,endTimeMode,addEventEditDay,addEventEditMonth,addEventEditYear,addEventType,eventClass,function(obj){
     if(obj.value!= null)
       {
      if(obj.value == "false")
      {
       alert("Please check inputs");
      }
       }
     sethref("#addEventButton");
     });
  }

  /**Add Week And Day Event****/
  else if(addEventType == 1)
  {
   var editWeekDay = $("#WNDaddEventEditWeekDay").val();
   var editWeek = $("#WNDaddEventEditWeek").val();
   var editMonth = $("#WNDaddEventEditMonth").val();
   var skipDays = [];
   $('input:checkbox[name="addskipDays"]:checked').each(function(index) 
     { 
      skipDays.push($(this).val());
     });
   
   $.niagara.addWeekAndDayEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,startTimeMode,endTimeMode,editWeekDay,editWeek,editMonth,skipDays,addEventType,eventClass,function(obj){
    if(obj.value!= null)
      {
     if(obj.value != "true")
     {
      alert("Please check inputs");
      }
     }
    sethref("#addEventButton");
    });
  }

 /**Add Daily Event****/
  else if(addEventType == 2)
  {
   var skipDays = [];
   $('input:checkbox[name="addskipDays"]:checked').each(function(index) 
     { 
      skipDays.push($(this).val());
     });
   $.niagara.addDailyEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,startTimeMode,endTimeMode,skipDays,addEventType,eventClass,function(obj){
     if(obj.value!= null)
       {
       if(obj.value != "true")
       {
        alert("Please check inputs");
        }
      }
     sethref("#addEventButton");
    });
  }
  
  /**Add Date Range Event****/
  else if(addEventType == 3)
  { 
    var skipDays = [];
    $('input:checkbox[name="addskipDays"]:checked').each(function(index) 
     { 
      skipDays.push($(this).val());
     });
    var editStartDay = $("#addDrStartDate").val();
    var editStartMonth = $("#addDrStartMonth").val();
    var editStartYear = $("#addDrStartYear").val();
    var editEndDay = $("#addDrEndDate").val();
    var editEndMonth = $("#addDrEndMonth").val();
    var editEndYear = $("#addDrEndYear").val();
    
    $.niagara.addDateRangeEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,startTimeMode,endTimeMode,editStartDay,editStartMonth,editStartYear,editEndDay,editEndMonth,editEndYear,skipDays,addEventType,eventClass,function(obj){
     if(obj.value!= null)
       {
    	 if(obj.value!="true")
         {
         alert("Please check inputs");
         }
       }
     sethref("#addEventButton");
     });
  }
  /**Add Mon To Friday Event****/
   else if(addEventType == 4)
   { 
    var skipDays = [];
    $('input:checkbox[name="addskipDays"]:checked').each(function(index) 
      { 
       skipDays.push($(this).val());
      });
    $.niagara.addMonToFriEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,startTimeMode,endTimeMode,skipDays,addEventType, eventClass,function(obj){
      if(obj.value!= null)
        {
        if(obj.value != "true")
        {
         alert("Please check inputs");
         }
       }
      sethref("#addEventButton");
     });
  }
  /**Add Trading Hours Event****/
   else if(addEventType == 5)
   { 
    var skipDays = [];
    $('input:checkbox[name="addskipDays"]:checked').each(function(index) 
      { 
       skipDays.push($(this).val());
      });
    var addStartOffset = $("#addStartOffset").val();
    var addEndOffset = $("#addEndOffset").val();
    
    $.niagara.addTradingHoursEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,startTimeMode,endTimeMode,skipDays,addEventType,addStartOffset,addEndOffset, eventClass,function(obj){
      if(obj.value!= null)
        {
        if(obj.value != "true")
        {
         alert("Please check inputs");
         }
       }
      sethref("#addEventButton");
     });
  }
  /**Add Weekly Event****/
   else if(addEventType == 6)
   { 
    var editWeekDay = $("#addWeeklyEditWeekDay").val();
    
    $.niagara.addWeeklyEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,startTimeMode,endTimeMode,addEventType,editWeekDay, eventClass,function(obj){
      if(obj.value!= null)
        {
        if(obj.value != "true")
        {
         alert("Please check inputs");
         }
       }
      sethref("#addEventButton");
     });
  }
  /**Add Monthly Event****/
   else if(addEventType == 7)
   { 
    var skipDays = [];
    $('input:checkbox[name="addskipDays"]:checked').each(function(index) 
      { 
       skipDays.push($(this).val());
      });
    var editDay = $("#addMonthlyEditDay").val();
    
    $.niagara.addMonthlyEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,startTimeMode,endTimeMode,skipDays,addEventType,editDay, eventClass,function(obj){
      if(obj.value!= null)
        {
        if(obj.value != "true")
        {
         alert("Please check inputs");
         }
       }
      sethref("#addEventButton");
     });
  }
  /**Add Yearly Event****/
   else if(addEventType == 8)
   { 
    var skipDays = [];
    $('input:checkbox[name="addskipDays"]:checked').each(function(index) 
      { 
       skipDays.push($(this).val());
      });
    var editDay = $("#addYearlyEditDay").val();
    var editMonth = $("#addYearlyEditMonth").val();
    
    $.niagara.addYearlyEvent($data.scheduleName,eventName,startHour,startMin,startAmPm, endHour,endMin,endAmPm,startTimeMode,endTimeMode,skipDays,addEventType,editDay,editMonth, eventClass,function(obj){
      if(obj.value!= null)
        {
        if(obj.value != "true")
        {
         alert("Please check inputs");
         }
       }
      sethref("#addEventButton");
     });
  }
  
 
 }); 
 
 
function sethref(obj)
{
	
	 var arr = params[0].split("/");
		var sched = arr[arr.length-1];
		params[0]="";
		for(var i=0;i<arr.length-1;i++)
		{	
			if(i<arr.length-2)
				params[0] = params[0]+arr[i]+"/";
			else
				params[0] = params[0]+arr[i];
		}
		var alink = "indexRelative.html?"+params[0]+"&sched="+sched;
		$(obj).attr('href',alink);	
		location.href = alink;

}
     
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     
    $('#mask').click(function () {
        $(this).hide();
        $('.window').hide();
    });         

 /* Get the metering present datapoint and store its result */
  
 $(window).unload(function() {
 // clearInterval(intr);
 });
 
 /*var intr = setInterval(function(){
  var date = $util.normalizeDate();
  $util.getMonthlySchedule(date,$data.scheduleName);
 },
 20000);*/
 
 //$.niagara.BatchPoll.printPollList();
});
