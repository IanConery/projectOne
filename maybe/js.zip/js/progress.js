/**
 * Progress bar to show currents power or energy usage and expected energy power
 * or energy usage Author: Divya Nagaraja
 */
var progress = function(option) {

    this.values = {
        "min" : option.min || 0,
        "max" : option.max || option.expectedPower >= option.powervalue ? findGoodMax(Math.round(option.expectedPower)):findGoodMax(Math.round(option.powervalue)) || 1000,
        "Parentwidth" : option.Parentwidth || 500,
        "height" : 50 || option.height,
        "x" : 50,
        "y" : 50,
        "powervalue" : null || Math.round(option.powervalue),
        "canvas" : null || option.canvas,
        "ctx" : null,
        "color" : "#abb53a" || option.color,
        "strokeStyle" : "red" || option.strokeStyle,
        "currentstrokeStyle":"#595350"||option.currentstrokeStyle,
        "id" : null || option.id,
        "fontStyle" : option.fontStyle || '15px sans-serif',
        "fontColor" : "black",
        "fontSize" : "20px",
        "expectedPower" : null || option.expectedPower,
        "units" : option.units || null,
        "currentDisplayText":null||option.currentDisplayText,
        "expectedDisplayText":null||option.expectedDisplayText

    }
    var val=this.values;
    if (val.id != null) {
        var canvas = document.getElementById(val.id);
        if (canvas.getContext("2d")) {
            ctx = canvas.getContext("2d");
        } else {
            throw Error("Canvas element Not supported");
        }
    }

    drawText(val["min"], "", val["fontStyle"],
            val["fontColor"], val["min"] + val.x,
            val["height"] + val.y + 20);
    if (!isNaN(val["max"])) {
        drawText(val["max"], "", this.values["fontStyle"],
                this.values["fontColor"], this.values["Parentwidth"]
                        + this.values.x, this.values["height"] + this.values.y
                        + 20);
    }

    this.setValue = function(val,currentDisplayText) {
        this.values.powervalue = Math.round(val);
        this.values.currentDisplayText=currentDisplayText;
        this.init();
        return this;
    }
    this.setExpectedValue = function(val,expectedDisplayText) {
        if(val!==0){
        this.values.expectedPower = Math.round(val);
        if(expectedDisplayText!=undefined){
        this.values.expectedDisplayText=expectedDisplayText;
     }
       this.setMaxValue(this.values.powervalue,this.values.expectedPower);
         this.init();
       
    }
     return this;
    }
    this.setMaxValue = function(val, expectedVal) {
        if (val != undefined && !isNaN(expectedVal)) {

            if (expectedVal >= val) {
                this.values.max = findGoodMax(Math.round(expectedVal))
            } else {
                this.values.max = findGoodMax(Math.round(val));
            }
            clear(this.values.x, this.values.y + this.values.height + 20,
                    this.values.Parentwidth + 100, 50);
            drawText(this.values["max"], "", this.values["fontStyle"],
                    this.values["fontColor"], this.values["Parentwidth"]
                            + this.values.x, this.values["height"]
                            + this.values.y + 20);
        }
        return this;
    }
    this.init = function() {
        rect(this.values.x, this.values.y, this.values.Parentwidth,this.values.height, "#F5F5F5");
        var range = Math.ceil((this.values["max"] - this.values["min"])/ this.values["Parentwidth"]);
        //console.log("Max value"+this.values["max"]);
        width = this.values.min;
        /*if(range!==1){
            total = Math.floor(this.values.powervalue / range);
        }
        else{
            total=0;
        }*/
         total = Math.floor(this.values.powervalue / range);
        this.values.expectedPower!=0?finalpower = Math.ceil(this.values.expectedPower / range):finalpower=0;// this.values.expectedPower/range
        var self = this.values;

        var intervalFn = setInterval(function(self) {
            clear(self.x, self.y + self.height + 35,self.Parentwidth +70, 50);
            clear(self.x - 10, self.y - 20, self.x+self.Parentwidth + (0.20 * self.Parentwidth),25);
            if (width <= total) {
               //console.log(width);
                rect(self.x, self.y, width, self.height,self.color);

                if(Math.floor(0.20 * total)===0){
                       width = width+0.5;
                }
                else{
                    width = width+Math.floor(0.20 * total);
                }

            }
            else {
                if (width === self.Parentwidth || width > total) {
                    width = total;
                }
                if (width!=0 && width === finalpower) {
                    finalpower = finalpower + 10;
                }
                if(width!==0)
                {
                    line(width + self.x, self.y, width+ self.x, self.y + self.height,self.currentstrokeStyle);
                    drawText(self.currentDisplayText, self.units,self.fontStyle, self.fontColor, width+ self.x, self.y+ self.height+ (0.80 * self.height));
                    if(finalpower!=0){
                      drawText(self.expectedDisplayText, self.units,self.fontStyle, self.fontColor,finalpower + self.x, self.y - 10);
                      line(finalpower + self.x, self.y, finalpower+ self.x, self.y + self.height,self.strokeStyle);
                    }
                }
                width=0;
                clearInterval(intervalFn);
            }
        }, 100,self);

    }
    function rect(x, y, width, height, color) {
        ctx.beginPath();
        ctx.lineWidth = 2;
        ctx.rect(x, y, width, height);
        ctx.fillStyle = color;
        ctx.strokeStyle = "#A3A3A3";
        ctx.stroke();
        ctx.fill();
    }
    function clear(x, y, width, height) {
        ctx.clearRect(x + 7, y - 12, width - x + 7, height);
    }
    function drawText(displayValue, units, fontStyle, fontColor, x, y) {
        if (displayValue != undefined) {
            ctx.beginPath();
            ctx.fillStyle = fontColor;
            ctx.font = fontStyle;
            ctx.fillText(displayValue, x, y);
        }
    }
    function line(xFrom, yFrom, xTo, yTo, color) {
        ctx.beginPath();
        ctx.lineWidth = 4;
        ctx.moveTo(xFrom, yFrom);
        ctx.lineTo(xFrom, yFrom);
        ctx.lineTo(xTo, yTo);
        ctx.strokeStyle = color;
        ctx.stroke();
    }

    function findGoodMax(num) {
        var num = parseFloat(num);
        var s = num.toExponential().split('e');
        var pow = parseInt(s[1]);
        var isNegative = s[0][0] === "-";
        if (isNegative) {
            if (pow === 0 || pow === -1) {
                return 0;
            } else if (pow < 0) {
                pow += 1;
            }
            return -Math.pow(10, pow);
        } else {
            return Math.pow(10, pow + 1);
        }
    }

}