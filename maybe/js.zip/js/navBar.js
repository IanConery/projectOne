(function loadNavBar(){

  var navItems = [
    { title: 'Home',          href: 'index',         icon: 'home'       },
    { title: 'HVAC',          href: 'hvac',          icon: 'hvac'       },
    { title: 'Lighting',      href: 'lighting',      icon: 'lightbulb'  },
    { title: 'Power',         href: 'power',         icon: 'bolt-sm'    },
    { title: 'Alarms',        href: 'alarms',        icon: 'alarm'      },
    { title: 'Schedule',      href: 'schedule',      icon: 'calendar'   },
    { title: 'Misc',          href: 'miscellaneous', icon: 'tool'       },
    { title: 'Charting',      href: 'chart',         icon: 'bar-chart'  }
  ];

  var page = window.location.href;
  page = page.slice(page.lastIndexOf('/') + 1, page.lastIndexOf('.')).toLowerCase();

  if ( page === "" ) { page = 'index'; }

  if (page === "") { page = 'index'; } // handle defaulting address

  var currentPageObj = _.findWhere(navItems, { href: page });
  if (currentPageObj) { currentPageObj.klass = 'active'; }

  var navHTML = TMPLS.navBar(navItems);
  $('section#menu').html(navHTML);

})();