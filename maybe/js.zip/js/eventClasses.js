
/******************************************************************
 * schedule.js
 *
 * This Javascript code does all the implementation of the code
 * related to the boiler monitor page.
 *
 * This code is jQuery 1.4.X dependent and also dependent on the
 * jquery.niagara-ajax.X.js jQuery plug-in for Niagara/Ajax 
 * communication with the Niagara server and the 
 * jquery.control-panel-1.0.js file, both of which must be loaded
 * first.
 * Author: Deepti Phadnis
 ******************************************************************/
 jQuery(document).ready(function($) {

	 var loc = location.search.substring(1, location.search.length);
	 
	    var param_value = false;
	 var params = loc.split("&");
	 
	 param_name = params[0].substring(0,params[0].indexOf('='));
	 param_value = params[0].substring(params[0].indexOf('=')+1);
	 
	 var output = [];
	  var $data = {
	   regionPath : param_value,
	   scheduleType : "HVAC",
	   scheduleName : param_value
	 };
	 var $currWeeklySchedule = [];
	 var $newWeeklySchedule = [];
	    var maskHeight = 600;
	    var maskWidth = $(document).width();
	    var winH = 500;
	    var winW = $(document).width();
	    
	    var hvacList = [];
	    var lightingList = [];
	    var generalList = [];
	    
	var oldEventName="";
	var newEventName="";
	var cnt=8;
	var sub=50;
	var windLoc = window.location+"";
	var schedName="";
	var str = "";
	var str1="";
	var a="";

	$.niagara.getEventClassesAndNames($data.scheduleName,function(obj){
		if(obj.eventClassNames!=null && obj.eventClassNames.length > 0)
		{	
			showEventClasses(obj);
		}
	});

	function showEventClasses(obj)
	{
		var str="";
		for(var i = 0;i<obj.eventClassNames.length;i=i+2)
		{
			var cls = obj.eventClassNames[i];
			var list = obj.eventClassNames[i+1];
			
			str=str+'<li class="ui-state-default">'+
			'<span style="width:100px;"><b>'+cls+'</b></span>'+
			'<input type="text" style="position:relative;width:100px;top:5px;display:none;" value="'+cls+'"></input>'+
			'<button type="button" id="remove" name="remove" class="btn btn-primary" value="'+cls+'" style="float:right;position:relative;left:-410px;top:-5px;">'+'Remove'+'</button>'+
			'<button type="button" id="edit" name="edit" class="btn btn-primary" style="width:70px;float:right;position:relative;left:-250px;top:-5px;" value="'+cls+'">'+'Edit'+'</button>'+
			'<button type="button" id="eventsClassSave" name="save" class="btn btn-success" style="width:70px;float:right;position:relative;left:-330px;top:-5px;display:none;">'+'Save'+'</button>'+
			'<div style="width:300px;position:relative;left:375px;margin-top:-25px;"><ul class="csv">';

			
			for(j=0;j<list.length;j++)
			{	
				str=str+'<li>'+list[j]+'</li>';
			}
			str=str+'</ul></div></li>'; 
		}
		$("#eventsClass").append(str);

		$('button[name="remove"]').click(function(){
			var str = $(this).val();
			$.niagara.removeEventClasses($data.scheduleName,str,function(obj){
				if(obj.value=="true")
				{	
					$.niagara.getEventClassesAndNames($data.scheduleName,function(obj){
						if(obj.eventClassNames!=null && obj.eventClassNames.length > 0)
						{	
							$("#eventsClass").empty();
							$("#eventsClass").children().remove();
							showEventClasses(obj);
						}
					});
				}
				else
					{
					alert("Could not remove Class");
					}
			});
			
		});
		$('button[name="edit"]').click(function()
				{

				$(this).siblings(".ui-state-default").css("background-color","yellow");
				$(this).siblings().css("display","block");
				$(this).siblings("span").css("display","none");
				$(this).siblings("button").css("margin-top","-30px");
				$(this).siblings("div").css("margin-top","-35px");
				$(this).siblings("input").css("margin-top","-10px");
				$(this).css("display","none");

				});
				$('button[name="save"]').click(function()
				{

				$(this).siblings(".ui-state-default").css("background-color","red");
				$(this).siblings().css("display","block");
				$(this).siblings("input").css("display","none");
				$(this).siblings("button").css("margin-top","-20px");
				$(this).siblings("div").css("margin-top","-25px");
				$(this).css("display","none");
				oldEventName=$(this).siblings("span").text();

				newEventName=$(this).siblings("input").val();

				$(this).siblings("span").text(newEventName);


				$.niagara.editEventClasses($data.scheduleName,oldEventName,newEventName,function(obj){
				      if(obj.value == "true")
				      {
							$.niagara.getEventClassesAndNames($data.scheduleName,function(obj){
								if(obj.eventClassNames!=null && obj.eventClassNames.length > 0)
								{	
									$("#eventsClass").empty();
									$("#eventsClass").children().remove();
									showEventClasses(obj);
								}
							});
				      }
				      else
				    	  {
				    	  	alert("Please check inputs");
				    	  }
				     //sethref("#sunPositionSave");
				     });
				});
		
	}

	$("#addEventClass").click(function()
		{
		var str = $("#eventClassText").val();
			$.niagara.addEventClasses($data.scheduleName,str,function(obj){
				if(obj.value=="true")
				{	
					$.niagara.getEventClassesAndNames($data.scheduleName,function(obj){
						if(obj.eventClassNames!=null && obj.eventClassNames.length > 0)
						{	
							$("#eventsClass").empty();
							$("#eventsClass").children().remove();
							showEventClasses(obj);
						}
					});
				}
				else{
					alert("Please check inputs!");
				}
			});
		});

	 
	$("#eventClassText").click(function()
			{
				if($(this).val()=="Add Event Class")
					$(this).val("");
					
			});
	 $("#backButton").click(function()
			 {
		 sethref("#backButton");
		 	
	});




function sethref(obj)
{
	
	 var arr = params[0].split("/");
		var sched = arr[arr.length-1];
		params[0]="";
		console.log(arr);
		for(var i=0;i<arr.length-1;i++)
		{	
			if(i<arr.length-2)
				params[0] = params[0]+arr[i]+"/";
			else
				params[0] = params[0]+arr[i];
		}
		var alink = "indexRelative.html?"+params[0]+"&sched="+sched;
		$(obj).attr('href',alink);	
		location.href = alink;

}
     
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     
    $('#mask').click(function () {
        $(this).hide();
        $('.window').hide();
    });         

 /* Get the metering present datapoint and store its result */
  
 $(window).unload(function() {
 // clearInterval(intr);
 });
 
 /*var intr = setInterval(function(){
  var date = $util.normalizeDate();
  $util.getMonthlySchedule(date,$data.scheduleName);
 },
 20000);*/
 
 //$.niagara.BatchPoll.printPollList();
});

