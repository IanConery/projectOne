$("#right").click(function(){
  $(".block").animate({"left": "+=300px"}, "slow");
});

$("#left").click(function(){
  $(".block").animate({"left": "-=300px"}, "slow");
});