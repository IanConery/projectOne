


$("ul#GroupNames li").live("click",function(){
   var a=$(this).text(); 


if (a=="Group1")
{
$("#GroupButton").text(a);
$("#Zones").css("display","block");
$("#subZones").css("display","block");
$("#Group1Zones").css("display","block");
$("#Group2Zones").css("display","none");
$("#Group3Zones").css("display","none");
$("#Group4Zones").css("display","none");
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");
}
else if (a=="Group2")
{
$("#GroupButton").text(a);
$("#Zones").css("display","block");
$("#subZones").css("display","block");
$("#Group1Zones").css("display","none");
$("#Group2Zones").css("display","block");
$("#Group3Zones").css("display","none");
$("#Group4Zones").css("display","none");
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");
}
else if (a=="Group3")
{
$("#GroupButton").text(a);
$("#Zones").css("display","block");
$("#subZones").css("display","block");
$("#Group1Zones").css("display","none");
$("#Group2Zones").css("display","none");
$("#Group3Zones").css("display","none");
$("#Group4Zones").css("display","none");
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");
}
else if (a=="Group4")
{
$("#GroupButton").text(a);
$("#Zones").css("display","block");
$("#subZones").css("display","block");
$("#Group1Zones").css("display","none");
$("#Group2Zones").css("display","none");
$("#Group3Zones").css("display","none");
$("#Group4Zones").css("display","block");
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");
}
else if (a=="None")
{
$("#GroupButton").text(a);
$("#Zones").css("display","none");
$("#subZones").css("display","none");
}
else
{
$("#Group1Zones").css("display","none");
$("#Group2Zones").css("display","none");
$("#Group3Zones").css("display","none");
$("#Group4Zones").css("display","none");
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");
}
});

$("ul#Group1ZonesName li").live("click",function(){
   var a=$(this).text(); 


if (a=="Zone11")
{
$("#GroupButtonZone1").text(a);
$("#subZones").css("display","block");
$("#Zone11Sub").css("display","block");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");

}
else if (a=="Zone12")
{
$("#subZones").css("display","block");
$("#GroupButtonZone1").text(a);
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","block");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");
}
else if (a=="None")
{

$("#GroupButtonZone1").text(a);
$("#subZones").css("display","none");
}
else
{
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");
}
});


$("ul#Group2ZonesName li").live("click",function(){
   var a=$(this).text(); 


if (a=="Zone21")
{
$("#subZones").css("display","block");
$("#GroupButtonZone2").text(a);
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","block");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");

}
else if (a=="Zone22")
{
$("#subZones").css("display","block");
$("#GroupButtonZone2").text(a);
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");
}
else if (a=="None")
{

$("#GroupButtonZone2").text(a);
$("#subZones").css("display","none");
}
else
{
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");
}
});

$("ul#Group4ZonesName li").live("click",function(){
   var a=$(this).text(); 


if (a=="Zone41")
{
$("#subZones").css("display","block");
$("#GroupButtonZone4").text(a);
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","block");
$("#Zone42Sub").css("display","none");
}
else if (a=="Zone42")
{
$("#subZones").css("display","block");
$("#GroupButtonZone4").text(a);
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","block");
}
else if (a=="None")
{

$("#GroupButtonZone4").text(a);
$("#subZones").css("display","none");
}
else
{
$("#Zone11Sub").css("display","none");
$("#Zone12Sub").css("display","none");
$("#Zone21Sub").css("display","none");
$("#Zone22Sub").css("display","none");
$("#Zone41Sub").css("display","none");
$("#Zone42Sub").css("display","none");
}
});

$("ul#SubZone11Name li").live("click",function(){
   var a=$(this).text(); 


if (a=="Sub11-1")
{
$("#SubZoneButton11").text(a);
}
if (a=="None")
{
$("#SubZoneButton11").text(a);
}
});

$("ul#SubZone12Name li").live("click",function(){
   var a=$(this).text(); 


if (a=="Sub12-1")
{
$("#SubZoneButton12").text(a);
}
if (a=="None")
{
$("#SubZoneButton12").text(a);
}
});

$("ul#SubZone21Name li").live("click",function(){
   var a=$(this).text(); 


if (a=="Sub21-1")
{
$("#SubZoneButton21").text(a);
}
if (a=="None")
{
$("#SubZoneButton21").text(a);
}
});

$("ul#SubZone22Name li").live("click",function(){
   var a=$(this).text(); 


if (a=="Sub22-1")
{
$("#SubZoneButton22").text(a);
}
if (a=="None")
{
$("#SubZoneButton22").text(a);
}
});

$("ul#SubZone41Name li").live("click",function(){
   var a=$(this).text(); 

if (a=="Sub41-1")
{
$("#SubZoneButton41").text(a);
}
if (a=="None")
{
$("#SubZoneButton41").text(a);
}
});

$("ul#SubZone42Name li").live("click",function(){
   var a=$(this).text(); 


if (a=="Sub42-1")
{
$("#SubZoneButton42").text(a);
}
if (a=="None")
{
$("#SubZoneButton42").text(a);
}
});

$("ul#hvac1 li").live("click",function(){
   var a=$(this).text(); 


if (a=="mallHours")
{
$("#HVACButton").text(a);
}
});

$("ul#hvac1 li").live("click",function(){
   var a=$(this).text(); 


if (a=="AllMalls")
{
$("#HVACButton").text(a);
}
});