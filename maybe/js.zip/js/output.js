
/******************************************************************
 * schedule.js
 *
 * This Javascript code does all the implementation of the code
 * related to the boiler monitor page.
 *
 * This code is jQuery 1.4.X dependent and also dependent on the
 * jquery.niagara-ajax.X.js jQuery plug-in for Niagara/Ajax 
 * communication with the Niagara server and the 
 * jquery.control-panel-1.0.js file, both of which must be loaded
 * first.
 * Author: Deepti Phadnis
 ******************************************************************/
 jQuery(document).ready(function($) {

 var loc = location.search.substring(1, location.search.length);
 
    var param_value = false;
 var params = loc.split("&");
 
 param_name = params[0].substring(0,params[0].indexOf('='));
 param_value = params[0].substring(params[0].indexOf('=')+1);
 
 var output = [];
  var $data = {
   regionPath : param_value,
   scheduleType : "HVAC",
   scheduleName : param_value
 };
 var $currWeeklySchedule = [];
 var $newWeeklySchedule = [];
    var maskHeight = 600;
    var maskWidth = $(document).width();
    var winH = 500;
    var winW = $(document).width();
    var hvacList = [];
    var lightingList = [];
    var generalList = [];
    
var oldEventName="";
var newEventName="";
var cnt=6;
var sub=50;
var windLoc = window.location+"";
var schedName="";
var str = "";
var str1="";
var a="";

$.niagara.getScheduleOutputs($data.scheduleName,function(obj){
	if(obj && obj.value.length > 0)
	{
		showOutputs(obj.value);
	}	
});

function showOutputs(obj)
{
	$("#output").html("");
	var str="";
	for(var i = 0;i<obj.length;i=i+2)
	{
	str=str+'<li class="ui-state-default">'+
				'<span id="name" style="width:100px;">'+obj[i]+'</span>'+
				'<img src="images/close-icon.png" id="remove" name="remove" title="Close Output" class="btn btn-primary1" style="float:right;position:relative;left:-45px;top:-3px;"></img>'+
				'<img src="images/editButton.png" id="edit" name="edit" title="Edit Output" class="btn btn-primary1" style="float:right;position:relative;left:-55px;top:-5px;"></img>'+
				'<div style="width:120px;position:relative;left:245px;margin-top:-25px;">'+'<span id="t" class="y" style="width:100px;">'+obj[i+1]+'</span></div>'+'<div style="width:120px;position:relative;left:455px;margin-top:-22px;">'+'<span name="y" id="value" class="y" style="width:100px;"><input type="text" style="position:relative;width:100px;top:5px;display:none;" value="Event"></input>'+obj[i+1]+'</span></div>'+'</li>';

	}
	$("#output").append(str);
}

for(var i = 1;i<=6;i++)
{

str=str+'<li class="ui-state-default">'+
			'<span id="name" style="width:100px;">Name'+i+'</span>'+
			'<img src="images/close-icon.png" id="remove" name="remove" title="Remove Output" class="btn btn-primary1" style="float:right;position:relative;left:-45px;top:-3px;"></img>'+ '<img src="images/save.png" id="save" name="save" title="Save Output" class="btn btn-primary1" style="float:right;position:relative;left:-55px;margin-top:-5px;display:none;"></img>'+
				'<img src="images/editButton.png" id="edit" name="edit" title="Edit Output" class="btn btn-primary1" style="float:right;position:relative;left:-55px;top:-5px;"></img>'+
			'<div class="p" style="width:120px;position:relative;left:255px;margin-top:-20px;">'+'<span id="t" class="y" style="width:100px;">Type'+i+'</span></div>'+
			'<div class="v" style="width:120px;position:relative;left:455px;margin-top:-20px;">'+'<span id="t" class="y" style="width:100px;">Type'+i+5+'</span>'+'<input type="text" style="position:relative;width:100px;top:-5px;display:none;" value="Event"></input>'+'<select class="default" style="width:120px;display:none;margin-top:-25px;"><option value="True">True</option><option value="False">False</option></select>'+'</div></li>';

}
$("#output").append(str);

$('#type').on('change', function() {
  
  var a = this.value;
  if (a == "Boolean")
  {
  $("#defaultValueBoolean").css({"display":"block","margin-left":"410px","margin-top":"-40px"});
  $("#defaultValue").css("display","none");
  }
 else
{ 
  $("#defaultValue").css({"display":"block","margin-left":"410px","margin-top":"-40px"});
  $("#defaultValueBoolean").css("display","none");
}
});

$('#output').on('click', '#edit', function () {


$(this).siblings(".v").children("span").css("display","none");
$(this).siblings("#save").css("display","block");
$(this).css("display","none");

var e = $(this).siblings(".p").children("span").text();

if (e == "Boolean")
{
$(this).siblings(".v").children("select").css("display","block");
$(this).siblings(".v").children("input").css("display","none");
}
else
{
$(this).siblings(".v").children("input").css("display","block");
$(this).siblings(".v").children("select").css("display","none");
}

});

$('#output').on('click', '#save', function () {


$(this).siblings(".v").children("span").css("display","block");



var e = $(this).siblings(".p").children("span").text();
oldValue=$(this).siblings(".v").children("span").text();
if (e == "Boolean")
{
$(this).siblings(".v").children("input").css("display","none");
$(this).siblings(".v").children("select").css("display","none");
$(this).siblings("#edit").css("display","block");
$(this).css("display","none");
newValue=$(this).siblings(".v").children("select").val();
$(this).siblings(".v").children("span").text(newValue);
}
else if (e == "Numeric")
{

var regex = /^[0-9]+$/;
        if (regex.test($(this).siblings(".v").children("input").val())) {
            $(this).siblings(".v").children("select").css("display","none");
            $(this).siblings(".v").children("input").css("display","none");
			$(this).siblings("#edit").css("display","block");
			$(this).css("display","none");
            newValue=$(this).siblings(".v").children("input").val();
			$(this).siblings(".v").children("span").text(newValue);
        } else {
            alert("Please check inputs");
			$(this).siblings("#edit").css("display","none");
        }


}
else if (e == "String")
{

var regex = /^[a-zA-Z0-9]+$/;;
        if (regex.test($(this).siblings(".v").children("input").val())) {
            $(this).siblings(".v").children("select").css("display","none");
            $(this).siblings(".v").children("input").css("display","none");
			$(this).siblings("#edit").css("display","block");
			$(this).css("display","none");
            newValue=$(this).siblings(".v").children("input").val();
			$(this).siblings(".v").children("span").text(newValue);
        } else {
           alert("Please check inputs");
			$(this).siblings("#edit").css("display","none");
        }

$(this).siblings(".v").children("select").css("display","none");
$(this).siblings(".v").children("input").css("display","none");
newValue=$(this).siblings(".v").children("input").val();
}
else
{
$(this).siblings(".v").children("select").css("display","none");
$(this).siblings(".v").children("input").css("display","none");
$(this).siblings("#edit").css("display","block");
$(this).css("display","none");
newValue=$(this).siblings(".v").children("input").val();
}


$.niagara.outputValueSave($data.scheduleName,oldValue,newValue,function(obj){
     if(obj.value!= null)
       {
      if(obj.value == "false")
      {
       alert("Please check inputs");
      }
       }
     //sethref("#sunPositionSave");
     });
});
//Remove Row

$('#output').on('click', '#remove', function () {

        $(this).closest('li').remove();
		var name = $(this).siblings("span").text();
		var type = $(this).siblings("div").text();
		  var d= $('#type').val();

if (d == "Boolean")
{
var Value = $('#defaultValueBoolean').val();
}
else
{
var Value = $('#defaultValue').val();
} 
		
    $.niagara.removeScheduleOutputs($data.scheduleName,name,function(obj){
     if(obj.value!= null)
       {
      if(obj.value == "false")
      {
       alert("Please check inputs");
      }
       }
     //sethref("#sunPositionSave");
     });
		
 });


//Add Row
$("#addOutput").click(function () {           

  var Name = $('#outputText').val();
  var Type = $('#type').val();

  var d= $('#type').val();

if (d == "Boolean")
{
var Value = $('#defaultValueBoolean').val();
}
else
{
var Value = $('#defaultValue').val();
} 
  var c='<li class="ui-state-default">'+
			'<span style="width:100px;">'+Name+'</span>'+
			'<img src="images/close-icon.png" id="remove" name="remove" title="Remove Output" class="btn btn-primary1" style="float:right;position:relative;left:-45px;top:-3px;"></img>'+ '<img src="images/save.png" id="save" name="save" title="Save Output" class="btn btn-primary1" style="float:right;position:relative;left:-55px;margin-top:-5px;display:none;"></img>'+
				'<img src="images/editButton.png" id="edit" name="edit" title="Edit Output" class="btn btn-primary1" style="float:right;position:relative;left:-55px;top:-5px;"></img>'+
			'<div class="p" style="width:120px;position:relative;left:258px;margin-top:-20px;">'+'<span style="width:100px;">'+Type+'</span></div>'+
			'<div class="v" style="width:120px;position:relative;left:455px;margin-top:-20px;">'+'<span style="width:100px;">'+Value+'</span>'+'<input type="text" style="position:relative;width:100px;margin-top:-25px;display:none;" value="Event"></input>'+'<select class="default" style="width:120px;display:none;margin-top:-25px;"><option value="True">True</option><option value="False">False</option></select>'+'</div></li>'
 
if (d == "Numeric")
{
var regex = /^[0-9]+$/;
        if (regex.test($("#defaultValue").val())) {
           $('#output').append(c);
        } else {
            alert("Please Check Inputs");
        }

}
else if (d == "Boolean") 
{
$('#output').append(c);
}
else if (d == "String")
{
var regex = /^[a-zA-Z0-9]+$/;
        if (regex.test($("#defaultValue").val()) ) {
           $('#output').append(c);
        }
       
		else {
            alert("Please Check Inputs");
        }

}


    $.niagara.addScheduleOutputs($data.scheduleName,Name,Type,Value,function(obj){
     if(obj.value!= null)
       {
      if(obj.value == "false")
      {
       alert("Please check inputs");
      }
       }
     $.niagara.getScheduleOutputs($data.scheduleName,function(obj){
    		if(obj && obj.value.length > 0)
    		{
    			showOutputs(obj.value);
    		}	
    	});
     });

}); 
 
/*
//Remove Row

$('#output').on('click', '#remove', function () {

        //$(this).closest('li').remove();
		var name = $(this).siblings("span").text();
		var type = $(this).siblings("div").text();
		
    $.niagara.removeScheduleOutputs($data.scheduleName,name,function(obj){
     if(obj.value!= null)
       {
      if(obj.value == "false")
      {
       alert("Please check inputs");
      }
      else
    	  {
    	  	alert("Output removed successfully!");
    	  	$.niagara.getScheduleOutputs($data.scheduleName,function(obj){
    	  		if(obj.value && obj.value.length > 0)
    	  		{
    	  			$("#output").empty();
    	  			showOutputs(obj.value);
    	  		}	
    	  	});    	  	
    	  }
       }
     });
		
 });

//Add Row
$("#addOutput").click(function () {           
$('span[name="y"]').css("display","none");
  var Name = $('#outputText').val();
  var Type = $('#type').val();
  var c= $('#type').val();

if (c == "Boolean")
{
var Value = $('#defaultValueBoolean').val();
}
else
{
var Value = $('#defaultValue').val();
}
alert(Value);

    $.niagara.addScheduleOutputs($data.scheduleName,Name,Type,function(obj){
     if(obj.value!= null)
       {
      if(obj.value == "false")
      {
       alert("Please check inputs");
      }
      else
    	{
  	  	alert("Output added successfully!");
	  	$.niagara.getScheduleOutputs($data.scheduleName,function(obj){
	  		if(obj.value && obj.value.length > 0)
	  		{
	  			$("#output").empty();
	  			showOutputs(obj.value);
	  		}	
	  	});    	  	
   	  
    	}  
       }
     });

}); 
 */
 
 
	 $("#backButton").click(function()
			 {
		 sethref("#backButton");
		 	
	});
	

 
function sethref(obj)
{
	
	 var arr = params[0].split("/");
		var sched = arr[arr.length-1];
		params[0]="";
		console.log(arr);
		for(var i=0;i<arr.length-1;i++)
		{	
			if(i<arr.length-2)
				params[0] = params[0]+arr[i]+"/";
			else
				params[0] = params[0]+arr[i];
		}
		var alink = "indexRelative.html?"+params[0]+"&sched="+sched;
		$(obj).attr('href',alink);	
		location.href = alink;
}
     
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     
    $('#mask').click(function () {
        $(this).hide();
        $('.window').hide();
    });         

 /* Get the metering present datapoint and store its result */
  
 $(window).unload(function() {
 // clearInterval(intr);
 });
 
 /*var intr = setInterval(function(){
  var date = $util.normalizeDate();
  $util.getMonthlySchedule(date,$data.scheduleName);
 },
 20000);*/
 
 //$.niagara.BatchPoll.printPollList();
});