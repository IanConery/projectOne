
/******************************************************************
 * schedule.js
 *
 * This Javascript code does all the implementation of the code
 * related to the boiler monitor page.
 *
 * This code is jQuery 1.4.X dependent and also dependent on the
 * jquery.niagara-ajax.X.js jQuery plug-in for Niagara/Ajax 
 * communication with the Niagara server and the 
 * jquery.control-panel-1.0.js file, both of which must be loaded
 * first.
 * Author: Deepti Phadnis
 ******************************************************************/
 jQuery(document).ready(function($) {

	 var loc = location.search.substring(1, location.search.length);
	 
	    var param_value = false;
	 var params = loc.split("&");
	 
	 param_name = params[0].substring(0,params[0].indexOf('='));
	 param_value = params[0].substring(params[0].indexOf('=')+1);
	 
	 var output = [];
	  var $data = {
	   regionPath : param_value,
	   scheduleType : "HVAC",
	   scheduleName : param_value
	 };
	 var $currWeeklySchedule = [];
	 var $newWeeklySchedule = [];
	    var maskHeight = 600;
	    var maskWidth = $(document).width();
	    var winH = 500;
	    var winW = $(document).width();
	    
	    var hvacList = [];
	    var lightingList = [];
	    var generalList = [];
	    
	var oldEventName="";
	var newEventName="";
	var cnt=30;
	var windLoc = window.location+"";
	var schedName="";
	var eventNames = "";
	var str1="";

	schedName = ""+params[0].substring(params[0].indexOf('=')+1);
	$data.scheduleName = schedName;

	$.niagara.getMiscData($data.scheduleName,function(obj)
			{
			if(obj!=  "false")
			{
				$("#autoCleanUp").val(obj.autoCleanUp);
				$("#ignoreNullOp").val(obj.ignoreNullOp);
				$("#controlConfigEn").text(obj.controlConfigEn);
				if(obj.control=="0")
					$("#control").text("Master");
				else
					$("#control").text("Slave");

				if(obj.synchronization=="0")
					$("#synchronization").text("Slave Only");
				else
					$("#synchronization").text("Full");

				if(obj.schOut=="" || obj.schOut==" ")
					$("#out").text("-");
				else
					$("#out").text(obj.schOut);
				
				if(obj.schIn=="" || obj.schIn==" ")
					$("#in").text("-");
				else
					$("#in").text(obj.schIn);
				
				$("#maxRecords").text(obj.maxRecords);

			}
			});
 
 
 
 $("#backButton").click(function()
		 {
	 sethref("#backButton");
	 	
});

 
 

 
 $("#controlconfigSave").click(function(){

  var autoCleanUp = $("#autoCleanUp").val();
  var ignoreNullOp = $("#ignoreNullOp").val();

  
    $.niagara.saveMiscData($data.scheduleName,autoCleanUp,ignoreNullOp,function(obj){
      if(obj.value == "false")
      {
    	  alert("Please check inputs");
      }
      if(obj.value=="true")
    	  {
    		$.niagara.getMiscData($data.scheduleName,function(obj)
    				{
    				if(obj!=  "false")
    				{
    					$("#autoCleanUp").val(obj.autoCleanUp);
    					$("#ignoreNullOp").val(obj.ignoreNullOp);
    					$("#controlConfigEn").text(obj.controlConfigEn);
    					if(obj.control=="0")
    						$("#control").text("Master");
    					else
    						$("#control").text("Slave");

    					if(obj.synchronization=="0")
    						$("#synchronization").text("Slave Only");
    					else
    						$("#synchronization").text("Full");

    					if(obj.schOut=="" || obj.schOut==" ")
    						$("#out").text("-");
    					else
    						$("#out").text(obj.schOut);
    					
    					if(obj.schIn=="" || obj.schIn==" ")
    						$("#in").text("-");
    					else
    						$("#in").text(obj.schIn);
    					
    					$("#maxRecords").text(obj.maxRecords);

    				}
    				});
    	  
    	  }
    	  
     });
 }); 
 
 
function sethref(obj)
{
	
	 var arr = params[0].split("/");
		var sched = arr[arr.length-1];
		params[0]="";
		for(var i=0;i<arr.length-1;i++)
		{	
			if(i<arr.length-2)
				params[0] = params[0]+arr[i]+"/";
			else
				params[0] = params[0]+arr[i];
		}
		var alink = "indexRelative.html?"+params[0]+"&sched="+sched;
		$(obj).attr('href',alink);	
		location.href = alink;

}
     
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     
    $('#mask').click(function () {
        $(this).hide();
        $('.window').hide();
    });         

 /* Get the metering present datapoint and store its result */
  
 $(window).unload(function() {
 // clearInterval(intr);
 });
 
 /*var intr = setInterval(function(){
  var date = $util.normalizeDate();
  $util.getMonthlySchedule(date,$data.scheduleName);
 },
 20000);*/
 
 //$.niagara.BatchPoll.printPollList();
});



 