/******************************************************************
 * power.js
 *
 * This Javascript code does all the implementation of the code
 * related to the Power page.
 *
 * This code is jQuery 1.4.X dependent and also dependent on the
 * jquery.niagara-ajax.X.js jQuery plug-in for Niagara/Ajax
 * communication with the Niagara server and the
 * jquery.control-panel-1.0.js file, both of which must be loaded
 * first.
 * to retrieve xml data and functions to plot the charts
 * @author: Mithila Paranjpe
 ******************************************************************/
var currentNodeId;

window.onload = function() {
    window.doMetersSummaryTabWork = function() {
     	 doProgress();

        loadStaticPowerEnergyDetails();
        loadRealEnergyPowerWithPolling();
        loadExpectedEnergyDetails();
    }


    var prog, expected = 0,
        expectedString, yesterday = 0,
        currentTotalPower = 0;; /// don't remove values
    window.powertable = {};
    powertable.loading = "false";
      currentNodeId=window.location.href.split("url=")[1];
	  
    $.niagaraGet.getUserLogin("testpath", function(xml) {
       // currentNodeId = $util.setUpUser(xml);
        doMetersWork();

    });

    function doMetersWork() {

        var req = $util.getGateWay(currentNodeId);
        $util.extractPowerTableParentNodes(req);
        $('#powerTable').on('click', ' table .power', function() {

            if (powertable.loading === "false") {

                $('#loadProfileChart, #dailKwhChart, #monthlyKwhChart').find('div:first-child').remove();
                $('.powerloader').css('display', 'block');
                $('#powerCharts').css("opacity","0.3");
                $('#childTr').remove();
                powertable.loading = "true";
                LChosen = $(this);
                $(LChosen).after("<tr id='childTr'></tr>");
                var parentId = LChosen.parents('section:first').attr('id');
                tabClicked = parentId;

                LChosenID = $(this).children('td:nth-child(2)').attr('id');

                var LChosendText = $(this).children('td:nth-child(2)').text();
                panelName = LChosendText;
                //$(this).next().empty();
                var query;

                if (parentId == 'Meters') {
                    LChosenID = LChosenID;

                    query = "bql:select name as 'SEM',slotPath.toString as 'SlotPath',totalActivePower.out.value as 'Power',RealEnergyToday.out.value as 'Energy',attrs.disName as 'name',attrs.disSubMeter as 'subMeter' from csi3prophet:ProphetNode where name like 'SEM*'";

                    var powerResponse = $util.getTableQuery1(LChosenID, query);


                    $util.extractPowerTableChildNodes(powerResponse, LChosen, currentNodeId, parentId);


                }

                $(' table .power').not(this).removeClass('active');
                $(this).addClass('active');
                

                $(this).next().append('<td colspan="4"><div class="littleLoader">loading</div></td>');

                var working = $(this).next('table .power > tr');
                $('table .power >tr').not(working).removeClass('block');
                working.addClass('block');

            }

        });
        /*var setIntv = setInterval(function() {
           // $util.getTableQuery1(currentNodeId,query);            
        }, 2000);*/

    }



    function doProgress() {
        var option = {
            "min": 0,
            "max": 1000,
            "Parentwidth": 300,
            "powervalue": 0,
            "expectedPower": 0,
            "id": "can",
            "units": "KWH"
        }

       // prog = new progress(option);
       // prog.init();
    }

    function loadRealEnergyPowerWithPolling() {

        var credential = [{
            uid: "powerCurrent",
            nodeId: currentNodeId,
            data: "prophetData:Haystack/elecMeter/numeric/elecMeterRealPowerNum",
            tags: ['utilityMeter'],
            timeRange: "today"
        }, {
            uid: "energyToday",
            nodeId: currentNodeId,
            data: "prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum",
            tags: ['utilityMeter'],
            timeRange: "today"
        }];
        var updatePowerData = function(values) {
            var powerMap = {};
            _.each(values, function(val) {
                $('#' + val.uid).html(val.value);
                powerMap[val.uid] = {
                    "num": val.v,
                    "units": val.value
                };
                if (val.uid === 'energyToday') {
                    currentTotalPower = val.v;
                    $('#powerUsage').html('<b>' + val.value + '</b>');
                }

            });

            if (powerMap.energyToday != undefined) {
               // prog.setMaxValue(powerMap.energyToday.num, expected).setExpectedValue(expected, expectedString).setValue(powerMap.energyToday.num, powerMap.energyToday.units);
                var deltaObj = {};
                deltaObj.now = powerMap.energyToday.num;
                if (yesterday !== 0) {
                    deltaObj.before = yesterday;
                    deltaObj.type = 'day';
                    $('#energyToday').find('span').remove();
                    //ArrowHandler(deltaObj);
                }
            }
        }
        var powerUid = _.uniqueId('Realpower');
        var powerRequest = TMPLS.subscribe({
            uid: powerUid,
            values: credential
        });
        $util.subscribe(powerRequest, powerUid, updatePowerData); // call to get real power

        var powerreq = $util.pollReq(powerUid);

        var powerPollPoints = function(powerreq, uid, cb) {
            niagara.postReq("testPath", powerreq, function(xml) {
                var pollData = $util.parsePollSubcriptionXml(xml);
                cb(pollData.values);
            });
        };
        $util.kickoffPolling({
            fxn: powerPollPoints,
            args: [powerreq, powerUid, updatePowerData],
            interval: 10000
        });
    }

    function loadExpectedEnergyDetails() {
        var ExpectedCredentails = [{
            uid: "expectedPower",
            nodeId: currentNodeId,
            data: "prophetData:GGP/Predictions/realEnergyMax",
            timeRange: "previous30days"
        }];

        ExpectedCredentails.callback = function(data) {
            var calArr = {};
            _.each(data, function(val) {
                $('#' + val.uid).html('<b>' + val.value + '</b>');
                calArr[val.uid] = {
                    "num": val.valueObj.value,
                    "units": val.value
                };
            });
            expected = calArr.expectedPower.num;
            expectedString = calArr.expectedPower.units;
           // prog.setExpectedValue(expected, calArr.expectedPower.units);
        }

        dataEye.getDataValuesForNodes(ExpectedCredentails);

    }

    function ArrowHandler(deltaObj) {
        // then do the math to figure out increase/decrease arrow
        var periodDelta = deltaObj.now - deltaObj.before;
        var selector = deltaObj.type === 'day' ? '#energyToday' : '#energyMonthtoDate';
        if (!isNaN(periodDelta) && deltaObj.now !== 0) {
            if (periodDelta < 0) {
                $(selector).append("<span class='icon-arrow-down' id='low'>" + Math.abs(((periodDelta * 100) / deltaObj.now).toFixed(2)) + "%</span>")
            } else {
                $(selector).append("<span  class='icon-arrow-up' id='high'>" + ((periodDelta * 100) / deltaObj.now).toFixed(2) + "%</span>");
            }
        }
    }

    function loadStaticPowerEnergyDetails() {
        var dataHander = function(data) {

            // deltaObj is just to make computation of now and historical
            // references generic
            var deltaObj = {};
            _.each(data, function(d) {
                var typeKey = /energyLastmonth|energyYesterday/.test(d.uid) ? 'before' : 'now';
                var timeType = /day/.test(d.uid) ? 'day' : 'month';
                deltaObj[typeKey] = +d.valueObj.value;
                deltaObj.type = timeType
            });

            // first update the UI
            _.each(data, function(val) {
                $('#' + val.uid).html(val.value);
            });
            if (deltaObj.type === 'day') {
                yesterday = deltaObj.before;
                deltaObj.now = currentTotalPower;
            }

           // ArrowHandler(deltaObj);
        };

        var fastQueries = [{
            uid: "energyYesterday",
            nodeId: currentNodeId,
            data: "prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum",
            tags: ['utilityMeter'],
            timeRange: "yesterday"
        }];

        var slowerQueries = [{
            uid: "energyMonthtoDate",
            nodeId: currentNodeId,
            data: "prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum",
            tags: ['utilityMeter'],
            timeRange: "thisMonth"
        }, {
            uid: "energyLastmonth",
            nodeId: currentNodeId,
            data: "prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum",
            tags: ['utilityMeter'],
            timeRange: "lastMonth"
        }];

        _.each([fastQueries, slowerQueries], function(qry) {
            qry.callback = dataHander;
            dataEye.getDataValuesForNodes(qry);
        });


    }


};
