
define(function(require) {

    require('backbone');
    require('moment');

    var DataDefinition = require("models/data-definition-model");
    var DataDefinitionCollection = require("collections/data-definition-collection");
    var TrendCollection = require('collections/trend-collection');

    var renderPeakEnergyChart = function(options) {

        var
            siteInfo = $util.siteInfoFromNodeId(options.nodeId),
            timeRange = options.timeRange || 'current1days',
            chartTitle = options.chartTitle || {};
            timeMap = {             // keyed off of timeRange
                current1days: {
                    interval: {
                        small: 'fifteenMinutes',
                        big: 'oneHour'
                    }
                },
                current7days: {
                    interval: {
                        small: 'threeHours',
                        big: 'twelveHours'
                    }
                }
            }
        ;

        // TODO: code smell/HACK... this nice little timeMap works great
        // for prophet timeRange values that are not using startDate;endDate
        // (e.g. have a semicolon with two values)... so we are using this
        // timeMapKey to reset the key for this map to an available key,
        // current1days
        var timeMapKey = /;/.test(timeRange) ? 'current1days' : timeRange;

        // a state object because this module is loaded as a
        // singleton with renderPeakEnergyChart being a unique
        // entry point
        var state = {
            currentOptions: _.extend({}, options, {timeRange: timeRange}),
            $chartContainer: $('#'+options.renderTo)
        };

        registerLoading( state );

        var pointsMap = {
            electricRealEnergy: {
                data: 'prophetData:Haystack/elecMeter/numeric/elecMeterRealEnergyNum',
                trendCriteria: {
                    timeRange: timeRange,
                    aggregation: 'sum',
                    interval: timeMap[timeMapKey].interval.big,
                    rollup: 'sum'
                }
            },
            electricRealPower: {
                data: 'prophetData:Haystack/elecMeter/numeric/elecMeterRealPowerNum',
                trendCriteria: {
                    timeRange: timeRange,
                    aggregation: 'sum',
                    interval: timeMap[timeMapKey].interval.small,
                    rollup: 'avg'
                }
            },
            oat: {
                data:'prophetData:Haystack/weather/temperature/numeric/outdoorAirTemperatureNOAANum',
                trendCriteria: {
                    timeRange: timeRange,
                    aggregation: 'avg',
                    interval: timeMap[timeMapKey].interval.small,
                    rollup: 'avg'
                }
            }
        };

        var oatNodeId;
        if (options.oatNode) {
            oatNodeId = options.oatNode;
        }

        var ddCfg = _.map(pointsMap, function(val, key) {
            return {
                nodeId: key === 'oat' && oatNodeId ? oatNodeId : options.nodeId,
                data: val.data,
                uid: key
            }
        });

        var seriesCfg =_.map(pointsMap, function(val, key) {
            var obj = {
                nodeId: key === 'oat' && oatNodeId ? oatNodeId : options.nodeId,
                data: val.data,
                uid: key
            };
            _.extend(obj, val.trendCriteria);
            return obj;
        });


        // convert complete collection into a series suitable for highcharts
        var postProcessor = function(collection) {
            var highChartSeries = [];
            var yAxes = [];
            var pointMap = collection.groupBy('uid');
            var seriesCfgMap = {
                electricRealEnergy: {
                    type: 'column',
                    color: '#b0bf88',
                    pointPadding: 0.3,
                    groupPadding: 0.3,
                    borderWidth: 0,
                    shadow: false,
                    pointWidth: 27
                },
                electricRealPower: {
                    type: 'spline',
                    color: '#50471d',
                    marker: {
                        radius: 3,
                        symbol: 'circle',
                        fillColor: '#50471d'
                    }
                },
                oat: {
                    type: 'spline',
                    color: '#e58a53',
                    marker: {
                        radius: 3,
                        symbol: 'circle',
                        fillColor: '#e58a53'
                    }
                }
            }

            for (var uid in pointMap) {
                var cfg = _.findWhere(collection.options.trendRequests, {uid:uid});
                var seriesCfg =_.extend({
                    name: cfg.name,
                    yAxis: uid,
                    tooltip: {
                        valueSuffix: ' ' + cfg.units.text,
                        valueDecimals: cfg.precision
                    }
                }, seriesCfgMap[uid]);
                seriesCfg.data = _.map(pointMap[uid], function(p) {
                    return [
                        p.get('timestamp'),
                        p.get('value')
                    ];
                });

                var maxY = _.max(seriesCfg.data, function(xy) {
                    return xy[1];
                })[1];

                highChartSeries.push(seriesCfg);
                var yAxisCfg = {
                    id: uid,
                    labels: {
                        formatter: function() {
                            return Highcharts.numberFormat(this.value, 0);
                        },
                        style: {
                            color: seriesCfgMap[uid].color
                        }
                    },
                    title: {
                        text: cfg.units.text,
                        style: {
                            color: seriesCfgMap[uid].color
                        }
                    },
                    opposite: _.contains(['electricRealPower', 'oat'], uid),
                    max: maxY
                };
                yAxes.push(yAxisCfg);
            }
            return {
                series: highChartSeries,
                yAxes: yAxes
            };
        };


        var dataDefs = new DataDefinitionCollection(null,ddCfg);

        dataDefs.fetch({success:function(collection) {
            seriesCfg = _.map(seriesCfg, function(s) {
                var dd = collection.findWhere({uid: s.uid});
                return _.extend({}, s, {
                    type: dd.get('type'),
                    precision: dd.get('precision'),
                    name: dd.get('name'),
                    units: dd.get('units')
               });
            });

            var pointsFetched = function(points) {
                var chartData = postProcessor(points);
                _.extend(chartData, {
                    renderTo: options.renderTo,
                    siteInfo: siteInfo,
                    chartTitle: chartTitle,
                    datePicker: options.datePicker
                });
                renderHighChart(chartData, state)
            };

            var points = new TrendCollection(null, {
                trendRequests: seriesCfg
            });
            points.fetch({success: pointsFetched});

        }});
    };

    function renderHighChart(options, state) {
       
       //disabling loader image (Power Tab) once we get data to plot graph
     /*  if( options.renderTo =='loadProfileChart') {
        $('.powerloader').css('display','none');
       }
        */
        var chartCfg = getPeakEnergyHighchartsCfg({
            renderTo: options.renderTo,
            name: options.siteInfo.name,
            chartTitle: options.chartTitle
        });

        chartCfg.yAxis = options.yAxes;
        chartCfg.series = options.series;

        state.chart = new Highcharts.Chart(chartCfg);
        var dateFldId = _.uniqueId('peak-date')
        if (options.datePicker) {
            state.$chartContainer.prepend(TMPLS.dateChooser({id: dateFldId}));
            var dateVal = (state.currentOptions.timeRange === 'current1days'
                ? moment()
                : moment(state.currentOptions.timeRange.split(';')[0]))
                .format('YYYY-MM-DD');
            $('#'+dateFldId).val(dateVal);
            var $datePicker = state.$chartContainer.find('.date-pick-container');
            var paddingV = parseInt($datePicker.css('paddingTop'),10) + parseInt($datePicker.css('paddingBottom'),10);
            var dateH = $datePicker.height() + paddingV;
            var chartH = $(state.chart.container).height();
            var chartW = $(state.chart.container).width();
            state.chart.setSize(chartW, chartH - dateH);
            setUpDateHandler($datePicker, state);
        }
        state.$chartContainer.trigger('loaded');

    }

    function getPeakEnergyHighchartsCfg(options) {
        return {
            chart: {
                renderTo: options.renderTo,
                zoomType: 'xy',
                backgroundColor: 'white',
                marginRight: 120,
                borderRadius: 0
            },
            scrollbar: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            title: (function(){
                return _.extend({
                    text: options.name + ' Peak kW vs Energy per Day',
                    style: {
                        color: '#3c3334'
                    }
                }, options.chartTitle);
            })(),
            point: {
                marker: {
                    radius: 1,
                    symbol: 'circle'
                }
            },
            subtitle: {

            },
            xAxis: {
                type: 'datetime',
                 labels: {
                        formatter: function() {
                        return Highcharts.dateFormat('%l:00 %p', this.value);

                    }}
                // Highcharts.dateFormat('%b.%e %Y, %l:00 %p', this.x
            },
            tooltip: {
                shared: true,
                 formatter: function() {
                    var s = [
                        '<b>',
                        Highcharts.dateFormat('%b %d, %Y %I:%M %p', this.x),
                        '</b>'
                    ].join('');
                    _.each(this.points, function(point) {
                        var precision = point.series.options.precision;
                        s += [
                            '<br/>',
                            '<span style="color: ',
                            point.series.color,
                            '; font-weight: bold;">',
                            point.series.name,
                            '</span>: ',
                            Highcharts.numberFormat(point.y, precision)
                        ].join('');
                    });
                    return s;
                }
            },
            plotOptions: {
                series: {
                    animation: true
                }
            },
            legend: {
                layout: 'horizontal',
                align: 'center',
                backgroundColor: '#848484',
                itemStyle: {
                    color: 'white',
                    fontWeight: 'bold'
                }
            },
            series: []

        };
    }

    function setUpDateHandler($datePickerContainer, state) {
        $goBtn = $datePickerContainer.find("button[name='go']");
        $resetBtn = $datePickerContainer.find("button[name='reset']");
        $dateField = $datePickerContainer.find("input[type='date']");
        $resetBtn.on('click', function(jQEvent) {
            var timeRange = 'current1days';
            var cfg = _.extend({}, state.currentOptions, {timeRange: timeRange});
            $(state.chart.container).trigger('loading');
            renderPeakEnergyChart(cfg);
        });
        $goBtn.on('click', function(jQEvent) {
            var date = moment($dateField.val(), 'YYYY-MM-DD').startOf('day');
            var timeRange = moment(date).toISOString()+';'+moment(date).add('days', 1).toISOString();
            var cfg = _.extend({}, state.currentOptions, {timeRange: timeRange});
            $(state.chart.container).trigger('loading');
            renderPeakEnergyChart(cfg);
        });
    }

    function registerLoading(state) {
        if (! $(state.$chartContainer).data('loadingEventInitialized') ) {
            state.$chartContainer.on('loading', function() {
                state.$chartContainer.addClass('loading');
            });

            state.$chartContainer.on('loaded', function() {
                state.$chartContainer.removeClass('loading');
            });

            $(state.$chartContainer).data('loadingEventInitialized', true);
        }
    }

    return renderPeakEnergyChart;
});
