define(function(require) {


    var consumptionBreakdown = function(options) {

        var hvac, Misc, light, total;
        var credArr = {};
        var Credentails = [{
            uid: "TotalEnergy",
            nodeId: options.nodeId + "/Metering/Power",
            data: "prophetData:GGP/Power/shadowMeterEnergy",
            timeRange:"previous7days"
        }, {
            uid: "TotalHvac",
            nodeId: options.nodeId + "/Metering/Power",
            data: "prophetData:GGP/Power/hvacEnergy",
            timeRange: "previous7days"
        }, {
            uid: "TotalMisc",
            nodeId: options.nodeId + "/Metering/Power",
            data: "prophetData:GGP/Power/miscEnergy",
             timeRange: "previous7days"
        }, {
            uid: "TotalLigthing",
            nodeId: options.nodeId + "/Metering/Power",
            data: "prophetData:GGP/Power/lightingEnergy",
            timeRange: "previous7days"
        },{
            uid: "Tenant",
            nodeId: options.nodeId + "/Metering/Power",
            data: "prophetData:GGP/Power/tenantEnergy",
            timeRange: "previous7days"
        }];

        Credentails.callback = function(data) {
            _.each(data, function(val) {
                credArr[val.uid] = val.valueObj.value;

            });
            hvac = credArr["TotalHvac"];
            Misc = credArr["TotalMisc"];
            light = credArr["TotalLigthing"];
            total = credArr["TotalEnergy"];
            tenant= credArr["Tenant"];
            hvac != 0 && hvac !== undefined && !isNaN(hvac) ? hvac = (hvac / total) * 100 : hvac = 0;
            Misc != 0 && hvac !== Misc && !isNaN(Misc) ? Misc = (Misc / total) * 100 : Misc = 0;
            light !== 0 && light !== undefined && !isNaN(light) ? light = (light / total) * 100 : light = 0;
            tenant !== 0 && tenant !== undefined && !isNaN(tenant) ? tenant = (tenant / total) * 100 : tenant = 0;


            Highcharts.setOptions({
                colors: ['#22bbaf', '#CD4C6E', '#1c3544',"#E3C801"]
            });
           
              var avgPowerChart = new Highcharts.Chart(getHighchartsCfg(options.renderTo));
            
            
        }

        function getHighchartsCfg(renderTo) {
            return {
                chart: {
                    renderTo: renderTo,
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false
                },
                title: {
                    text: 'Consumption Break Down Last 7 Days'
                },
                tooltip: {
                    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            color: '#000000',
                            distance: -45,
                            format: '<b style="color:white;font-size:20px">{point.percentage:.1f} %</b>'
                        },
                        showInLegend: true
                    }
                },
                series: [{
                    type: 'pie',
                    name: 'Consumption share',
                    data: [
                        ['HVAC', hvac],
                        ['Light', light],
                        ['Misc', Misc],
                        ['Tenant', tenant]
                    ]
                }]
            }
        }

        dataEye.getDataValuesForNodes(Credentails);

    }
    return consumptionBreakdown;
});