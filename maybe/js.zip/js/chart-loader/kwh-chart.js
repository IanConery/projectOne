define(function(require) {

    require('backbone');

    var DataDefinition = require("models/data-definition-model");
    var DataDefinitionCollection = require("collections/data-definition-collection");
    var TrendCollection = require('collections/trend-collection');

    var renderKwhChart = function(options) {
        var seriesReq = _.map(options.dataDefs, function(i) {
            return {
                nodeId: options.nodeId,
                data: i.data,
                uid: i.uid,
                timeRange: options.timeRange,
                interval: options.interval
            }
        });

        var highChartCfg = options.highChartCfg || {};

        var dataDefs = new DataDefinitionCollection(null, seriesReq);

        // convert complete collection into a series suitable for highcharts
        var postProcessor = function(collection) {
            var highChartSeries = [];

            var indexPoints = collection.groupBy('uid');

            for (var idx in indexPoints) {
                var idxCfg = _.findWhere(collection.options.trendRequests, {uid:idx});

                var seriesCfg = {
                    name: idxCfg.name,
                    precision: idxCfg.precision
                };
                seriesCfg.data = _.map(indexPoints[idx], function(i) {
                    return [
                        i.get('timestamp'),
                        i.get('value')
                    ];
                });

                highChartSeries.push(seriesCfg);
            }
            return highChartSeries;
        };

        dataDefs.fetch({success:function(collection) {
            seriesReq = _.map(seriesReq, function(s) {
                var dd = collection.findWhere({uid: s.uid});
                return _.extend({}, s, {
                    type: dd.get('type'),
                    precision: dd.get('precision'),
                    name: dd.get('name'),
                    units: dd.get('units')
                });
            });

            var pointsFetched = function(collection) {

                 //disabling loader image (Power Tab) once we get data to plot graph
               /* if( options.renderTo =='dailKwhChart' || options.renderTo =='monthlyKwhChart' ) {
                     $('.powerloader').css('display','none');
                }*/

                var series = postProcessor(collection);
                var units = collection.options.trendRequests[0].units.text;
                $('#' + options.renderTo).highcharts(_.extend({
                    series: series,
                    chart: {
                        type: 'column',
                        borderRadius: 0
                    },
                    xAxis: {
                        type: 'datetime',
                        tickInterval: 24 * 3600 * 1000 * 1 , // three days in ms
                        labels: {
                            formatter: function() {
                                return Highcharts.dateFormat('%d', this.value)
                            }
                        }
                    },
                    yAxis: {
                        title: {
                            text: units
                        }
                    },
                    tooltip: {
                        shared: true,
                        formatter: function() {
                            var s = [
                                '<b>',
                                Highcharts.dateFormat('%b %d, %Y', this.x),
                                '</b>'
                            ].join('');
                            _.each(this.points, function(point){
                                var precision = point.series.options.precision;
                                s += [
                                    '<br/>',
                                    '<span style="color: ',
                                    point.series.color,
                                    '; font-weight: bold;">',
                                    point.series.name,
                                    '</span>: ',
                                    Highcharts.numberFormat(point.y, precision),
                                    ' ',
                                    units
                                ].join('');
                            });
                            return s;
                        }
                    }
                }, highChartCfg));


            };

            var points = new TrendCollection(null, {
                trendRequests: seriesReq
            });
            points.fetch({success: pointsFetched});

        }});

    };

    return renderKwhChart;
});


