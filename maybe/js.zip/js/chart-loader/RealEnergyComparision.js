define(function(require) {

    require('backbone');

    var DataDefinition = require("models/data-definition-model");
    var DataDefinitionCollection = require("collections/data-definition-collection");
    var TrendCollection = require('collections/trend-collection');
    var HOUR = 1000 * 60 * 60;
    var DAY = HOUR * 24;
    var RealEnergyComparision = function(options) {
        var seriesReq = _.map(options.dataDefs, function(i) {
            return {
                nodeId: options.nodeId,
                data: i.data,
                uid: i.uid,
                timeRange: i.timeRange
            }
        });
        var highChartCfg = options.highChartCfg || {};

        var dataDefs = new DataDefinitionCollection(null, seriesReq);

        // convert complete collection into a series suitable for highcharts
        var postProcessor = function(collection) {
            var highChartSeries = [];

            var indexPoints = collection.groupBy('uid');

            for (var idx in indexPoints) {
                var idxCfg = _.findWhere(collection.options.trendRequests, {
                    uid: idx
                });

                var seriesCfg = {
                    name: idxCfg.uid,
                    precision: idxCfg.precision
                };
                seriesCfg.data = _.map(indexPoints[idx], function(i) {
                    return i.get('value');
                });

                seriesCfg.data = seriesCfg.data.slice(0, 12);

                highChartSeries.push(seriesCfg);
            }
            highChartSeries[1].data=highChartSeries[1].data.slice(0, 7);
            return highChartSeries;
        };

        dataDefs.fetch({
            success: function(collection) {
                seriesReq = _.map(seriesReq, function(s) {
                    var dd = collection.findWhere({
                        uid: s.uid
                    });
                    return _.extend({}, s, {
                        type: dd.get('type'),
                        precision: dd.get('precision'),
                        name: dd.get('name'),
                        units: dd.get('units')
                    });
                });

                var pointsFetched = function(collection) {
                    var series = postProcessor(collection);
                    var units = collection.options.trendRequests[0].units.text;
                    $('#' + options.renderTo).highcharts(_.extend({
                        series: series,
                        chart: {
                            type: 'column',
                            borderRadius: 0
                        },
                        xAxis: {
                            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', "Aug", "Sep", "Oct", "Nov", "Dec"]
                        },
                        yAxis: {
                            title: {
                                text: units
                            }
                        },

                        plotOptions: {
                            column: {
                                stacking: 'normal'

                            }
                        },
                        tooltip: {
                            formatter: function() {
                                console.log(this.y);
                                return '<b>' + this.x + '</b><br/>' +
                                    this.series.name + ': ' + this.y + '<br/>' +
                                    'Total: ' + this.point.stackTotal;
                            }
                        }
                    }, highChartCfg));


                };

                var points = new TrendCollection(null, {
                    trendRequests: seriesReq
                });
                points.fetch({
                    success: pointsFetched
                });



                function loadYearlyComparisionDetails() {
                    rangeseries = [];
                    var ExpectedCredentails = [{
                        uid: "LastYearKwh",
                        nodeId: options.nodeId,
                        data: "prophetData:Haystack/elecMeter/numeric/elecMeterRealPowerNum",
                        timeRange: "yesterday",
                        tag: ['utilityMeter'],

                    }, {
                        uid: "thisYearKwh",
                        nodeId: options.nodeId,
                        data: "prophetData:Haystack/elecMeter/numeric/elecMeterRealPowerNum",
                        timeRange: "today",
                        tag: ['utilityMeter']
                    }];

                    ExpectedCredentails.callback = function(data) {

                        var arrytempHolder = [];
                        _.each(data, function(val) {
                            var calArr = {
                                name: val.uid
                            };
                            calArr.data = [parseInt(val.valueObj.value)];
                            arrytempHolder.push(calArr);
                        });

                        $('#loadYearlyComparision').highcharts(_.extend({
                            series: arrytempHolder,
                            chart: {
                                type: 'column',
                                borderRadius: 0
                            },
                            xAxis: {
                                categories: ['Yearly Comparision']
                            },
                            yAxis: {
                                title: {
                                    text: 'Kwh'
                                }
                            },
                            tooltip: {
                                shared: true

                            }
                        }, highChartCfg));

                    }

                    dataEye.getDataValuesForNodes(ExpectedCredentails);

                }
                loadYearlyComparisionDetails();

            }
        });

    };

    return RealEnergyComparision;
});
