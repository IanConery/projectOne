define(function(require) {

    require('backbone');

    var DataDefinition = require("models/data-definition-model");
    var DataDefinitionCollection = require("collections/data-definition-collection");
    var TrendCollection = require('collections/trend-collection');

    var renderStdDeviationChart = function(options) {
        var uid = _.uniqueId('std-dev-');
        var trendCfg = [{
            data: 'prophetData:Calculations/Metrics/avgZoneTempDev',
            nodeId: options.nodeId,
            timeRange: 'current1days',
            interval: 'oneHour',
            uid: uid
        }];

        var highChartCfg = getStDeviationHighchartsCfg(options);

        var dataDefs = new DataDefinitionCollection(null, trendCfg);

        // convert complete collection into a series suitable for highcharts
        var postProcessor = function(collection) {
            var highChartSeries = [];
            var idxCfg = _.findWhere(collection.options.trendRequests, {
                uid: uid
            });

            var seriesCfg = {
                name: idxCfg.name,
                precision: idxCfg.precision,
                type: 'areaspline',
                fillColor: {
                    linearGradient: [0, 0, 0, 300],
                    stops: [
                        [0, "#4572a7"],
                        [1, "#c3d6e1"]
                    ]
                },
                yAxis: 0,
                pointPadding: 0.3,
                groupPadding: 0.3,
                borderWidth: 0,
                shadow: false,
                pointWidth: 14
            };

//            seriesCfg.data = _.map(collection, function(i) {
            seriesCfg.data = collection.map(function(m) {
                return [
                    m.get('timestamp'),
                    m.get('value')
                ];
            });

            highChartSeries.push(seriesCfg);

            return highChartSeries;
        };

        dataDefs.fetch({
            success: function(collection) {
                trendCfg = _.map(trendCfg, function(s) {
                    var dd = collection.findWhere({
                        uid: s.uid
                    });
                    return _.extend({}, s, {
                        type: dd.get('type'),
                        precision: dd.get('precision'),
                        name: dd.get('name')
                    });
                });

                var pointsFetched = function(collection) {
                    var series = postProcessor(collection);
                    renderHighChart(highChartCfg, series);
                };

                var points = new TrendCollection(null, {
                    trendRequests: trendCfg
                });
                points.fetch({
                    success: pointsFetched
                });

            }
        });

    };

    function getStDeviationHighchartsCfg(options) {
        return {
            chart: {
                renderTo: options.renderTo,
                zoomType: 'xy',
                backgroundColor: 'transparent',
                marginLeft: 40,
                spacingLeft: 20
            },
            scrollbar: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            title: {
                text: 'Deviation From SetPoint',
                style: {
                    color: '#4572a7'
                }
            },
            point: {
                marker: {
                    radius: 1,
                    symbol: 'circle'

                }
            },
            subtitle: {

            },
            xAxis: {
                type: 'datetime'
                // Highcharts.dateFormat('%b.%e %Y, %l:00 %p', this.x
            },
            yAxis: [{ // Primary yAxis
                labels: {
                    formatter: function() {
                        return Highcharts.numberFormat(this.value, 0, "", ",") + '';
                    },
                    style: {
                        color: '#4572a7'
                    }
                },
                title: {
                    text: '',
                    style: {
                        color: '#4572a7'
                    }
                },
                opposite: false

            }],
            tooltip: {
                xDateFormat: '%Y/%m/%d',
                formatter: function() {
                    var d = new Date(this.x);
                    var sd = d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate() + " | " + d.getHours() + ":" + d.getMinutes();
                    var unit = {
                        'ZoneDevT': 'Value'
                        // 'Cost': '°$',
                        // 'C02': 'ppm'
                    }[this.series.name];

                    return '' +
                    //"<b>"+sd.toString()+"</b><br/><b>"+ this.y +' '+ unit+"</b>";
                    //shared: true,
                    //crosshairs: true
                    '<b>' + Highcharts.dateFormat('%b.%e %Y, %I:%M %p', this.x) + '</b><br/><b>' +
                        this.series.name + ' : ' + Highcharts.numberFormat(this.y, 2, '.', ',') + '</b>';
                }
            },
            plotOptions: {
                series: {
                    animation: true
                },
                areaspline: {
                    marker: {
                        enabled: false
                    }
                }
            },
            legend: {
                layout: 'horizontal',
                align: 'center',
                backgroundColor: '#424242',
                itemStyle: {
                    color: 'white',
                    fontWeight: 'bold'
                }
            },
            series: []

        };
    }

    function renderHighChart(highChartCfg, series) {
        var $parentContainer = $('#' + highChartCfg.chart.renderTo).parent();
        var $parentCWithWidth = $parentContainer.parent();

        var hPadding = (parseInt($parentContainer.css('paddingLeft'), 10) +
            parseInt($parentContainer.css('paddingRight'), 10));
        var w = $parentCWithWidth.width();
        _.extend(highChartCfg.chart, {
            width: w - hPadding,
            marginRight: 30
        });

        _.extend(highChartCfg, {
            credits: {
                enabled: false
            },
            series: series,
            tooltip: {
                shared: true,
                formatter: function() {
                    var s = [
                        '<b>',
                        Highcharts.dateFormat('%b %d, %Y %I:%M %p', this.x),
                        '</b>'
                    ].join('');
                    _.each(this.points, function(point) {
                        var precision = point.series.options.precision;
                        s += [
                            '<br/>',
                            '<span style="color: ',
                            point.series.color,
                            '; font-weight: bold;">',
                            point.series.name,
                            '</span>: ',
                            Highcharts.numberFormat(point.y, precision)
                        ].join('');
                    });
                    return s;
                }
            },
            xAxis: {
                type: 'datetime',
                 labels: {
                        formatter: function() {
                        return Highcharts.dateFormat('%l:00 %p', this.value);

                    }}

            },
            yAxis: {
                title: {
                    text: ''
                }
            }

        });
        var indicesChart = new Highcharts.Chart(highChartCfg);


    };

    return renderStdDeviationChart;
});