
define(function(require) {

    require('backbone');

    var DataDefinition = require("models/data-definition-model");
    var DataDefinitionCollection = require("collections/data-definition-collection");
    var TrendCollection = require('collections/trend-collection');


    var renderAZTChart = function(options) {
        var data = 'prophetData:Haystack/hvac/temp/air/numeric/activeZoneControlTempNum',
            nodeId = options.nodeId;

        var avgZoneTempCfgSeries = function(nodeId) {
            var commonOpts = {
                nodeId: nodeId,
                data: data,
                timeRange: 'current7days',
                aggregation: 'avg',
                interval: 'oneDay'
            };
            var minOpts = _.extend({}, {
                uid: _.uniqueId('min'),
                rollup: 'min'
            }, commonOpts);
            var maxOpts = _.extend({}, {
                uid: _.uniqueId('max'),
                rollup: 'max'
            }, commonOpts);

            return [minOpts, maxOpts];
        };

        var seriesReq = avgZoneTempCfgSeries(nodeId);

        // convert complete collection into a series suitable for highcharts
        var postProcessor = function(points) {
            var //data = points.toJSON(),
                uidForMin = _.findWhere(seriesReq, {rollup: 'min'}).uid,
                uidForMax = _.findWhere(seriesReq, {rollup: 'max'}).uid,
                // getTrend returns ALL points in a flat collection; we ran two
                // method requests (min and max) in getTrend, so we break out the
                // results in two sets id'd by uid
                minPoints = points.where({uid: uidForMin}),
                maxPoints = points.where({uid: uidForMax}),
                series = [];

            _.each(minPoints, function(minPt) {
                // between min set and max set, identify if we have a min & max for the same date
                // if so, add the data points with the common timestamp to the series
                var maxPt = _.find(maxPoints, function(mp) {
                    return minPt.get('timestamp') === mp.get('timestamp');
                });
                if (!!maxPt) {
                    var minVal = dataDef.getDisplayValueFor(minPt.get('value'), false),
                        maxVal = dataDef.getDisplayValueFor(maxPt.get('value'), false);
                    series.push([
                        minPt.get('timestamp'),
                        minVal,
                        maxVal
                    ]);
                }
            });
            return series;
        };

        var avgMinMaxZoneTempChart = new Highcharts.Chart(getAZTHighchartsCfg(options.renderTo));

        var dataDef = new DataDefinition({
            uid: _.uniqueId('azt-dd'),
            nodeId: nodeId,
            data: data
        });

        dataDef.fetch({success:function(dd) {
            seriesReq = _.map(seriesReq, function(s) {
                return _.extend({}, s, {type: dd.get('type')});
            });

            var pointsFetched = function(points) {
                var series = postProcessor(points);
                avgMinMaxZoneTempChart.addSeries({
                    name: 'Temperature range',
                    type: 'columnrange',
                    inverted: false,
                    id: 'AvgZoneT',
                    pointPadding: 0.3,
                    groupPadding: 0.3,
                    borderWidth: 0,
                    pointWidth:14,
                    data: series,
                    tooltip: {
                        valueSuffix: ' ' + dd.get('units').text,
                        valueDecimals: dd.get('precision')
                    }
                }, true);
            };

            var points = new TrendCollection(null, {
                trendRequests: seriesReq
            });
            points.fetch({success: pointsFetched});

        }});
    };

    function getAZTHighchartsCfg(renderTo) {
        return {
            chart: {
                renderTo: renderTo,
                zoomType: 'xy',
                borderRadius: 0,
                backgroundColor: 'transparent',
                inverted: true,
                marginRight: 30,
                spacingLeft: 20,
                spacingBottom: 20
            },
            scrollbar: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            title: {
                text: 'Average Zone Temperature',
                style: {
                    color: '#aa5858'
                }
            },
            point: {
                marker: {
                    radius: 1,
                    symbol: 'circle'
                }
            },
            subtitle: {

            },
            xAxis: {
                type: 'datetime',
                tickInterval: 24 * 3600 * 1000, // one day in ms
                labels: {
                    formatter: function() {
                        return Highcharts.dateFormat('%b %d', this.value)
                    }
                }
            },
            yAxis: [{
                labels: {
                    formatter: function() {
                        return Highcharts.numberFormat(this.value, 1, '.', ',') + '';
                    },
                    style: {
                        color: '#aa5858'
                    }
                },
                title: {
                    text: '',
                    style: {
                        color: '#aa5858'
                    }
                },
                maxPadding: .08,
                opposite: false

            }],
            plotOptions: {
                series: {
                    animation: true,
                    type: 'columnrange'

                }
            },
            legend: {enabled: false}
        };
    }

    return renderAZTChart;
});


