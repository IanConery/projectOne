define(function(require) {

    require('backbone');

    var DataDefinition = require("models/data-definition-model");
    var DataDefinitionCollection = require("collections/data-definition-collection");
    var TrendCollection = require('collections/trend-collection');

    var HOUR = 1000 * 60 * 60;
    var DAY = HOUR * 24;

    var renderIndicesChart = function(options) {
        var seriesReq = _.map(options.indices, function(i) {
            return {
                nodeId: options.nodeId,
                data: i.data,
                uid: i.uid,
                timeRange: options.timeRange,
                interval: options.interval
            }
        });

        var highChartCfg = options.highChartCfg;

        var dataDefs = new DataDefinitionCollection(null, seriesReq);

        // convert complete collection into a series suitable for highcharts
        var postProcessor = function(collection) {
            var highChartSeries = [];

            var indexPoints = collection.groupBy('uid');

            for (var idx in indexPoints) {
                var idxCfg = _.findWhere(collection.options.trendRequests, {uid:idx});

                var seriesCfg = {
                    name: idxCfg.name,
                    tooltip: {
                        valueDecimals: idxCfg.precision
                    }
                };
                seriesCfg.data = _.map(indexPoints[idx], function(i) {
                    return [
                        i.get('timestamp'),
                        i.get('value')
                    ];
                });

                highChartSeries.push(seriesCfg);
            }
            return highChartSeries;
        };

        dataDefs.fetch({success:function(collection) {
            seriesReq = _.map(seriesReq, function(s) {
                var dd = collection.findWhere({uid: s.uid});
                return _.extend({}, s, {
                    type: dd.get('type'),
                    precision: dd.get('precision'),
                    name: dd.get('name')
                });
            });

            var pointsFetched = function(collection) {
                var series = postProcessor(collection);
                renderHighChart(highChartCfg, series);
            };

            var points = new TrendCollection(null, {
                trendRequests: seriesReq
            });
            points.fetch({success: pointsFetched});

        }});

    };

    function renderHighChart(highChartCfg, series) {
        var $parentContainer = $('#'+highChartCfg.chart.renderTo).parent();
        var $parentCWithWidth = $parentContainer.parent();

        var hPadding = (parseInt($parentContainer.css('paddingLeft'),10) +
            parseInt($parentContainer.css('paddingRight'),10));
        var w = $parentCWithWidth.width();
        _.extend(highChartCfg.chart, {
            width: w-hPadding,
            marginRight: 30
        });

        _.extend(highChartCfg, {
            credits: {
                enabled: false
            },
            series: series,
            tooltip: {
                shared: true
            },
            xAxis: {
                type: 'datetime',
                tickInterval: DAY * 2 ,
                labels: {
                    formatter: function() {
                        return Highcharts.dateFormat('%b %d', this.value)
                    }
                }
            },
            yAxis: {
                title: {
                    text: ''
                }
            }

        });
        var indicesChart = new Highcharts.Chart(highChartCfg);


    };

    return renderIndicesChart;
});


