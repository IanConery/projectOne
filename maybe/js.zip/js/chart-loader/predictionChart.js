define(function(require) {

    require('backbone');
    var moment = require('moment');

    var DataDefinition = require("models/data-definition-model");
    var DataDefinitionCollection = require("collections/data-definition-collection");
    var TrendCollection = require('collections/trend-collection');

    var HOUR = 1000 * 60 * 60;

    var renderPredictionChart = function(options) {
        var nodeId = options.nodeId;

        var pointsMap = {
            minpower: {
                data: 'prophetData:GGP/Predictions/realPowerMin',
                trendCriteria: {
                    interval: 'fifteenMinutes',
                    timeRange: 'previous30days'
                }
            },
            maxpower: {
                data: 'prophetData:GGP/Predictions/realPowerMax',
                trendCriteria: {
                    interval: 'fifteenMinutes',
                    timeRange: 'previous30days'
                }
            },
            realpower: {
                data: 'prophetData:Haystack/elecMeter/numeric/elecMeterRealPowerNum',
                trendCriteria: {
                    interval: 'fifteenMinutes',
                    timeRange: 'today',
                    rollup: 'avg',
                    aggregation: 'sum',
                    tags: ['utilityMeter']
                }
            }
        };


        var ddCfg = _.map(pointsMap, function(val, key) {
            return {
                nodeId: options.nodeId,
                data: val.data,
                uid: key
            }
        });

        var seriesCfg = _.map(pointsMap, function(val, key) {
            var obj = {
                nodeId: options.nodeId,
                data: val.data,
                uid: key
            };
            _.extend(obj, val.trendCriteria);
            return obj;
        });

        // convert complete collection into a series suitable for highcharts
        var postProcessor = function(points) {

            var
                minPoints,
                maxPoints, realPoints,
                series = [],
                area = [],
                highChartSeries = [],
                yAxes = [],
                pointMap = points.groupBy('uid');

            // realpower
            if (pointMap.realpower) {
                var realPowerCfg = _.findWhere(points.options.trendRequests, {
                    uid: 'realpower'
                });
                realPowerCfg = _.extend({}, {
                    name: realPowerCfg.name,
                     unit:' ' + realPowerCfg.units.text,
                     decimal:realPowerCfg.precision
                   
                });
                realPowerCfg.data = pointMap.realpower.map(function(p) {
                    return [
                        p.get('timestamp'),
                        p.get('value')
                    ];
                });
                highChartSeries.push(realPowerCfg);
            } else if (points.error.realpower) {
                console.warn("Error getting real power for", points.options.nodeId, points.error.realpower);
            }

            if (pointMap.minpower && pointMap.maxpower) {
                var rangeCfg = _.findWhere(points.options.trendRequests, {
                    uid: 'minpower'
                });
                rangeCfg = _.extend({}, {
                    data: rangeCfg.data,
                   unit:' ' + rangeCfg.units.text,
                     decimal:rangeCfg.precision
                });

                rangeCfg.data = pointMap.minpower.map(function(p, i) {
                    return [
                        p.get('timestamp'),
                        p.get('value'),
                        pointMap.maxpower[i].get('value')
                    ];
                });

                highChartSeries.push(rangeCfg);

            } else {
                if (points.error.minpower) {
                    console.warn("Error getting min power for", points.options.nodeId, points.error.minpower);
                }
                if (points.error.maxpower) {
                    console.warn("Error getting max power for", points.options.nodeId, points.error.maxpower);
                }
            }
            /*if(points.error.minpower||points.error.maxpower||pointMap.realpower){
                 $('#'+options.renderTo).html('ERROR:Currently Data Not Available for prediction chart').css('color','red');
            }
             else{
                var avgPowerChart = new Highcharts.Chart(getHighchartsCfg(options.renderTo, series[0], series[1]));
                avgPowerChart.render();
               
             }*/
             var avgPowerChart = new Highcharts.Chart(getHighchartsCfg(options.renderTo, highChartSeries[0], highChartSeries[1]));
                avgPowerChart.render();
            return highChartSeries;
        };



        var dataDefs = new DataDefinitionCollection(null, ddCfg);

        dataDefs.fetch({
            success: function(collection) {

                seriesCfg = _.map(seriesCfg, function(s) {
                    var dd = collection.findWhere({
                        uid: s.uid
                    });
                    return _.extend({}, s, {
                        type: dd.get('type'),
                        precision: dd.get('precision'),
                        name: dd.get('name'),
                        units: dd.get('units')
                    });
                });

                var pointsFetched = function(points) {
                    var series = postProcessor(points);


                   
                };

                var points = new TrendCollection(null, {
                    nodeId: nodeId,
                    trendRequests: seriesCfg
                });
                points.fetch({
                    success: pointsFetched
                });

            }
        });
    };

    function getHighchartsCfg(renderTo, min, real) {
        return {
            chart: {
                renderTo: renderTo,
                zoomType: 'x'
            },
            title: {
                text: 'Expected Power Vs Real Time'
            },
            xAxis: {
                type: "datetime",
                /* dateTimeLabelFormats: {
                     day: '%H'
                 }*/
                labels: {
                    formatter: function() {
                        return Highcharts.dateFormat('%I %p', this.value);

                    }
                },
                tickInterval: HOUR * 2
            },
            yAxis: {
                title: {
                    text: 'Power kW'
                }
            },
            tooltip: {
                crosshairs: true,
                shared: true,
                formatter: function() {
                    var s = [
                        '<b>',
                        Highcharts.dateFormat('%b %d, %Y %I:%M %p', this.x),
                        '</b>'
                    ].join('');
                    _.each(this.points, function(point) {
                        var precision = point.series.options.precision;
                        var rangeVal;
                        if (point.point.low && point.point.high) {
                            rangeVal = Highcharts.numberFormat(point.point.low, precision) + '-' + Highcharts.numberFormat(point.point.high, precision);
                            s += [
                                '<br/>',
                                '<span style="color: ',
                                point.series.color,
                                '; font-weight: bold;">',
                                point.series.name,
                                '</span>: ',
                                rangeVal
                            ].join('');
                        } else {
                            rangeVal = Highcharts.numberFormat(point.y, precision);
                            s += [
                                '<br/>',
                                '<span style="color: ',
                                point.series.color,
                                '; font-weight: bold;">',
                                point.series.name,
                                '</span>: ',
                                rangeVal
                            ].join('');
                        }

                    });
                    return s;
                }
            },
            series: [{
                data: min.data,
                name: min.name,
                zIndex: 1,
                color:'#2f7ed8',
                marker: {
                    enabled: false
                },
                tooltip: {
                    valueSuffix:min.unit,
                    valueDecimals: min.decimal
                }
            }, {
                data: real.data,
                name: 'Power range',
                type: 'arearange',
                lineWidth: 1,
                color:'#0D233A',
                fillOpacity: 0.3,
                zIndex: 0,
                tooltip: {
                    valueSuffix: real.unit,
                    valueDecimals: real.decimal
                }
            }],
            credits: {
                enabled: false
            }
        };
    }
    return renderPredictionChart;
});
