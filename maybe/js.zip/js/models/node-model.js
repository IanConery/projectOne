/*****************************************************************
 * Name: 
 * Version: 
 * Date: {}
 * Copyright: 2013 Controlco, CSI3
 *
 *
 * @author: Brian Murrell
 *****************************************************************/

define(function(require) {
    require('backbone');
    var xml2json = require('xml2json');
    var getNodeTmpl = require('hbars!xmlDataEyeReqTmpls/get-node-template');

    var Node = Backbone.Model.extend({
        defaults: {},
        initialize: function(options) {
            options = options || {};


            this.set(options);
        },

        setChildNodes: function(nodes) {
            if (nodes) {
                this.set({
                    childNodes: nodes
                });
            }
        },

        url: '/prophet',

        fetch: function(options) {

            options = options || {};
            options.nodeId = options.nodeId || this.get('nodeId');

            var xmlReqData = xmlIfy(options);

            var self = this;

            var success = function(xmlData) {

                var response = deXmlIfy(xmlData);
                if (response.node) {
                    // rename response.node.attributes to avoid naming conflict w/ backbone model
                    self.transformServerValues(response.node);
                    self.set(response.node);
                }
            }

            var ajaxConfig = {
                url: this.url, 
                data: xmlReqData,
                type: 'POST', 
                dataType: 'text',
                contentType: 'text/xml',
                success: success
            };
           
            $.ajax(ajaxConfig);
        },

        // this should be called as a pre-processor to setting values
        // on the node to clean up xml properties into something 
        // useful for the model.
        transformServerValues: function (options) {
            // attributes is just a container. the real data is 
            // in attributes.attr (which could be an obj or an array)
            // on options.attr, then we need to get at @attrs (xml dom)
            // to fill out all the data, then we simply set options.attributes
            // to a regular array of JS objects
            if (options.attributes) {
                options.attrs = options.attributes.attr;
                delete options.attributes;
            }
            if (!!options.attrs) {
                if ( !_.isArray(options.attrs) ) {
                    options.attrs = [options.attrs];
                }
            }
            _.forEach(options.attrs, function(a) {
                a.name = a['@n'];
                a.definedOnThisNode = a['@d'] === "true";
                a.value = a['#cdata']; 
                delete a['@n'];
                delete a['@d'];
                delete a['#cdata']
            });

            options.tags = !!options.tags ? options.tags.split(',') : [];
            options.hasChildNodes = options.hasChildNodes === "true";

            options.type = options['@type'];
            delete options['@type'];

        }

    });

    function xmlIfy(options) {
        options.uid = options.uid || _.uniqueId();
        var xml = getNodeTmpl(options);
        return xml;
    }

    function deXmlIfy(xmlData) {
        var d = xml2json($.parseXML(xmlData),'');
        var da = JSON.parse(d);

        return da.ProphetResponse.MethodResponse;

    }

    return Node;
});