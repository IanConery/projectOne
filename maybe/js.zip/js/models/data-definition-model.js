
define(function(require) {
    'use strict';

    require('backbone');

    var getDataDefinitionTmpl = TMPLS.getDataDefinition;

    var DataDefinition = Backbone.Model.extend({

        fetch: function(options) {
            var ajaxConfig = {
                url: this.url,
                data: this.xmlIfy(),
                type: 'POST',
                dataType: 'text',
                contentType: 'text/xml',
                parse: true
            };

            options = _.extend({}, ajaxConfig, options);

            return Backbone.Model.prototype.fetch.call(this, options);

        },
        toggleSelected: function(bool) {
            if (_.isUndefined(bool)) {
                this.set('selected', !this.get('selected'));
            } else {
                this.set('selected', bool);
            }
        },
        getDisplayValueFor: function(val, showLabel) {
            if ( _.isUndefined(showLabel) ) showLabel = true;
            var units = this.get('units'),
                prefix = '',
                suffix = '';
            switch ( this.get('type') ) {
                case 'numeric' :
                    if ( /\./.test(val) ) {
                        val = parseFloat(val.toFixed( this.get('precision') ) );
                    } else {
                        val = parseInt(val, 10);
                    }
                    if (!!units && showLabel) {
                        if (units.name==='dollar') {
                            prefix = units.text;
                        } else {
                            suffix = ' ' + units.text;
                        }
                        val = prefix + val + suffix;
                    }
                    break;
                case 'boolean' :
                    val = val  ? this.get('trueText') : this.get('falseText');
                    break;
                case 'enum' :
                    // TODO: do something with mapped enum vals
                case 'string' :
                    // TODO:  mabye nothing to do, but need a test case

            }
            return val;

        },

        url: '/prophet',

        parse: function(response, options) {
            // if coming from collection fetch, the response is already an object;
            // if coming from model fetch (it's a string), it needs to be deXmlified
            var attrs;
            if ( _.isString(response) ) {
                var data = deXmlIfy(response);
                attrs = data.dataDefinition;
                attrs.uid = data['@uid'];
            } else {
                attrs = response;
            }
            attrs.type = attrs['@type']; delete attrs['@type'];
            attrs.trended = attrs.trended === 'true';
            if (attrs.units) {
                attrs.units = {
                    text: attrs.units['#text'],
                    name: attrs.units['@name']
                };
            }
            if (attrs.actions) {
                // actions is an object with 'action'
                // property on it... which may be an
                // object or array. promote actions.action to
                // attrs.actions array
                if (_.isArray(attrs.actions.action)) {
                    attrs.actions = attrs.actions.action;
                } else {
                    attrs.actions = [attrs.actions.action];
                }
            }
            if (attrs.precision) {
                attrs.precision = parseInt(attrs.precision, 10);
            }
            return attrs;
        },

        xmlIfy: function(options) {
            var data = options || this.attributes;
            // the template expects an array
            var xml = getDataDefinitionTmpl([data]);
            return xml;
        }

    });

    function deXmlIfy(xmlData) {
        var d = xml2json($.parseXML(xmlData),'');
        var da = JSON.parse(d);
        return da.ProphetResponse.MethodResponse;
    }

    return DataDefinition;
});
