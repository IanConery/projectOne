/*****************************************************************
 * Name:
 * Version:
 * Date: {}
 * Copyright: 2013 Controlco, CSI3
 *
 *
 * @author: Brian Murrell
 *****************************************************************/

define(function (require) {

    require('backbone');
    require('moment');

    var TrendPoint = Backbone.Model.extend({
        parse: function(serverData, options) {
            // this gives a moment object which is aware of the tz from which
            // it was created (server time)
            var localizedServerTime = moment.parseZone(serverData.isoDate);
            // here is just to get the tz offset of the browser (local time)
            var here = moment();
            // localAdjust is the delta btwn local time and server time
            var localAdjust = localizedServerTime.zone()-here.zone();
            localizedServerTime.subtract('minutes', localAdjust);
            // to create a new Date object from moment, you must first clone(), then doDate()
            var dateVal = localizedServerTime.clone().toDate();
            // getTimezoneOffset is in minutes; multiply 60 min and make it milliseconds
            var timestamp = dateVal.getTime() - (dateVal.getTimezoneOffset() * 60 * 1000);

            return {
                timestamp: timestamp,
                value: getVal(serverData),
                status: serverData.status,
                uid: serverData.uid,
                serverInterval: serverData.serverInterval
            };
        }
    });

    function getVal(options) {
        var val = '';
        switch (options.type) {
            case 'numeric' :
                val = parseFloat(options.value);
                break;
            case 'boolean' :
                val = options.value === "true";
                break;
            case 'enum' :
            case 'string' :
                val = options.value;
                break;
        }
        return val;
    }
    return TrendPoint;
});
