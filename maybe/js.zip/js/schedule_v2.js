
/******************************************************************
 * schedule.js
	Controlco Inc
 * Author: Deepti Phadnis
 ******************************************************************/



jQuery(document).ready(function($) {

 var loc = location.search.substring(1, location.search.length);
 
 var param_value = false;
 var params = loc.split("&");
 var ord = params[0].substring(params[0].indexOf('=')+1);
 var schedName="",isVirtual="false",virSchPath="";
 var selectedGroupName="";
 var selectedZoneName="";
 var selectedSubZoneName="";

 if(params[1] &&  params[1]!=null && params[1]!="")
 {
	 schedName=params[1].substring(params[1].indexOf('=')+1);
 }	 
 if(params[2] &&  params[2]!=null && params[2]!="")
 {
	 isVirtual=params[2].substring(params[2].indexOf('=')+1);
	 virSchPath=params[3].substring(params[3].indexOf('=')+1);
 }	 
 if(params[4] &&  params[4]!=null)
 {
	 selectedGroupName=params[4].substring(params[4].indexOf('=')+1);
 }
 if(params[5] &&  params[5]!=null)
 {
	 selectedZoneName=params[5].substring(params[5].indexOf('=')+1);
 }	 
 if(params[6] &&  params[6]!=null)
 {
	 selectedSubZoneName=params[6].substring(params[6].indexOf('=')+1);
 }	 
 

 var output = [];
  var $data = {
   regionPath : ord,
   scheduleType : "General",
   scheduleName : schedName,
   virSchPath : virSchPath
 };
 var $currWeeklySchedule = [];
 var $newWeeklySchedule = [];
    
    var hvacList = [];
    var lightingList = [];
    var generalList = [];
    
var oldEventName="";
var newEventName="";
var grpZone={};


//$util.setValueEditBox();

var windLoc = window.location+"";


$("#isSelected").click(function (){
	
	var date = $util.normalizeDate();
	$("#editGroup").css("display","none");
	
	if($("#isSelected").attr("checked"))
	{
		$("#modlink").hide();
		$("#dropdownMenu1").hide();
		$("#Zones").show();
		$("#Group").show();
		$("#SubZones").show();
		isVirtual="true";
		getVirtualHtml($data.scheduleName,"#GroupNames","#GroupButton","#editGroup",'Groups <span class="caret"></span>');
	}
	else
	{
		selectedGroupName="";
		selectedZoneName="";
		selectedSubZoneName="";
		$("#modlink").show();
		$("#dropdownMenu1").show();
		$("#Zones").hide();
		$("#Group").hide();
		$("#SubZones").hide();
		isVirtual="false";
		$util.getMonthlySchedule(date,$data.scheduleName);
	}	
	});

 $.niagara.getChildren($data.regionPath,function(obj){
  if(obj.value.length > 0)
    {
   for(var i=0;i<obj.value.length;i++)
     {
     var sched = {
       name: "name",
       description:"description",
       path:"path",
       defaultOp:"",
       input:"",
       currOp:"",
       nextOp:""
        };
    sched.name = obj.value[i].name;
    sched.description = obj.value[i].description;
    sched.path = obj.value[i].path;
    sched.defaultOp = obj.value[i].defaultOp;
    sched.input = obj.value[i].input;
    sched.currOp = obj.value[i].currOp;
    sched.nextOp = obj.value[i].nextOp;
    
     if(obj.value[i].scheduleType=="HVAC")
      hvacList.push(sched);
     else if(obj.value[i].scheduleType=="Lighting")
      lightingList.push(sched);
     else if(obj.value[i].scheduleType=="General")
      generalList.push(sched);
     }
   $("#isSelected").attr("checked",false);
   var schList = ''; 
     for(var j=0;j<generalList.length;j++)
     {
    	schList = schList + '<li><a href="#" value="'+generalList[j].name+'">'+generalList[j].name+'</a></li>';
     }
     $("#hvac_list").append(schList);
     
    if(generalList.length > 0)
    {
    	if(params[1] &&  params[1]!=null && params[1]!="")
    	{	
    		$data.scheduleName = ""+params[0].substring(params[0].indexOf('=')+1)+"/"+schedName;
    		$("#NamePlaceholder h2").text(generalList[0].description);
	        var date = $util.normalizeDate();
	        $("#HVACButton").text(schedName);
	        
	  	  
		  for(var i=0;i<generalList.length;i++)
		  {
		   if(generalList[i].name == schedName)
		    {
		   	var str = $util.getScheduleValues(generalList[i]);
	        $( "#scheduleDesc" ).qtip( {
                content     : {
                	title: "Description",
                	text: str
                },
                position    : {
                    target  : 'mouse'
                },
                style: { classes: 'qtip-blue',
                	'font-size':12},
                	show: { event: 'click'}, 
        			
    				hide: {event: 'unfocus' }	
             });
		    }
		  }
		  if(isVirtual=="false")
		  {
			  $("#isSelected").attr("checked",false);
			  	$util.getMonthlySchedule(date,$data.scheduleName);
		        getVirtualScheduleList($data.scheduleName);
		  }	
		  else
		  {
			  $("#isSelected").attr("checked",true);
			  getVirtualScheduleList($data.scheduleName);
  			  $util.getVirtualMonthlySchedule(date,$data.scheduleName,$data.virSchPath);
  			  
  			  if(selectedGroupName!="")
  				  getVirtualHtml($data.scheduleName,"#GroupNames","#GroupButton","#editGroup",'Groups <span class="caret"></span>',selectedGroupName);
  			  if(selectedZoneName!="")
  				  getVirtualHtml($data.scheduleName,"#ZoneNames","#ZoneButton","#editZone","#closeZone",'Zones <span class="caret"></span>',selectedZoneName);
  			  if(selectedSubZoneName!="")
  				getVirtualHtml("#SubZoneNames","#SubZoneButton","#editSubZone","#closeSubZone",'Sub Zones <span class="caret"></span>',selectedSubZoneName);

		  }
		  
		  $(window).unload(function() {
			  clearInterval(intr);
			 });
			 
		 
		  var intr = setInterval(function(){
			  var date = $util.normalizeDate();
			  if(isVirtual=="true")
				  {
				 
					var date = $util.normalizeDate();
					$util.getVirtualMonthlySchedule(date,$data.scheduleName,$data.virSchPath);
				  }
			  else
				  $util.getMonthlySchedule(date,$data.scheduleName);
			 },
			 20000);
    	}
    	
    	else
	    {		
		   	$data.scheduleName = generalList[0].path;
		   	var str = $util.getScheduleValues(generalList[0]);
		     $("#NamePlaceholder h2").text(generalList[0].description);
		     $( "#scheduleDesc" ).qtip( {
	                content     : {
	                	title: "Description",
	                	text: str
	                },
	                position    : {
	                    target  : 'mouse'
	                },
	                style: { classes: 'qtip-blue',
	                	'font-size':12},
	                	show: { event: 'click'}, 
	        			
	    				hide: {event: 'unfocus' }	
	             });
		     var date = $util.normalizeDate();
		     $util.getMonthlySchedule(date,$data.scheduleName);
		     getVirtualScheduleList($data.scheduleName);
	    }
    }
    	
    }
  $("ul#hvac_list li a").click(function(){
		  var str = $(this).text();
		  var arr=[];
		   arr = generalList;
		  
		  for(var i=0;i<arr.length;i++)
		  {
		   if(arr[i].name == str)
		    {
			 $("#HVACButton").text(str);  
		     $data.scheduleName = arr[i].path;
		    var date = $util.normalizeDate();
		    $util.getMonthlySchedule(date,$data.scheduleName);
		    $("#NamePlaceholder h2").text(arr[i].description);
		   	var str = $util.getScheduleValues(arr[i]);
		     
	        $( "#scheduleDesc" ).qtip( {
	            content     : {
	            	title: "Description",
	            	text: str
	            },
	            position    : {
	                target  : 'mouse'
	            },
	            style: { classes: 'qtip-blue',
	            	'font-size':12},
	            	show: { event: 'click'}, 
	    			
					hide: {event: 'unfocus' }	
	         });
			getVirtualHtml($data.scheduleName,"#GroupNames","#GroupButton","#editGroup",'Groups <span class="caret"></span>');
			selectedGroupName="";
			selectedZoneName="";
			selectedSubZoneName="";
	  
			  $(window).unload(function() {
				  clearInterval(intr);
				 });
			  var intr = setInterval(function(){
				  var date = $util.normalizeDate();
				  if(isVirtual=="true")
					  {
					  
						var date = $util.normalizeDate();
						$util.getVirtualMonthlySchedule(date,$data.scheduleName,$data.virSchPath);
					  }
				  else
					  $util.getMonthlySchedule(date,$data.scheduleName);
				 },
				 20000);
		    }
		  }
		 });
  

  });
 
 function getVirtualScheduleList(path)
 {
	 getVirtualHtml(path,"#GroupNames","#GroupButton","#editGroup",'Groups <span class="caret"></span>');
	 
 }
 
 function getVirtualHtml(path,id,buttonId,editbutton,appendStr,selVal)
 {
	 if(path==null || path=="")
	 {
		 $(id).html("");
		  	$(buttonId).css("display","none");
		  	return;
	 }
	 $(id).html("");
	 $(buttonId).html("");
	 $(buttonId).append(appendStr);  
	 $(editbutton).css("display","none");	
	 $.niagara.getVirtualScheduleList(path,function(obj){
			 var list='';
			  if(obj!=null && obj.value!="false" && obj.value.length > 0)
			    {
				  for(var i=0;i<obj.value.length;i++)
				  {
					var grp=obj.value[i];
					list=list+'<li><a href"#" value="'+grp.path+'" idn="'+i+'">'+grp.name+'</a></li>';
				  }
				  $(buttonId).show();
				  $(id).append(list);
				  if(selVal && selVal!=undefined && selVal!=null && selVal!="")
				  {
					  $(buttonId).html("");
					  $(buttonId).append(selVal+' <span class="caret"></span>');
				  }	  
			    }
			  else
				  {
				  	$(id).html("");
				  	$(buttonId).css("display","none");
				  }
			 
			  });
 }

 function showSelected(group,obj,buttonId)
 {
	 isVirtual="true";
	 $(group).show();
	 var v = $(obj).attr("value");
	 $data.virSchPath = v;
	 var txt = $(obj).text();
	 $(buttonId).html("");
	 $(buttonId).append(txt+' <span class="caret"></span>');
	 var date = $util.normalizeDate();
	 $util.getVirtualMonthlySchedule(date,$data.scheduleName,v);
	 selectedGroupName = txt;
	 $(group).click(function()
			 {
		var alink = "groupEdit.html?ord="+$data.scheduleName+"&virSchPath="+v+"&name="+txt; 
		 $(group).attr('href',alink);
		 });
	 return v;
 }
 $("ul#GroupNames li a").live("click",function(){
	 var v = showSelected("#editGroup",this,"#GroupButton");
	 /*isVirtual="true";
	 $("#editGroup").show();
	 var v = $(this).attr("value");
	 $data.virSchPath = v;
	 var txt = $(this).text();
	 $("#GroupButton").html("");
	 $("#GroupButton").append(txt+' <span class="caret"></span>');
	 var date = $util.normalizeDate();
	 $util.getVirtualMonthlySchedule(date,$data.scheduleName,v);
	 selectedGroupName = txt;
	 $("#editGroup").click(function()
			 {
		var alink = "groupEdit.html?ord="+$data.scheduleName+"&virSchPath="+v+"&name="+txt; 
		 $("#editGroup").attr('href',alink);
		 });*/
	 getVirtualHtml(v,"#ZoneNames","#ZoneButton","#editZone","#closeZone",'Zones <span class="caret"></span>');
 });
 
 $("ul#ZoneNames li a").live("click",function(){
	 /*isVirtual="true";
	 $("#editZone").show();
	 var v = $(this).attr("value");
	 $data.virSchPath = v;
	 var txt = $(this).text();
	 $("#ZoneButton").html("");
	 $("#ZoneButton").append(txt+' <span class="caret"></span>');
	 var date = $util.normalizeDate();
	 $util.getVirtualMonthlySchedule(date,$data.scheduleName,v);
	 selectedZoneName = txt;
	 $("#editZone").click(function()
			 {
		var alink = "groupEdit.html?ord="+$data.scheduleName+"&virSchPath="+v+"&name="+txt; 
		 $("#editZone").attr('href',alink);
		 });*/
	 var v = showSelected("#editZone",this,"#ZoneButton");
	 getVirtualHtml(v,"#SubZoneNames","#SubZoneButton","#editSubZone","#closeSubZone",'Sub Zones <span class="caret"></span>');
 });
 
 $("ul#SubZoneNames li a").live("click",function(){
	 /*isVirtual="true";
	 $("#editSubZone").show();
	 var v = $(this).attr("value");
	 $data.virSchPath = v;
	 var txt = $(this).text();
	 $("#SubZoneButton").html("");
	 $("#SubZoneButton").append(txt+' <span class="caret"></span>');
	 var date = $util.normalizeDate();
	 $util.getVirtualMonthlySchedule(date,$data.scheduleName,v);
	 selectedSubZoneName = txt;
	 $("#editSubZone").click(function()
			 {
		var alink = "groupEdit.html?ord="+$data.scheduleName+"&virSchPath="+v+"&name="+txt; 
		 $("#editSubZone").attr('href',alink);
		 });*/
	 var v = showSelected("#editSubZone",this,"#SubZoneButton","#closeSubZone");
 });
 
 
 $("select#groupList").change(function(){
	 
	 selectVirtualSchedule();
 });	  


 $('#calendar').fullCalendar({
  //height:$(document).height(),
    height:500,
    
          // put your options and callbacks here
   header: {
    left: 'prev,next',
    center: 'title',
    right: 'month,agendaWeek,agendaDay'
   },
   selectable: false,
   selectHelper: false,
   
   editable: true,
   loading: function(bool){
    if(bool)
     $('#loading').show();
    else
     $('#loading').hide();
   },
    events: function(start,end,callback){
    },
    dayClick: function(date, allDay, jsEvent, view) {
   },
   
   eventClick: function(calEvent, jsEvent, view) {
    $('.qtip').each(function(){
     $(this).qtip('hide');
  });
    
    var v = $data.virSchPath;
    var jsonStr={
    		"title" : calEvent.name,
    		"startH" : ""+calEvent.start.getHours(),
    		"startM" : ""+calEvent.start.getMinutes(),
    		"startDay" : ""+calEvent.start.getDate(),
    		"startMon" : ""+calEvent.start.getMonth(),
    		"startYear" : ""+calEvent.start.getFullYear(),
    		"endH" : ""+calEvent.end.getHours(),
    		"endM" : ""+calEvent.end.getMinutes(),
    		"isException" : ""+ calEvent.isException,
    		"isVirtual" : ""+ calEvent.isVirtual,
    		"actualExceptionName" : ""+ calEvent.actualExceptionName,
    		"output" : calEvent.output,
    		"virSchPath" : v,
    		"selectedGroupName" : selectedGroupName,
    		"selectedZoneName" : selectedZoneName,
    		"selectedSubZoneName" : selectedSubZoneName
    };
    var jsonF = JSON.stringify(jsonStr);
    var obj = jQuery.parseJSON(jsonF);
    window.location.href = "editEvent.html?ord="+$data.scheduleName+'&json='+jsonF;

  },
  eventMouseover: function(event,jsEvent)
  {
	  jQuery(this).qtip();
  },
  eventMouseout: function(event)
  {
    $(event).qtip('hide'); 
       $('.qtip').each(function(){
    $(this).qtip('hide');
     });
	 //$(this).qtip().hide();
  },

  eventRender: function(event, element) {
	   var title = "";
	   if(event.isException == "false")
	   {
		   title = "<p><b>Event Name : "+event.title+"</b>  ("+event.type+")</p>";
	   }
	   else
	   {
		   title = "<p><b>Event Name : "+event.title+"</b>  ("+event.type+"  Exception)</p>";
	   }
	   
	   var priority = "<p><b>Event Priority : "+event.priority+"</b></p>";
	   var sMin = '',eMin='';
	   var startTime="";
	   if(event.start!=null)
	   {	   
		   if(event.start.getMinutes() < 10)
		    sMin = '0'+ event.start.getMinutes();
		   else
		    sMin = event.start.getMinutes();
	   
		   if(event.start.getHours() > 12)
		   {
		    var k = event.start.getHours()-12;
		    startTime = "<p><b>Start Time</b> : "+k+":"+sMin+" PM</p>";   
		   }
		   else if(event.start.getHours() == 12)
		   {
			   startTime = "<p><b>Start Time</b> : "+12+":"+sMin+" PM</p>";
		   }   
		   else
		   {
		     if(event.start.getHours() == 0)
		      startTime = "<p><b>Start Time</b> : "+12+":"+sMin+" AM</p>";
		     else
		      startTime = "<p><b>Start Time</b> : "+event.start.getHours()+":"+sMin+" AM</p>";
		   }
	   }
	   var endTime="";
	   if(event.end!=null)
	   {
		   if(event.end.getMinutes() < 10)
			    eMin = '0'+ event.end.getMinutes();
			   else
			    eMin = event.end.getMinutes();
	   
		  // var endTime="<p><b>End Time</b> : "+event.end.getHours()+":"+event.end.getMinutes()+"</p>";
			   if(event.end.getHours() > 12)
			   {
			    var k = event.end.getHours()-12;
			    endTime = "<p><b>End Time</b> : "+k+":"+eMin+" PM</p>";   
			   }
			   else if(event.end.getHours() == 12)
			   {
			    endTime = "<p><b>End Time</b> : "+12+":"+eMin+" PM</p>";
			   }   
			   else
			   {
			     if(event.end.getHours() == 0)
			      endTime = "<p><b>End Time</b> : "+12+":"+eMin+" AM</p>";
			     else
			      endTime = "<p><b>End Time</b> : "+event.end.getHours()+":"+eMin+" AM</p>";
			   }
	   
	   }		   
	   var outputs = "<p><b>Outputs:</b></p>";
	   for(var i=0;i<(event.output.length);i=i+3)
	   {
	    outputs = outputs + "<p>"+event.output[i]+":";
	    outputs = outputs + event.output[i+1]+"</p>";
	   }
	   element.qtip({
	     content: {
	      text:"<div>"+title+priority+startTime+endTime+outputs+"</div>"
	     },
	     position: {
	         my: 'top center',
	         at: 'bottom center'
	         },
	            style: { classes: 'qtip-light'}
	     });
  },
  eventAfterRender: function(calEvent,element) 
	{
	  if(calEvent.active == "ACTIVE")
	  {	
		  
		  element.marquee({
		  duration: 3000,
		  duplicate: false
		  }).css({"border":"1px solid black","overflow":"hidden","border-radius":"10px"});
	  }
	  if(calEvent.active == "next event")
	  {	
		  element.marquee({
		  duration: 3000,
		  duplicate: false
		  }).css({"border":"1px solid black","overflow":"hidden","border-radius":"10px"});
	  }
	  
},
  viewDisplay: function(view)
  {
      var date = $util.normalizeDate();
      $util.getMonthlySchedule(date,$data.scheduleName);
  }

 });
 $util.loadAddEvents();
 $("#addEventPage").click(function()
		 {
	 var alink = "addEvent.html?ord="+$data.scheduleName; 
	 $("#addEventPage").attr('href',alink);
		 });

 $("#sunOffsetPage").click(function()
		 {
	 var alink = "sunOffset.html?ord="+$data.scheduleName; 
	 $("#sunOffsetPage").attr('href',alink);
		 });

 $("#reorderEventsPage").click(function()
		 {
	 var alink = "reorderEvents.html?ord="+$data.scheduleName; 
	 $("#reorderEventsPage").attr('href',alink);
		 });

 $("#eventClassesPage").click(function()
		 {
	 var alink = "eventClasses.html?ord="+$data.scheduleName; 
	 $("#eventClassesPage").attr('href',alink);
		 });
 
 $("#overridePage").click(function()
		 {
	 var alink = "override.html?ord="+$data.scheduleName; 
	 $("#overridePage").attr('href',alink);
		 });
 $("#miscPage").click(function()
		 {
	 var alink = "misc.html?ord="+$data.scheduleName; 
	 $("#miscPage").attr('href',alink);
		 });

 
 $("#backButton").click(function()
		 {
	 	var arr = params[0].split("/");
	 	var sched = arr[arr.length-1];
	 	params[0]="";
	 	for(var i=0;i<arr.length-1;i++)
	 	{	
	 		if(i<arr.length-2)
	 			params[0] = params[0]+arr[i]+"/";
	 		else
	 			params[0] = params[0]+arr[i];
	 	}
	 	var alink = "indexRelative.html?ord="+params[0]+"&sched="+sched;
	 	$("#backButton").attr('href',alink);
});

 $("#hvacSelect").click(function()
 {
  createScheduleList(hvacList);
 });
 $("#lightingSelect").click(function()
 {
  createScheduleList(lightingList);
 });
 $("#generalSelect").click(function()
 {
  createScheduleList(generalList);
 });
 
/* function createScheduleList(arr)
 {
  $("#hvac_list").empty();
  for(var j=0;j<arr.length;j++)
  {
   $("#hvac_list").append($('<option>',{value : arr[j].name})
              .text(arr[j].name));
  }
  if(arr.length > 0)
  {
   $data.scheduleName = arr[0].path;
   $("#NamePlaceholder h2").text(arr[0].description);
   var date = $util.normalizeDate();
   $util.getMonthlySchedule(date,$data.scheduleName);
  }
 }*/
 
 
 
 
 
 
    $('.window .close').click(function (e) {
        e.preventDefault();
        $('#mask, .window').hide();
    });     
     
    $('#mask').click(function () {
        $(this).hide();
        $('.window').hide();
    });         

 /* Get the metering present datapoint and store its result */
  

 
 //$.niagara.BatchPoll.printPollList();
});
